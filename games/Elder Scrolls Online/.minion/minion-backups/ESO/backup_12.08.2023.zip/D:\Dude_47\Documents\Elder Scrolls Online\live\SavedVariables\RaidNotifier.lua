RNVars =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["sunspire"] = 
                {
                    ["shock_bolt"] = true,
                    ["focus_fire"] = 1,
                    ["chilling_comet"] = 1,
                    ["breath"] = 1,
                    ["negate_field"] = 1,
                    ["molten_meteor"] = 1,
                    ["mark_for_death"] = 0,
                    ["cataclism"] = true,
                    ["time_breach"] = false,
                    ["thrash"] = true,
                    ["sweeping_breath"] = true,
                    ["frozen_tomb"] = true,
                },
                ["sounds"] = 
                {
                },
                ["cloudrest"] = 
                {
                    ["heavy_attack"] = 0,
                    ["chilling_comet"] = true,
                    ["shadow_realm_cast"] = false,
                    ["baneful_barb"] = 0,
                    ["break_amulet"] = false,
                    ["voltaic_overload"] = 1,
                    ["crushing_darkness"] = 1,
                    ["tentacle_spawn"] = false,
                    ["sum_shadow_beads"] = false,
                    ["voltaic_overload_time"] = 10000,
                    ["shadow_splash"] = false,
                    ["hoarfrost_countdown"] = true,
                    ["malicious_strike"] = false,
                    ["hoarfrost_shed"] = true,
                    ["roaring_flare"] = 2,
                    ["track_roaring_flare"] = false,
                    ["hoarfrost"] = 0,
                    ["nocturnals_favor"] = 0,
                    ["olorime_spears"] = false,
                },
                ["countdown"] = 
                {
                    ["timerScale"] = 100,
                    ["textScale"] = 100,
                    ["timerPrecise"] = 10,
                    ["useColor"] = false,
                },
                ["maelstrom"] = 
                {
                    ["stage9_synergy"] = true,
                    ["stage7_poison"] = true,
                },
                ["rockgrove"] = 
                {
                    ["havocrel_barbarian_hasted_assault"] = false,
                    ["sulxan_reaver_sundering_strike"] = 0,
                    ["sulxan_soulweaver_soul_remnant"] = false,
                    ["oaxiltso_noxious_sludge"] = 0,
                    ["prime_meteor"] = false,
                    ["oaxiltso_annihilator_cinder_cleave"] = 0,
                    ["bahsei_embrace_of_death"] = 0,
                    ["sulxan_soulweaver_astral_shield"] = false,
                    ["oaxiltso_savage_blitz"] = false,
                },
                ["asylum"] = 
                {
                    ["olms_protector_spawn"] = true,
                    ["llothis_defiling_blast"] = 1,
                    ["olms_gusts_of_steam_slider"] = 0,
                    ["olms_exhaustive_charges"] = false,
                    ["llothis_soul_stained_corruption"] = false,
                    ["felms_teleport_strike"] = 1,
                    ["olms_trial_by_fire"] = true,
                    ["olms_storm_the_heavens"] = true,
                    ["olms_gusts_of_steam"] = true,
                },
                ["hallsFab"] = 
                {
                    ["committee_fabricant_spawn"] = false,
                    ["pinnacleBoss_conduit_drain"] = 0,
                    ["pinnacleBoss_conduit_spawn"] = true,
                    ["pinnacleBoss_scalded"] = true,
                    ["committee_overpower_auras_duration"] = 9000,
                    ["committee_reclaim_achieve"] = false,
                    ["power_leech"] = false,
                    ["committee_overpower_auras"] = false,
                    ["conduit_strike"] = true,
                    ["committee_overpower_auras_dynamic"] = false,
                    ["taking_aim"] = 1,
                    ["taking_aim_duration"] = 5000,
                    ["draining_ballista"] = 1,
                    ["venom_injection"] = false,
                    ["taking_aim_dynamic"] = 1,
                    ["pinnacleBoss_scalded_display"] = 
                    {
                        [2] = 400,
                        [1] = 100,
                    },
                },
                ["general"] = 
                {
                    ["unlock_status_icon"] = false,
                    ["useDisplayName"] = false,
                    ["no_assistants"] = true,
                    ["use_center_screen_announce"] = 1,
                    ["vanity_pets"] = true,
                    ["notifications_scale"] = 100,
                    ["last_pet"] = 0,
                    ["status_display"] = 
                    {
                        [1] = 100,
                        [2] = 400,
                        [3] = 128,
                    },
                    ["default_sound"] = "Champion_PointsCommitted",
                    ["buffFood_reminder_interval"] = 60,
                    ["announcement_position"] = 
                    {
                        [1] = 0,
                        [2] = -120,
                        [3] = 128,
                    },
                    ["buffFood_reminder"] = true,
                },
                ["useAccountWide"] = true,
                ["archive"] = 
                {
                    ["overcharge"] = 0,
                    ["stoneatro_bigquake"] = false,
                    ["stormatro_impendingstorm"] = false,
                    ["stormatro_lightningstorm"] = false,
                    ["call_lightning"] = 1,
                    ["stoneatro_boulderstorm"] = false,
                },
                ["kynesAegis"] = 
                {
                    ["yandir_fireshaman_meteor"] = 0,
                    ["bitter_knight_sanguine_prison"] = false,
                    ["yandir_totem_spawn"] = 0,
                    ["tidebreaker_crashing_wall"] = false,
                    ["falgravn_ichor_eruption_time_before"] = 3,
                    ["bloodknight_blood_fountain"] = false,
                    ["falgravn_ichor_eruption"] = false,
                    ["vrol_firemage_meteor"] = 0,
                },
                ["dragonstar"] = 
                {
                    ["arena6_drain_resource"] = 1,
                    ["arena7_unstable_core"] = true,
                    ["arena2_crushing_shock"] = true,
                    ["general_taking_aim"] = false,
                    ["general_crystal_blast"] = true,
                    ["arena8_ice_charge"] = 1,
                    ["arena8_fire_charge"] = 1,
                },
                ["dreadsailReef"] = 
                {
                    ["reef_guardian_reef_heart_result"] = false,
                    ["taleria_rapid_deluge"] = 0,
                    ["reef_guardian_reef_heart"] = false,
                    ["brothers_heavy_attack"] = 0,
                    ["imminent_debuffs"] = false,
                    ["dome_activation"] = false,
                },
                ["dbg"] = 
                {
                    ["verbose"] = false,
                    ["tracker"] = false,
                    ["devMode"] = false,
                    ["enable"] = false,
                    ["notify"] = false,
                    ["spamControl"] = true,
                    ["myEnemyOnly"] = false,
                },
                ["mawLorkhaj"] = 
                {
                    ["rakkhat_unstablevoid"] = 1,
                    ["rakkhat_lunarbastion2"] = 0,
                    ["rakkhat_lunarbastion1"] = 0,
                    ["zhaj_glyph_window"] = 
                    {
                        [2] = 400,
                        [1] = 100,
                    },
                    ["twinBoss_aspects_status"] = false,
                    ["zhaj_glyphs_invert"] = false,
                    ["rakkhat_threshingwings"] = true,
                    ["zhaj_gripoflorkhaj"] = true,
                    ["zhaj_glyphs"] = false,
                    ["twinBoss_aspects"] = 2,
                    ["shattering_strike"] = 0,
                    ["hulk_armorweakened"] = false,
                    ["rakkhat_darkbarrage"] = false,
                    ["suneater_eclipse"] = 1,
                    ["rakkhat_darknessfalls"] = false,
                    ["rakkhat_unstablevoid_countdown"] = false,
                },
                ["version"] = 4,
                ["dLog"] = 
                {
                },
                ["sanctumOphidia"] = 
                {
                    ["troll_boulder"] = 0,
                    ["overcharge"] = 0,
                    ["magicka_deto"] = true,
                    ["call_lightning"] = 1,
                    ["mantikora_quake"] = false,
                    ["troll_poison"] = 0,
                    ["serpent_world_shaper"] = true,
                    ["serpent_poison"] = 1,
                },
                ["ultimate"] = 
                {
                    ["useDisplayName"] = false,
                    ["ulti_window"] = 
                    {
                        [2] = 600,
                        [1] = 100,
                    },
                    ["enabled"] = false,
                    ["override_cost"] = 0,
                    ["showHealers"] = true,
                    ["showDps"] = false,
                    ["hidden"] = false,
                    ["showTanks"] = true,
                    ["useColor"] = true,
                },
                ["helra"] = 
                {
                    ["yokeda_meteor"] = 1,
                    ["warrior_stoneform"] = 1,
                },
                ["addonVersion"] = "2.24.1",
            },
        },
    },
}
