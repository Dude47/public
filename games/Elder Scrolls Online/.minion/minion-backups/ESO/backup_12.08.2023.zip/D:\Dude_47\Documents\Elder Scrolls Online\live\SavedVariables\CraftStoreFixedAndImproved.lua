CraftStore_Account =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["EU Megaserver"] = 
                {
                    ["furnisher"] = 
                    {
                        ["knowledge"] = 
                        {
                            ["Galrnskar Haraendottir"] = "CSFK32фAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2",
                        },
                        ["ingredients"] = 
                        {
                        },
                        ["tracking"] = 
                        {
                            ["Galrnskar Haraendottir"] = false,
                        },
                    },
                    ["announce"] = 
                    {
                    },
                    ["timer"] = 
                    {
                        [12] = 0,
                        [24] = 0,
                    },
                    ["position"] = 
                    {
                        [2] = 100,
                        [1] = 350,
                    },
                    ["cook"] = 
                    {
                        ["knowledge"] = 
                        {
                            ["Galrnskar Haraendottir"] = "CSCK28фAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAECAAAAIAgAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA5",
                        },
                        ["ingredients"] = 
                        {
                        },
                        ["tracking"] = 
                        {
                            ["Galrnskar Haraendottir"] = false,
                        },
                    },
                    ["crafting"] = 
                    {
                        ["studies"] = 
                        {
                            ["Galrnskar Haraendottir"] = "CSCS29фAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0",
                        },
                        ["skill"] = 
                        {
                            ["Galrnskar Haraendottir"] = 
                            {
                                [1] = 
                                {
                                    ["maxsim"] = 1,
                                    ["rank"] = 5,
                                    ["unknown"] = 124,
                                    ["level"] = 2,
                                },
                                [2] = 
                                {
                                    ["maxsim"] = 1,
                                    ["rank"] = 4,
                                    ["unknown"] = 125,
                                    ["level"] = 1,
                                },
                                [3] = 
                                {
                                    ["maxsim"] = 0,
                                    ["rank"] = 1,
                                    ["level"] = 1,
                                },
                                [4] = 
                                {
                                    ["maxsim"] = 0,
                                    ["rank"] = 4,
                                    ["level"] = 1,
                                },
                                [5] = 
                                {
                                    ["maxsim"] = 0,
                                    ["rank"] = 4,
                                    ["level"] = 1,
                                },
                                [6] = 
                                {
                                    ["maxsim"] = 1,
                                    ["rank"] = 5,
                                    ["unknown"] = 54,
                                    ["level"] = 1,
                                },
                                [7] = 
                                {
                                    ["maxsim"] = 1,
                                    ["rank"] = 1,
                                    ["unknown"] = 18,
                                    ["level"] = 0,
                                },
                            },
                        },
                        ["researched"] = 
                        {
                            ["Galrnskar Haraendottir"] = "CSCR29фAAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0",
                        },
                        ["stored"] = 
                        {
                            [2] = 
                            {
                                [1] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [2] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [3] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [4] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [5] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [6] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [7] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [8] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [9] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [10] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [11] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [12] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [13] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [14] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                            },
                            [1] = 
                            {
                                [1] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                        ["link"] = "|H0:item:45228:2:17:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:0:0|h|h",
                                        ["id"] = "4960035203599827655",
                                        ["owner"] = "Galrnskar Haraendottir",
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [2] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [3] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [4] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [5] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [6] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [7] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [8] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [9] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                        ["link"] = "|H0:item:45096:4:19:26588:4:19:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h",
                                        ["id"] = "4960016606391436373",
                                        ["owner"] = "Galrnskar Haraendottir",
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [10] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [11] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [12] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [13] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [14] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                            },
                            [6] = 
                            {
                                [1] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [2] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [3] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [4] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [5] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [6] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                        ["link"] = "|H0:item:45083:4:19:26582:4:19:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h",
                                        ["id"] = "4960035203599827812",
                                        ["owner"] = "Galrnskar Haraendottir",
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                        ["link"] = "|H0:item:134799:4:15:0:0:0:0:0:0:0:0:0:0:0:1:19:0:0:0:0:0|h|h",
                                        ["id"] = "4960035203599827579",
                                        ["owner"] = "Galrnskar Haraendottir",
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                            },
                            [7] = 
                            {
                                [2] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                                [1] = 
                                {
                                    [1] = 
                                    {
                                    },
                                    [2] = 
                                    {
                                    },
                                    [3] = 
                                    {
                                    },
                                    [4] = 
                                    {
                                    },
                                    [5] = 
                                    {
                                    },
                                    [6] = 
                                    {
                                    },
                                    [7] = 
                                    {
                                    },
                                    [8] = 
                                    {
                                    },
                                    [9] = 
                                    {
                                    },
                                },
                            },
                        },
                        ["researching"] = 
                        {
                            ["Galrnskar Haraendottir"] = 
                            {
                                [2] = 
                                {
                                    [10] = 
                                    {
                                        [5] = 1691880199,
                                    },
                                },
                                [1] = 
                                {
                                    [12] = 
                                    {
                                        [4] = 1691877332,
                                    },
                                },
                            },
                        },
                    },
                    ["player"] = 
                    {
                        ["Galrnskar Haraendottir"] = 
                        {
                            ["skyShards"] = "17/543",
                            ["skillPoints"] = "3/32",
                            ["level"] = 19,
                            ["mount"] = 
                            {
                                ["stamina"] = "0/60",
                                ["space"] = "2/60",
                                ["complete"] = false,
                                ["time"] = 0,
                                ["speed"] = "0/60",
                            },
                            ["faction"] = 2,
                            ["race"] = 5,
                            ["class"] = 1,
                        },
                    },
                    ["questbox"] = 
                    {
                        [2] = -20,
                        [1] = 2060,
                    },
                    ["mainchar"] = false,
                    ["coords"] = 
                    {
                        ["blueprint"] = 
                        {
                            [2] = 140,
                            [1] = 2060,
                        },
                        ["overview"] = 
                        {
                            [2] = 319.5000000000,
                            [1] = 979.5000000000,
                        },
                        ["style"] = 
                        {
                            [2] = 200,
                            [1] = 500,
                        },
                        ["rune"] = 
                        {
                            [2] = 140,
                            [1] = 2016,
                        },
                        ["recipe"] = 
                        {
                            [2] = 200,
                            [1] = 600,
                        },
                        ["cook"] = 
                        {
                            [2] = 140,
                            [1] = 2016,
                        },
                    },
                    ["trait"] = 
                    {
                        ["tracking"] = 
                        {
                            ["Galrnskar Haraendottir"] = false,
                        },
                    },
                    ["button"] = 
                    {
                        [2] = 75,
                        [1] = 75,
                    },
                    ["version"] = 3,
                    ["options"] = 
                    {
                        ["userunecreation"] = true,
                        ["advancedcolorgrid"] = true,
                        ["showstock"] = true,
                        ["markitems"] = true,
                        ["useruneextraction"] = true,
                        ["mountalarm"] = 1,
                        ["userune"] = true,
                        ["displaycount"] = true,
                        ["lockelements"] = false,
                        ["markduplicates"] = true,
                        ["sortstyles"] = 1,
                        ["closeonmove"] = true,
                        ["stacksplit"] = true,
                        ["lockprotection"] = true,
                        ["displayknown"] = true,
                        ["usequest"] = false,
                        ["overviewstyle"] = 1,
                        ["userunerecipe"] = true,
                        ["timeralarm"] = 1,
                        ["bulkcraftlimit"] = 10,
                        ["usecook"] = true,
                        ["useflask"] = false,
                        ["displayttc"] = true,
                        ["playrunevoice"] = true,
                        ["sortsets"] = 1,
                        ["displayrunelevel"] = true,
                        ["lockbutton"] = false,
                        ["displaystyles"] = false,
                        ["marksetitems"] = true,
                        ["displaymm"] = true,
                        ["displayunknown"] = true,
                        ["showbutton"] = true,
                        ["useartisan"] = false,
                        ["showsymbols"] = false,
                        ["researchalarm"] = 1,
                    },
                    ["materials"] = 
                    {
                        ["|H0:item:808:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:5413:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:5413:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:808:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:5820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:4487:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:64690:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:64689:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:4447:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:4448:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:794:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:793:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:135137:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:135138:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:521:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:533:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:64689:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:64690:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:4487:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:5820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:793:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:794:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:135138:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:135137:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:533:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:521:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:803:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:802:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = false,
                        },
                        ["|H0:item:802:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:803:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                        ["|H0:item:4448:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["link"] = "|H0:item:4447:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                            ["raw"] = true,
                        },
                    },
                    ["storage"] = 
                    {
                        ["|H0:item:64711:123:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:71740:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:135161:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:28636:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:114889:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:34345:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:43529:2:18:0:0:0:0:0:0:0:0:0:0:0:0:2:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:23165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:33771:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 7,
                        },
                        ["|H0:item:54383:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:23204:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:4448:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:30219:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:45228:2:17:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:64701:6:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:54387:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:45228:4:19:26848:4:19:0:0:0:0:0:0:0:0:0:2:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:64710:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:42872:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:33756:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:33253:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 8,
                        },
                        ["|H0:item:26848:2:18:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:45043:4:18:26582:4:18:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:114891:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:533:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 4,
                        },
                        ["|H0:item:45049:3:18:26848:3:18:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:43532:2:18:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:46152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:135111:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 25,
                        },
                        ["|H0:item:29030:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:46149:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:54174:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 5,
                        },
                        ["|H0:item:43529:3:18:26848:3:18:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:802:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 33,
                        },
                        ["|H0:item:71766:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:54508:2:18:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:54179:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:5413:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 28,
                        },
                        ["|H0:item:43544:2:18:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:28609:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:45852:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:33251:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:45083:4:19:26582:4:19:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:43559:3:18:26848:3:18:0:0:0:0:0:0:0:0:0:9:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:95984:3:9:0:0:0:0:0:0:0:0:0:0:0:1:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:114895:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:43537:3:19:26580:3:19:0:0:0:0:0:0:0:0:0:7:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:27064:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:135137:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 24,
                        },
                        ["|H0:item:33256:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 5,
                        },
                        ["|H0:item:34330:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:26580:2:18:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:813:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:46151:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:45344:2:18:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:42870:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:33773:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:33150:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 5,
                        },
                        ["|H0:item:794:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 19,
                        },
                        ["|H0:item:45838:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:27035:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:43530:2:18:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:803:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 21,
                        },
                        ["|H0:item:521:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:808:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 59,
                        },
                        ["|H0:item:79690:6:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:793:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 23,
                        },
                        ["|H0:item:811:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 19,
                        },
                        ["|H0:item:45843:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:116154:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:5820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 9,
                        },
                        ["|H0:item:44879:121:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:33258:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:33265:30:50:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:33753:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 3,
                        },
                        ["|H0:item:54384:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:33257:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:45833:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:134618:124:1:0:0:0:5:10000:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:64690:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:42871:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:127108:1:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:45134:3:4:26588:3:4:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:45183:2:18:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:16291:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:45870:2:18:0:0:0:0:0:0:0:0:0:0:0:0:3:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:121279:6:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:54170:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 10,
                        },
                        ["|H0:item:28078:18:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:94098:3:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:135113:122:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:43554:2:18:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:43740:4:1:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:45189:2:18:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:23203:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:54508:4:18:45870:4:18:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:5365:2:19:0:0:0:0:0:0:0:0:0:0:0:0:2:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:33255:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:54178:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:134799:4:15:0:0:0:0:0:0:0:0:0:0:0:1:19:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:114894:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 11,
                        },
                        ["|H0:item:4442:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 5,
                        },
                        ["|H0:item:43535:319:18:0:0:0:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:61080:32:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:153887:5:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:33194:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:34349:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 5,
                        },
                        ["|H0:item:45305:2:18:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:34305:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:4447:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:45871:2:18:0:0:0:0:0:0:0:0:0:0:0:0:5:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:43563:2:18:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:34323:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        ["|H0:item:45853:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:45096:4:19:26588:4:19:0:0:0:0:0:0:0:0:0:4:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 1,
                        },
                        ["|H0:item:28603:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:4487:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 17,
                        },
                        ["|H0:item:71779:4:1:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:46150:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 2,
                        },
                        ["|H0:item:135114:123:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["Galrnskar Haraendottir"] = 25,
                        },
                        ["|H0:item:33252:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 6,
                        },
                        ["|H0:item:45820:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:23219:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 1,
                        },
                        [""] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:54385:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = 
                        {
                        },
                        ["|H0:item:64537:124:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:0:0:0:0|h|h"] = 
                        {
                            ["House Bank "] = 0,
                            ["House Bank 0"] = 0,
                        },
                        ["|H0:item:30357:175:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h"] = 
                        {
                            ["Bank"] = 4,
                            ["Galrnskar Haraendottir"] = 50,
                        },
                        ["|H0:item:45314:2:18:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:0:0|h|h"] = 
                        {
                        },
                    },
                    ["style"] = 
                    {
                        ["tracking"] = 
                        {
                            ["Galrnskar Haraendottir"] = false,
                        },
                        ["knowledge"] = 
                        {
                            ["Galrnskar Haraendottir"] = "CSSK32фBAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4",
                        },
                    },
                },
            },
        },
    },
}
CraftStore_Character =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["EU Megaserver"] = 
                {
                    ["hideKnownRecipes"] = false,
                    ["essence"] = 1,
                    ["hidestyles"] = false,
                    ["version"] = 2,
                    ["hideUnknownRecipes"] = false,
                    ["enchant"] = 21,
                    ["potencytype"] = 1,
                    ["previewtype"] = 1,
                    ["hideKnownBlueprints"] = false,
                    ["favorites"] = 
                    {
                        [1] = 
                        {
                        },
                        [2] = 
                        {
                        },
                        [3] = 
                        {
                        },
                        [4] = 
                        {
                        },
                        [5] = 
                        {
                        },
                        [6] = 
                        {
                        },
                    },
                    ["recipe"] = 1,
                    ["furniture"] = 1,
                    ["hideUnknownBlueprints"] = false,
                    ["aspect"] = 1,
                    ["potency"] = 1,
                    ["previewType"] = 1,
                    ["hidecrownstyles"] = false,
                    ["runemode"] = "craft",
                    ["income"] = 
                    {
                        [2] = 106,
                        [1] = 20230812,
                    },
                    ["hideperfectedstyles"] = false,
                },
            },
        },
    },
}
