HarvensImprovedSkillsWindow_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["Galrnskar Haraendottir"] = 
            {
                ["showDetails"] = true,
                ["version"] = 1,
                ["showTotal"] = false,
            },
        },
    },
}
