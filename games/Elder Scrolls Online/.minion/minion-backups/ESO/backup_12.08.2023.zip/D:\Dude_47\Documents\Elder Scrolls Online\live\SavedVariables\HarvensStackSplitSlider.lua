HarvensStackSplitSlider_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["lastValue"] = 0,
                ["version"] = 1,
            },
        },
    },
}
