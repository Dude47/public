EventCollectiblesSavedVariables =
{
    ["Default"] = 
    {
        ["$InstallationWide"] = 
        {
            ["$AccountWide"] = 
            {
                ["filterId"] = 1,
                ["version"] = 1,
            },
        },
    },
}
