Harvest_SavedVars =
{
    ["tours"] = 
    {
    },
    ["account"] = 
    {
        ["Dude_47"] = 
        {
            ["filterProfiles"] = 
            {
                [1] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [11] = true,
                    [12] = true,
                    [13] = true,
                    [14] = true,
                    [15] = true,
                    [16] = true,
                    [17] = true,
                    [18] = false,
                    [19] = true,
                    ["name"] = "Default Filter Profile",
                },
            },
            ["compassSpawnFilter"] = false,
            ["hiddenOnHarvest"] = true,
            ["worldSpawnFilter"] = false,
            ["hiddenTime"] = 1,
            ["pinsAbovePoi"] = false,
            ["worldFilterProfile"] = 1,
            ["hasMaxVisibleDistance"] = false,
            ["pinLayouts"] = 
            {
                [1] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.4900000000,
                        ["r"] = 0.4470000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/mining.dds",
                },
                [2] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.9880000000,
                        ["r"] = 0.5880000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/clothing.dds",
                },
                [3] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.4550000000,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0.4780000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/enchanting.dds",
                },
                [4] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.5690000000,
                        ["r"] = 0.4510000000,
                        ["a"] = 1,
                        ["b"] = 0.4240000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/mushroom.dds",
                },
                [5] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.6940000000,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0.4940000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/wood.dds",
                },
                [6] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.9370000000,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0.3800000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/chest.dds",
                },
                [7] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.8270000000,
                        ["r"] = 0.5690000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/solvent.dds",
                },
                [8] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/fish.dds",
                },
                [9] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.6900000000,
                        ["r"] = 0.4240000000,
                        ["a"] = 1,
                        ["b"] = 0.3600000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/heavysack.dds",
                },
                [10] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.4040000000,
                        ["r"] = 0.7800000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/trove.dds",
                },
                [11] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/justice.dds",
                },
                [12] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/stash.dds",
                },
                [13] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 0.5570000000,
                        ["a"] = 1,
                        ["b"] = 0.5410000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/flower.dds",
                },
                [14] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.9370000000,
                        ["r"] = 0.4390000000,
                        ["a"] = 1,
                        ["b"] = 0.8080000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/waterplant.dds",
                },
                [15] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/clam.dds",
                },
                [16] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/stash.dds",
                },
                [17] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/stash.dds",
                },
                [18] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "esoui/art/icons/poi/poi_crafting_complete.dds",
                },
                [19] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 0.3450000000,
                        ["r"] = 0.9330000000,
                        ["a"] = 1,
                        ["b"] = 0.5370000000,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/waterplant.dds",
                },
                [100] = 
                {
                    ["size"] = 32,
                    ["tint"] = 
                    {
                        ["g"] = 0,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/tour.dds",
                },
            },
            ["displayNotifications"] = true,
            ["useHiddenTime"] = false,
            ["displayCompassPins"] = true,
            ["worldPinWidth"] = 100,
            ["minimapSpawnFilter"] = false,
            ["worldPinDepth"] = true,
            ["displayWorldPins"] = true,
            ["compassFilterProfile"] = 1,
            ["mapFilterProfile"] = 1,
            ["heatmap"] = false,
            ["visitedRangeInMeters"] = 10,
            ["displayMinimapPins"] = true,
            ["isSpawnFilterUsedForPinType"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [7] = true,
                [13] = true,
                [14] = true,
                [19] = true,
            },
            ["worldPinHeight"] = 200,
            ["showDebugOutput"] = false,
            ["displayMapPins"] = true,
            ["compassDistanceInMeters"] = 100,
            ["maxVisibleDistanceInMeters"] = 300,
            ["worldDistanceInMeters"] = 100,
            ["mapSpawnFilter"] = false,
            ["accountWideSettings"] = false,
            ["isPinTypeSavedOnGather"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                [8] = true,
                [9] = true,
                [10] = true,
                [11] = true,
                [12] = true,
                [13] = true,
                [14] = true,
                [15] = true,
                [16] = true,
                [17] = true,
                [18] = false,
                [19] = true,
            },
            ["minimapPinSize"] = 20,
        },
    },
    ["global"] = 
    {
        ["maxTimeDifference"] = 0,
        ["minGameVersion"] = 0,
    },
    ["character"] = 
    {
        ["8798292093726442"] = 
        {
            ["filterProfiles"] = 
            {
                [1] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [11] = true,
                    [12] = true,
                    [13] = true,
                    [14] = true,
                    [15] = true,
                    [16] = true,
                    [17] = true,
                    [18] = false,
                    [19] = true,
                    ["name"] = "Default Filter Profile",
                },
            },
            ["hiddenOnHarvest"] = true,
            ["compassSpawnFilter"] = false,
            ["hiddenTime"] = 1,
            ["pinsAbovePoi"] = false,
            ["worldFilterProfile"] = 1,
            ["hasMaxVisibleDistance"] = false,
            ["mapFilterProfile"] = 1,
            ["displayNotifications"] = true,
            ["pinLayouts"] = 
            {
                [1] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.4900000000,
                        ["r"] = 0.4470000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/mining.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [2] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.9880000000,
                        ["r"] = 0.5880000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/clothing.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [3] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.4550000000,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0.4780000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/enchanting.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [4] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.5690000000,
                        ["r"] = 0.4510000000,
                        ["a"] = 1,
                        ["b"] = 0.4240000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/mushroom.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [5] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.6940000000,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0.4940000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/wood.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [6] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.9370000000,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0.3800000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/chest.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [7] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.8270000000,
                        ["r"] = 0.5690000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/solvent.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [8] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/fish.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [9] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.6900000000,
                        ["r"] = 0.4240000000,
                        ["a"] = 1,
                        ["b"] = 0.3600000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/heavysack.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [10] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.4040000000,
                        ["r"] = 0.7800000000,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/trove.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [11] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/justice.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [12] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/stash.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [13] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 0.5570000000,
                        ["a"] = 1,
                        ["b"] = 0.5410000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/flower.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [14] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.9370000000,
                        ["r"] = 0.4390000000,
                        ["a"] = 1,
                        ["b"] = 0.8080000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/waterplant.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [15] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/clam.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [16] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/stash.dds",
                },
                [17] = 
                {
                    ["size"] = 20,
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["texture"] = "HarvestMap/Textures/Map/stash.dds",
                },
                [18] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 1,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "esoui/art/icons/poi/poi_crafting_complete.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [19] = 
                {
                    ["tint"] = 
                    {
                        ["g"] = 0.3450000000,
                        ["r"] = 0.9330000000,
                        ["a"] = 1,
                        ["b"] = 0.5370000000,
                    },
                    ["level"] = 20,
                    ["size"] = 20,
                    ["texture"] = "HarvestMap/Textures/Map/waterplant.dds",
                    ["currentPinSize"] = 26.0000000000,
                    ["OnClickHandler"] = 
                    {
                        [1] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [2] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                        [3] = 
                        {
                            ["show"] = nil, -- invalid value type [function] used
                            ["callback"] = nil, -- invalid value type [function] used
                        },
                    },
                },
                [100] = 
                {
                    ["size"] = 32,
                    ["tint"] = 
                    {
                        ["g"] = 0,
                        ["r"] = 1,
                        ["a"] = 1,
                        ["b"] = 0,
                    },
                    ["level"] = 55,
                    ["texture"] = "HarvestMap/Textures/Map/tour.dds",
                },
            },
            ["displayCompassPins"] = true,
            ["worldPinWidth"] = 100,
            ["minimapSpawnFilter"] = false,
            ["worldPinDepth"] = true,
            ["displayWorldPins"] = true,
            ["compassFilterProfile"] = 1,
            ["useHiddenTime"] = false,
            ["heatmap"] = false,
            ["worldSpawnFilter"] = false,
            ["displayMinimapPins"] = true,
            ["isSpawnFilterUsedForPinType"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [7] = true,
                [13] = true,
                [14] = true,
                [19] = true,
            },
            ["compassDistanceInMeters"] = 100,
            ["showDebugOutput"] = false,
            ["displayMapPins"] = true,
            ["visitedRangeInMeters"] = 10,
            ["isPinTypeSavedOnGather"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                [8] = true,
                [9] = true,
                [10] = true,
                [11] = true,
                [12] = true,
                [13] = true,
                [14] = true,
                [15] = true,
                [16] = true,
                [17] = true,
                [18] = false,
                [19] = true,
            },
            ["worldDistanceInMeters"] = 100,
            ["mapSpawnFilter"] = false,
            ["maxVisibleDistanceInMeters"] = 300,
            ["worldPinHeight"] = 200,
            ["minimapPinSize"] = 20,
        },
    },
}
