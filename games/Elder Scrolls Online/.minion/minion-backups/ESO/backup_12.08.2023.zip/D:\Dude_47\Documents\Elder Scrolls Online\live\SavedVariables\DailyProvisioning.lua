DailyProvisioningVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["version"] = 1,
            },
            ["$AccountWide"] = 
            {
                ["isDontKnow"] = true,
                ["isAcquireItem"] = true,
                ["isDebugQuest"] = true,
                ["version"] = 1,
                ["reservations"] = 
                {
                },
                ["debugLog"] = 
                {
                },
                ["isLog"] = true,
                ["acquireDelay"] = 1,
            },
        },
    },
}
