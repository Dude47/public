LibGroupSocket_Data =
{
    ["@Dude_47"] = 
    {
        ["autoDisableOnSessionStart"] = true,
        ["version"] = 1,
        ["handlers"] = 
        {
            [1] = 
            {
                ["percentOnly"] = true,
                ["enabled"] = true,
                ["version"] = 1,
            },
            [21] = 
            {
                ["enabled"] = true,
                ["version"] = 1,
            },
        },
        ["enabled"] = false,
        ["autoDisableOnGroupLeft"] = true,
    },
}
