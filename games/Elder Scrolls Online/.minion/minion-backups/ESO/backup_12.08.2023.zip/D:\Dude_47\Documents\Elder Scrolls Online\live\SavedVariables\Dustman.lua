Dustman_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["dailyLoginSoulGems"] = false,
                ["junkKeybind"] = false,
                ["stolenRecipeQuality"] = 1,
                ["housingRecipesQuality"] = 1,
                ["itemTraits"] = 
                {
                    [32] = false,
                    [1] = false,
                    [2] = false,
                    [3] = false,
                    [4] = false,
                    [5] = false,
                    [6] = false,
                    [7] = false,
                    [8] = false,
                    [11] = false,
                    [12] = false,
                    [13] = false,
                    [14] = false,
                    [15] = false,
                    [16] = false,
                    [17] = false,
                    [18] = false,
                    [21] = false,
                    [22] = false,
                    [23] = false,
                    [33] = false,
                    [28] = false,
                    [29] = false,
                    [30] = false,
                    [31] = false,
                },
                ["version"] = 2,
                ["lure"] = false,
                ["foodAll"] = false,
                ["useGlobalSettings"] = true,
                ["notifications"] = 
                {
                    ["sell"] = true,
                    ["total"] = true,
                    ["found"] = false,
                    ["allItems"] = true,
                    ["sellDialog"] = true,
                    ["verbose"] = false,
                },
                ["glyphs"] = false,
                ["fullStackBagPoisons"] = false,
                ["destroyNonLaundered"] = false,
                ["poisonsSolvants"] = false,
                ["potions"] = false,
                ["destroyQuality"] = 1,
                ["destroy"] = false,
                ["fullStackBagPoisonsSolvants"] = false,
                ["fullStackBankPotions"] = false,
                ["keepPoisonsLevel"] = 1,
                ["worldname"] = "EU Megaserver",
                ["destroyExcludeStackable"] = false,
                ["stolenQuality"] = 1,
                ["dailyLoginRepairKits"] = false,
                ["museumPiecesDestroy"] = false,
                ["lureFullStackBank"] = false,
                ["poisons"] = false,
                ["launder"] = false,
                ["treasureMaps"] = false,
                ["memory"] = false,
                ["excludeLaunder"] = 
                {
                    [48] = false,
                    [33] = false,
                    [19] = false,
                    [4] = false,
                    [44] = false,
                    [7] = false,
                    [56] = false,
                    [9] = false,
                    [10] = false,
                    [30] = false,
                    [12] = false,
                    [29] = false,
                    [62] = false,
                    [58] = false,
                },
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["provisioning"] = 
                {
                    ["drink"] = true,
                    ["all"] = false,
                    ["recipeQuality"] = 2,
                    ["fullStack"] = false,
                    ["dish"] = true,
                    ["unusable"] = false,
                    ["recipe"] = false,
                    ["excludeRareAdditives"] = true,
                },
                ["fullStackBankPoisons"] = false,
                ["bot"] = 1,
                ["treasureMapsDestroy"] = false,
                ["destroyStolenQuality"] = 1,
                ["traitMaterial"] = 
                {
                    ["23221"] = false,
                    ["139412"] = false,
                    ["30221"] = false,
                    ["139409"] = false,
                    ["4486"] = false,
                    ["23204"] = false,
                    ["23165"] = false,
                    ["23173"] = false,
                    ["23203"] = false,
                    ["23149"] = false,
                    ["810"] = false,
                    ["23219"] = false,
                    ["4442"] = false,
                    ["139413"] = false,
                    ["135156"] = false,
                    ["135157"] = false,
                    ["139414"] = false,
                    ["135155"] = false,
                    ["30219"] = false,
                    ["4456"] = false,
                    ["139411"] = false,
                    ["23171"] = false,
                    ["139410"] = false,
                    ["813"] = false,
                    ["16291"] = false,
                },
                ["stolen"] = false,
                ["styleFullStack"] = false,
                ["dailyLoginPoisons"] = false,
                ["foodQuality"] = 1,
                ["trophy"] = false,
                ["useMemoryFirst"] = false,
                ["excludeStolenClothes"] = true,
                ["destroyValue"] = 0,
                ["fullStackBagPotions"] = false,
                ["keepPotionsLevel"] = 1,
                ["jewelryMasterWritsQuality"] = 3,
                ["museumPieces"] = false,
                ["crafting"] = 
                {
                    ["lowLevelClothingRawMaterials"] = false,
                    ["lowLevelClothingMaterials"] = false,
                    ["lowLevelBlacksmithingRawMaterials"] = false,
                    ["lowLevelWoodworkingMaterials"] = false,
                    ["lowLevelJewelryMaterials"] = false,
                    ["lowLevelWoodworkingRawMaterials"] = false,
                    ["lowLevelJewelryRawMaterials"] = false,
                    ["lowLevelBlacksmithingMaterials"] = false,
                },
                ["destroyStolenValue"] = 0,
                ["junkTraitSets"] = false,
                ["fullStackBankPoisonsSolvants"] = false,
                ["lureFullStack"] = false,
                ["emptyGems"] = false,
                ["styleMaterial"] = 
                {
                    ["33252"] = false,
                    ["33256"] = false,
                    ["33254"] = false,
                    ["33257"] = false,
                    ["46152"] = false,
                    ["33194"] = false,
                    ["33255"] = false,
                    ["46149"] = false,
                    ["33150"] = false,
                    ["46151"] = false,
                    ["46150"] = false,
                    ["33253"] = false,
                    ["33251"] = false,
                    ["33258"] = false,
                },
                ["treasures"] = false,
                ["dailyLoginFood"] = false,
                ["glyphsQuality"] = 1,
                ["furnishing"] = 
                {
                    ["decWax"] = false,
                    ["regulus"] = false,
                    ["alchResin"] = false,
                    ["mundRune"] = false,
                    ["bast"] = false,
                    ["heartwood"] = false,
                    ["cleanPelt"] = false,
                    ["ochre"] = false,
                },
                ["traitFullStack"] = false,
                ["jewelryMasterWrits"] = false,
                ["enchanting"] = 
                {
                    ["aspectQuality"] = 1,
                    ["essenceRunes"] = 
                    {
                        [1] = 
                        {
                            [2] = false,
                            [1] = "45839",
                        },
                        [2] = 
                        {
                            [2] = false,
                            [1] = "45833",
                        },
                        [3] = 
                        {
                            [2] = false,
                            [1] = "45836",
                        },
                        [4] = 
                        {
                            [2] = false,
                            [1] = "45842",
                        },
                        [5] = 
                        {
                            [2] = false,
                            [1] = "68342",
                        },
                        [6] = 
                        {
                            [2] = false,
                            [1] = "45841",
                        },
                        [7] = 
                        {
                            [2] = false,
                            [1] = "166045",
                        },
                        [8] = 
                        {
                            [2] = false,
                            [1] = "45849",
                        },
                        [9] = 
                        {
                            [2] = false,
                            [1] = "45837",
                        },
                        [10] = 
                        {
                            [2] = false,
                            [1] = "45848",
                        },
                        [11] = 
                        {
                            [2] = false,
                            [1] = "45832",
                        },
                        [12] = 
                        {
                            [2] = false,
                            [1] = "45835",
                        },
                        [13] = 
                        {
                            [2] = false,
                            [1] = "45840",
                        },
                        [14] = 
                        {
                            [2] = false,
                            [1] = "45831",
                        },
                        [15] = 
                        {
                            [2] = false,
                            [1] = "45834",
                        },
                        [16] = 
                        {
                            [2] = false,
                            [1] = "45843",
                        },
                        [17] = 
                        {
                            [2] = false,
                            [1] = "45846",
                        },
                        [18] = 
                        {
                            [2] = false,
                            [1] = "45838",
                        },
                        [19] = 
                        {
                            [2] = false,
                            [1] = "45847",
                        },
                    },
                    ["enchantingEssence"] = false,
                    ["potencyRunes"] = 
                    {
                        [1] = 
                        {
                            [2] = false,
                            [1] = "45812",
                        },
                        [2] = 
                        {
                            [2] = false,
                            [1] = "45814",
                        },
                        [3] = 
                        {
                            [2] = false,
                            [1] = "45822",
                        },
                        [4] = 
                        {
                            [2] = false,
                            [1] = "45809",
                        },
                        [5] = 
                        {
                            [2] = false,
                            [1] = "45825",
                        },
                        [6] = 
                        {
                            [2] = false,
                            [1] = "45826",
                        },
                        [7] = 
                        {
                            [2] = false,
                            [1] = "68340",
                        },
                        [8] = 
                        {
                            [2] = false,
                            [1] = "45810",
                        },
                        [9] = 
                        {
                            [2] = false,
                            [1] = "45821",
                        },
                        [10] = 
                        {
                            [2] = false,
                            [1] = "64508",
                        },
                        [11] = 
                        {
                            [2] = false,
                            [1] = "45806",
                        },
                        [12] = 
                        {
                            [2] = false,
                            [1] = "45857",
                        },
                        [13] = 
                        {
                            [2] = false,
                            [1] = "45855",
                        },
                        [14] = 
                        {
                            [2] = false,
                            [1] = "45828",
                        },
                        [15] = 
                        {
                            [2] = false,
                            [1] = "45830",
                        },
                        [16] = 
                        {
                            [2] = false,
                            [1] = "45816",
                        },
                        [17] = 
                        {
                            [2] = false,
                            [1] = "45818",
                        },
                        [18] = 
                        {
                            [2] = false,
                            [1] = "45819",
                        },
                        [19] = 
                        {
                            [2] = false,
                            [1] = "45807",
                        },
                        [20] = 
                        {
                            [2] = false,
                            [1] = "45827",
                        },
                        [21] = 
                        {
                            [2] = false,
                            [1] = "45823",
                        },
                        [22] = 
                        {
                            [2] = false,
                            [1] = "45508",
                        },
                        [23] = 
                        {
                            [2] = false,
                            [1] = "45811",
                        },
                        [24] = 
                        {
                            [2] = false,
                            [1] = "45856",
                        },
                        [25] = 
                        {
                            [2] = false,
                            [1] = "45829",
                        },
                        [26] = 
                        {
                            [2] = false,
                            [1] = "64509",
                        },
                        [27] = 
                        {
                            [2] = false,
                            [1] = "45824",
                        },
                        [28] = 
                        {
                            [2] = false,
                            [1] = "45815",
                        },
                        [29] = 
                        {
                            [2] = false,
                            [1] = "68341",
                        },
                        [30] = 
                        {
                            [2] = false,
                            [1] = "45813",
                        },
                        [31] = 
                        {
                            [2] = false,
                            [1] = "45820",
                        },
                    },
                    ["enchantingPotency"] = false,
                    ["aspectFullStack"] = false,
                    ["enchantingAspect"] = false,
                    ["essenceFullStack"] = false,
                    ["potencyFullStack"] = false,
                },
                ["trophies"] = false,
                ["dailyLoginPotions"] = false,
                ["lowStolen"] = 1,
                ["keepLevelGlyphs"] = 1,
                ["equipment"] = 
                {
                    ["wa"] = 
                    {
                        ["keepCyroA"] = true,
                        ["keepDungeon"] = true,
                        ["keepIC"] = true,
                        ["keepSpecial"] = true,
                        ["keepIntricate"] = true,
                        ["notrait"] = false,
                        ["keepNirnhoned"] = true,
                        ["disguisesDestroy"] = false,
                        ["ornateQuality"] = 2,
                        ["keepArenaWeapons"] = true,
                        ["whiteZeroValue"] = false,
                        ["keepResearchable"] = true,
                        ["ornate"] = true,
                        ["keepLevelOrnate"] = false,
                        ["keepCrafted"] = true,
                        ["keepBG"] = true,
                        ["keepTrial"] = true,
                        ["enabled"] = false,
                        ["keepOverland"] = true,
                        ["equipmentQuality"] = 1,
                        ["notraitQuality"] = 1,
                        ["keepIntricateIfNotMaxed"] = false,
                        ["disguises"] = false,
                        ["keepLevel"] = 1,
                        ["keepCyroW"] = true,
                        ["keepMonsterSets"] = true,
                        ["keepSetItems"] = true,
                    },
                    ["j"] = 
                    {
                        ["keepDungeon"] = true,
                        ["keepIC"] = true,
                        ["keepSpecial"] = true,
                        ["keepIntricate"] = true,
                        ["notrait"] = false,
                        ["keepCyro"] = true,
                        ["ornateQuality"] = 2,
                        ["ornate"] = true,
                        ["notraitQuality"] = 1,
                        ["keepCrafted"] = true,
                        ["keepBG"] = true,
                        ["keepTrial"] = true,
                        ["enabled"] = false,
                        ["keepOverland"] = true,
                        ["equipmentQuality"] = 1,
                        ["keepDRandIC"] = true,
                        ["whiteZeroValue"] = false,
                        ["keepLevelOrnate"] = false,
                        ["keepLevel"] = 1,
                        ["keepResearchable"] = true,
                        ["keepIntricateIfNotMaxed"] = false,
                        ["keepSetItems"] = true,
                    },
                },
                ["automaticScan"] = true,
                ["housingRecipes"] = false,
                ["dailyLoginDrink"] = false,
                ["destroyKeybind"] = false,
            },
        },
    },
}
Dustman_GlobalSavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["dailyLoginSoulGems"] = false,
                ["junkKeybind"] = false,
                ["stolenRecipeQuality"] = 2,
                ["housingRecipesQuality"] = 1,
                ["itemTraits"] = 
                {
                    [32] = false,
                    [1] = false,
                    [2] = false,
                    [3] = false,
                    [4] = false,
                    [5] = false,
                    [6] = false,
                    [7] = false,
                    [8] = false,
                    [11] = false,
                    [12] = false,
                    [13] = false,
                    [14] = false,
                    [15] = false,
                    [16] = false,
                    [17] = false,
                    [18] = false,
                    [21] = false,
                    [22] = false,
                    [23] = false,
                    [33] = false,
                    [28] = false,
                    [29] = false,
                    [30] = false,
                    [31] = false,
                },
                ["version"] = 2,
                ["lure"] = true,
                ["foodAll"] = true,
                ["useGlobalSettings"] = true,
                ["notifications"] = 
                {
                    ["sell"] = true,
                    ["total"] = true,
                    ["found"] = false,
                    ["allItems"] = false,
                    ["sellDialog"] = false,
                    ["verbose"] = false,
                },
                ["glyphs"] = false,
                ["fullStackBagPoisons"] = false,
                ["destroyNonLaundered"] = true,
                ["poisonsSolvants"] = false,
                ["potions"] = true,
                ["destroyQuality"] = 1,
                ["destroy"] = true,
                ["fullStackBagPoisonsSolvants"] = false,
                ["equipment"] = 
                {
                    ["wa"] = 
                    {
                        ["keepCyroA"] = true,
                        ["keepDungeon"] = true,
                        ["keepIC"] = true,
                        ["keepSpecial"] = true,
                        ["keepIntricate"] = true,
                        ["notrait"] = true,
                        ["keepNirnhoned"] = true,
                        ["disguisesDestroy"] = false,
                        ["ornateQuality"] = 2,
                        ["keepArenaWeapons"] = true,
                        ["whiteZeroValue"] = true,
                        ["keepResearchable"] = true,
                        ["ornate"] = true,
                        ["keepLevelOrnate"] = false,
                        ["keepCrafted"] = true,
                        ["keepBG"] = true,
                        ["keepTrial"] = true,
                        ["enabled"] = true,
                        ["keepOverland"] = true,
                        ["equipmentQuality"] = 2,
                        ["notraitQuality"] = 2,
                        ["keepIntricateIfNotMaxed"] = false,
                        ["disguises"] = false,
                        ["keepLevel"] = 1,
                        ["keepCyroW"] = true,
                        ["keepMonsterSets"] = true,
                        ["keepSetItems"] = true,
                    },
                    ["j"] = 
                    {
                        ["keepDungeon"] = true,
                        ["keepIC"] = true,
                        ["keepSpecial"] = true,
                        ["keepIntricate"] = true,
                        ["notrait"] = true,
                        ["keepCyro"] = true,
                        ["ornateQuality"] = 1,
                        ["ornate"] = true,
                        ["notraitQuality"] = 1,
                        ["keepCrafted"] = true,
                        ["keepBG"] = true,
                        ["keepTrial"] = true,
                        ["enabled"] = true,
                        ["keepOverland"] = true,
                        ["equipmentQuality"] = 1,
                        ["keepDRandIC"] = true,
                        ["whiteZeroValue"] = true,
                        ["keepLevelOrnate"] = false,
                        ["keepLevel"] = 1,
                        ["keepResearchable"] = true,
                        ["keepIntricateIfNotMaxed"] = false,
                        ["keepSetItems"] = true,
                    },
                },
                ["keepPoisonsLevel"] = 1,
                ["worldname"] = "EU Megaserver",
                ["destroyExcludeStackable"] = false,
                ["stolenQuality"] = 1,
                ["dailyLoginRepairKits"] = false,
                ["museumPiecesDestroy"] = false,
                ["lureFullStackBank"] = false,
                ["poisons"] = true,
                ["launder"] = true,
                ["dailyLoginDrinks"] = true,
                ["treasureMaps"] = false,
                ["memory"] = true,
                ["excludeLaunder"] = 
                {
                    [48] = true,
                    [33] = false,
                    [19] = false,
                    [4] = true,
                    [44] = false,
                    [7] = true,
                    [56] = false,
                    [9] = false,
                    [10] = false,
                    [30] = true,
                    [12] = true,
                    [29] = true,
                    [62] = false,
                    [58] = false,
                },
                ["provisioning"] = 
                {
                    ["drink"] = true,
                    ["all"] = true,
                    ["recipeQuality"] = 2,
                    ["fullStack"] = false,
                    ["dish"] = true,
                    ["unusable"] = false,
                    ["recipe"] = true,
                    ["excludeRareAdditives"] = true,
                },
                ["fullStackBankPoisons"] = false,
                ["bot"] = 3,
                ["treasureMapsDestroy"] = false,
                ["destroyStolenQuality"] = 1,
                ["traitMaterial"] = 
                {
                    ["23221"] = true,
                    ["139412"] = false,
                    ["30221"] = true,
                    ["139409"] = false,
                    ["4486"] = true,
                    ["23204"] = true,
                    ["23165"] = true,
                    ["23173"] = true,
                    ["23203"] = true,
                    ["23149"] = true,
                    ["810"] = true,
                    ["23219"] = true,
                    ["4442"] = true,
                    ["139413"] = false,
                    ["135156"] = false,
                    ["135157"] = false,
                    ["139414"] = false,
                    ["135155"] = false,
                    ["30219"] = true,
                    ["4456"] = true,
                    ["139411"] = false,
                    ["23171"] = true,
                    ["139410"] = false,
                    ["813"] = true,
                    ["16291"] = true,
                },
                ["stolen"] = true,
                ["styleFullStack"] = false,
                ["dailyLoginPoisons"] = false,
                ["foodQuality"] = 1,
                ["trophy"] = true,
                ["useMemoryFirst"] = false,
                ["excludeStolenClothes"] = true,
                ["destroyValue"] = 0,
                ["fullStackBagPotions"] = false,
                ["keepPotionsLevel"] = 1,
                ["jewelryMasterWritsQuality"] = 3,
                ["museumPieces"] = false,
                ["crafting"] = 
                {
                    ["lowLevelClothingRawMaterials"] = false,
                    ["lowLevelClothingMaterials"] = true,
                    ["lowLevelBlacksmithingRawMaterials"] = false,
                    ["lowLevelWoodworkingMaterials"] = true,
                    ["lowLevelJewelryMaterials"] = true,
                    ["lowLevelWoodworkingRawMaterials"] = false,
                    ["lowLevelJewelryRawMaterials"] = false,
                    ["lowLevelBlacksmithingMaterials"] = true,
                },
                ["destroyStolenValue"] = 0,
                ["fullStackBankPotions"] = false,
                ["fullStackBankPoisonsSolvants"] = false,
                ["lureFullStack"] = false,
                ["junkTraitSets"] = false,
                ["styleMaterial"] = 
                {
                    ["33252"] = false,
                    ["33256"] = false,
                    ["33254"] = false,
                    ["33257"] = false,
                    ["46152"] = false,
                    ["33194"] = false,
                    ["33255"] = false,
                    ["46149"] = false,
                    ["33150"] = false,
                    ["46151"] = false,
                    ["46150"] = false,
                    ["33253"] = false,
                    ["33251"] = false,
                    ["33258"] = false,
                },
                ["treasures"] = true,
                ["dailyLoginFood"] = true,
                ["glyphsQuality"] = 1,
                ["furnishing"] = 
                {
                    ["decWax"] = false,
                    ["regulus"] = false,
                    ["alchResin"] = false,
                    ["mundRune"] = false,
                    ["bast"] = false,
                    ["heartwood"] = false,
                    ["cleanPelt"] = false,
                    ["ochre"] = false,
                },
                ["traitFullStack"] = false,
                ["jewelryMasterWrits"] = false,
                ["enchanting"] = 
                {
                    ["aspectQuality"] = 1,
                    ["essenceRunes"] = 
                    {
                        [1] = 
                        {
                            [2] = false,
                            [1] = "45839",
                        },
                        [2] = 
                        {
                            [2] = false,
                            [1] = "45833",
                        },
                        [3] = 
                        {
                            [2] = false,
                            [1] = "45836",
                        },
                        [4] = 
                        {
                            [2] = false,
                            [1] = "45842",
                        },
                        [5] = 
                        {
                            [2] = false,
                            [1] = "68342",
                        },
                        [6] = 
                        {
                            [2] = false,
                            [1] = "45841",
                        },
                        [7] = 
                        {
                            [2] = false,
                            [1] = "166045",
                        },
                        [8] = 
                        {
                            [2] = false,
                            [1] = "45849",
                        },
                        [9] = 
                        {
                            [2] = false,
                            [1] = "45837",
                        },
                        [10] = 
                        {
                            [2] = false,
                            [1] = "45848",
                        },
                        [11] = 
                        {
                            [2] = false,
                            [1] = "45832",
                        },
                        [12] = 
                        {
                            [2] = false,
                            [1] = "45835",
                        },
                        [13] = 
                        {
                            [2] = false,
                            [1] = "45840",
                        },
                        [14] = 
                        {
                            [2] = false,
                            [1] = "45831",
                        },
                        [15] = 
                        {
                            [2] = false,
                            [1] = "45834",
                        },
                        [16] = 
                        {
                            [2] = false,
                            [1] = "45843",
                        },
                        [17] = 
                        {
                            [2] = false,
                            [1] = "45846",
                        },
                        [18] = 
                        {
                            [2] = false,
                            [1] = "45838",
                        },
                        [19] = 
                        {
                            [2] = false,
                            [1] = "45847",
                        },
                    },
                    ["enchantingEssence"] = false,
                    ["potencyRunes"] = 
                    {
                        [1] = 
                        {
                            [2] = false,
                            [1] = "45812",
                        },
                        [2] = 
                        {
                            [2] = false,
                            [1] = "45814",
                        },
                        [3] = 
                        {
                            [2] = false,
                            [1] = "45822",
                        },
                        [4] = 
                        {
                            [2] = false,
                            [1] = "45809",
                        },
                        [5] = 
                        {
                            [2] = false,
                            [1] = "45825",
                        },
                        [6] = 
                        {
                            [2] = false,
                            [1] = "45826",
                        },
                        [7] = 
                        {
                            [2] = false,
                            [1] = "68340",
                        },
                        [8] = 
                        {
                            [2] = false,
                            [1] = "45810",
                        },
                        [9] = 
                        {
                            [2] = false,
                            [1] = "45821",
                        },
                        [10] = 
                        {
                            [2] = false,
                            [1] = "64508",
                        },
                        [11] = 
                        {
                            [2] = false,
                            [1] = "45806",
                        },
                        [12] = 
                        {
                            [2] = false,
                            [1] = "45857",
                        },
                        [13] = 
                        {
                            [2] = false,
                            [1] = "45855",
                        },
                        [14] = 
                        {
                            [2] = false,
                            [1] = "45828",
                        },
                        [15] = 
                        {
                            [2] = false,
                            [1] = "45830",
                        },
                        [16] = 
                        {
                            [2] = false,
                            [1] = "45816",
                        },
                        [17] = 
                        {
                            [2] = false,
                            [1] = "45818",
                        },
                        [18] = 
                        {
                            [2] = false,
                            [1] = "45819",
                        },
                        [19] = 
                        {
                            [2] = false,
                            [1] = "45807",
                        },
                        [20] = 
                        {
                            [2] = false,
                            [1] = "45827",
                        },
                        [21] = 
                        {
                            [2] = false,
                            [1] = "45823",
                        },
                        [22] = 
                        {
                            [2] = false,
                            [1] = "45508",
                        },
                        [23] = 
                        {
                            [2] = false,
                            [1] = "45811",
                        },
                        [24] = 
                        {
                            [2] = false,
                            [1] = "45856",
                        },
                        [25] = 
                        {
                            [2] = false,
                            [1] = "45829",
                        },
                        [26] = 
                        {
                            [2] = false,
                            [1] = "64509",
                        },
                        [27] = 
                        {
                            [2] = false,
                            [1] = "45824",
                        },
                        [28] = 
                        {
                            [2] = false,
                            [1] = "45815",
                        },
                        [29] = 
                        {
                            [2] = false,
                            [1] = "68341",
                        },
                        [30] = 
                        {
                            [2] = false,
                            [1] = "45813",
                        },
                        [31] = 
                        {
                            [2] = false,
                            [1] = "45820",
                        },
                    },
                    ["enchantingPotency"] = false,
                    ["aspectFullStack"] = false,
                    ["enchantingAspect"] = false,
                    ["essenceFullStack"] = false,
                    ["potencyFullStack"] = false,
                },
                ["emptyGems"] = false,
                ["trophies"] = true,
                ["dailyLoginPotions"] = false,
                ["keepLevelGlyphs"] = 1,
                ["lowStolen"] = 1,
                ["automaticScan"] = true,
                ["housingRecipes"] = true,
                ["dailyLoginDrink"] = false,
                ["destroyKeybind"] = false,
            },
        },
    },
}
Dustman_Junk_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["version"] = 2,
            },
        },
    },
}
Dustman_Junk_GlobalSavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
            },
        },
    },
}
