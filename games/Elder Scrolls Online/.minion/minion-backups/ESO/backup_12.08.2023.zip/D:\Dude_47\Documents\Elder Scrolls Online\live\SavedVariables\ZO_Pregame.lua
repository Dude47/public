ZO_Pregame_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["CharacterSelect_Manager"] = 
                {
                    ["eventBannerLastSeenTimestamp"] = 1691691777,
                    ["version"] = 1,
                },
                ["ChapterUpgrade"] = 
                {
                    ["version"] = 1,
                    ["chapterUpgradeSeenVersion"] = 7,
                },
            },
        },
    },
}
