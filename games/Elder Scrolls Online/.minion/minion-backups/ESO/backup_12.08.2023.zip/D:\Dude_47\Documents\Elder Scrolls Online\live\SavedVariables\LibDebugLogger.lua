LibDebugLoggerSettings =
{
    ["minLogLevel"] = "I",
    ["loadScreenStartTime"] = 1691871448262,
    ["logTraces"] = false,
    ["version"] = 2,
}
LibDebugLoggerLog =
{
    [1] = 
    {
        [1] = 1691785714004,
        [2] = "2023-08-11 23:28:34.004 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-11 23:27:18.999 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nRussian\naddon count: 98/98\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [2] = 
    {
        [1] = 1691785715766,
        [2] = "2023-08-11 23:28:35.766 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [3] = 
    {
        [1] = 1691785715768,
        [2] = "2023-08-11 23:28:35.768 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [4] = 
    {
        [1] = 1691785715770,
        [2] = "2023-08-11 23:28:35.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [5] = 
    {
        [1] = 1691785715770,
        [2] = "2023-08-11 23:28:35.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [6] = 
    {
        [1] = 1691785715770,
        [2] = "2023-08-11 23:28:35.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [7] = 
    {
        [1] = 1691785715770,
        [2] = "2023-08-11 23:28:35.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [8] = 
    {
        [1] = 1691785715770,
        [2] = "2023-08-11 23:28:35.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [9] = 
    {
        [1] = 1691785715771,
        [2] = "2023-08-11 23:28:35.771 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [10] = 
    {
        [1] = 1691785715874,
        [2] = "2023-08-11 23:28:35.874 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [11] = 
    {
        [1] = 1691785715874,
        [2] = "2023-08-11 23:28:35.874 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [12] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [13] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [14] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [15] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [16] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [17] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [18] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [19] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [20] = 
    {
        [1] = 1691785715890,
        [2] = "2023-08-11 23:28:35.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/CharacterKnowledge/LibCharacterKnowledge/'",
        [7] = "",
    },
    [21] = 
    {
        [1] = 1691785715896,
        [2] = "2023-08-11 23:28:35.896 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [22] = 
    {
        [1] = 1691785715917,
        [2] = "2023-08-11 23:28:35.917 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [23] = 
    {
        [1] = 1691785715930,
        [2] = "2023-08-11 23:28:35.930 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantJunk, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantJunk/'",
        [7] = "",
    },
    [24] = 
    {
        [1] = 1691785715951,
        [2] = "2023-08-11 23:28:35.951 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [25] = 
    {
        [1] = 1691785715956,
        [2] = "2023-08-11 23:28:35.956 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [26] = 
    {
        [1] = 1691785715956,
        [2] = "2023-08-11 23:28:35.956 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [27] = 
    {
        [1] = 1691785715959,
        [2] = "2023-08-11 23:28:35.959 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [28] = 
    {
        [1] = 1691785715959,
        [2] = "2023-08-11 23:28:35.959 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [29] = 
    {
        [1] = 1691785715986,
        [2] = "2023-08-11 23:28:35.986 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [30] = 
    {
        [1] = 1691785715986,
        [2] = "2023-08-11 23:28:35.986 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [31] = 
    {
        [1] = 1691785715986,
        [2] = "2023-08-11 23:28:35.986 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [32] = 
    {
        [1] = 1691785716306,
        [2] = "2023-08-11 23:28:36.306 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [33] = 
    {
        [1] = 1691785716641,
        [2] = "2023-08-11 23:28:36.641 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [34] = 
    {
        [1] = 1691785716647,
        [2] = "2023-08-11 23:28:36.647 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [35] = 
    {
        [1] = 1691785716649,
        [2] = "2023-08-11 23:28:36.649 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [36] = 
    {
        [1] = 1691785716649,
        [2] = "2023-08-11 23:28:36.649 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [37] = 
    {
        [1] = 1691785716649,
        [2] = "2023-08-11 23:28:36.649 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [38] = 
    {
        [1] = 1691785716649,
        [2] = "2023-08-11 23:28:36.649 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [39] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [40] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [41] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [42] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [43] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [44] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [45] = 
    {
        [1] = 1691785716651,
        [2] = "2023-08-11 23:28:36.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [46] = 
    {
        [1] = 1691785716658,
        [2] = "2023-08-11 23:28:36.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [47] = 
    {
        [1] = 1691785716658,
        [2] = "2023-08-11 23:28:36.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [48] = 
    {
        [1] = 1691785716663,
        [2] = "2023-08-11 23:28:36.663 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [49] = 
    {
        [1] = 1691785716666,
        [2] = "2023-08-11 23:28:36.666 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [50] = 
    {
        [1] = 1691785716666,
        [2] = "2023-08-11 23:28:36.666 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [51] = 
    {
        [1] = 1691785716674,
        [2] = "2023-08-11 23:28:36.674 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [52] = 
    {
        [1] = 1691785716678,
        [2] = "2023-08-11 23:28:36.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [53] = 
    {
        [1] = 1691785716689,
        [2] = "2023-08-11 23:28:36.689 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [54] = 
    {
        [1] = 1691785716689,
        [2] = "2023-08-11 23:28:36.689 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [55] = 
    {
        [1] = 1691785716689,
        [2] = "2023-08-11 23:28:36.689 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [56] = 
    {
        [1] = 1691785716696,
        [2] = "2023-08-11 23:28:36.696 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [57] = 
    {
        [1] = 1691785716696,
        [2] = "2023-08-11 23:28:36.696 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [58] = 
    {
        [1] = 1691785716701,
        [2] = "2023-08-11 23:28:36.701 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/EventCollectibles/LibExtendedJournal/'",
        [7] = "",
    },
    [59] = 
    {
        [1] = 1691785716702,
        [2] = "2023-08-11 23:28:36.702 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [60] = 
    {
        [1] = 1691785716703,
        [2] = "2023-08-11 23:28:36.703 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [61] = 
    {
        [1] = 1691785717144,
        [2] = "2023-08-11 23:28:37.144 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [62] = 
    {
        [1] = 1691785717151,
        [2] = "2023-08-11 23:28:37.151 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [63] = 
    {
        [1] = 1691785717162,
        [2] = "2023-08-11 23:28:37.162 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [64] = 
    {
        [1] = 1691785717269,
        [2] = "2023-08-11 23:28:37.269 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [65] = 
    {
        [1] = 1691785717277,
        [2] = "2023-08-11 23:28:37.277 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [66] = 
    {
        [1] = 1691785717283,
        [2] = "2023-08-11 23:28:37.283 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [67] = 
    {
        [1] = 1691785717283,
        [2] = "2023-08-11 23:28:37.283 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [68] = 
    {
        [1] = 1691785717285,
        [2] = "2023-08-11 23:28:37.285 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [69] = 
    {
        [1] = 1691785717285,
        [2] = "2023-08-11 23:28:37.285 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [70] = 
    {
        [1] = 1691785717294,
        [2] = "2023-08-11 23:28:37.294 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [71] = 
    {
        [1] = 1691785717297,
        [2] = "2023-08-11 23:28:37.297 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [72] = 
    {
        [1] = 1691785717313,
        [2] = "2023-08-11 23:28:37.313 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [73] = 
    {
        [1] = 1691785717319,
        [2] = "2023-08-11 23:28:37.319 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [74] = 
    {
        [1] = 1691785717323,
        [2] = "2023-08-11 23:28:37.323 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [75] = 
    {
        [1] = 1691785717324,
        [2] = "2023-08-11 23:28:37.324 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [76] = 
    {
        [1] = 1691785717325,
        [2] = "2023-08-11 23:28:37.325 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [77] = 
    {
        [1] = 1691785717336,
        [2] = "2023-08-11 23:28:37.336 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [78] = 
    {
        [1] = 1691785717342,
        [2] = "2023-08-11 23:28:37.342 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [79] = 
    {
        [1] = 1691785717342,
        [2] = "2023-08-11 23:28:37.342 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [80] = 
    {
        [1] = 1691785717347,
        [2] = "2023-08-11 23:28:37.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [81] = 
    {
        [1] = 1691785717347,
        [2] = "2023-08-11 23:28:37.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [82] = 
    {
        [1] = 1691785717354,
        [2] = "2023-08-11 23:28:37.354 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [83] = 
    {
        [1] = 1691785717354,
        [2] = "2023-08-11 23:28:37.354 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [84] = 
    {
        [1] = 1691785717354,
        [2] = "2023-08-11 23:28:37.354 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [85] = 
    {
        [1] = 1691785717354,
        [2] = "2023-08-11 23:28:37.354 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [86] = 
    {
        [1] = 1691785717359,
        [2] = "2023-08-11 23:28:37.359 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [87] = 
    {
        [1] = 1691785717359,
        [2] = "2023-08-11 23:28:37.359 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [88] = 
    {
        [1] = 1691785717362,
        [2] = "2023-08-11 23:28:37.362 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [89] = 
    {
        [1] = 1691785717368,
        [2] = "2023-08-11 23:28:37.368 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [90] = 
    {
        [1] = 1691785717440,
        [2] = "2023-08-11 23:28:37.440 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [91] = 
    {
        [1] = 1691785717440,
        [2] = "2023-08-11 23:28:37.440 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [92] = 
    {
        [1] = 1691785717441,
        [2] = "2023-08-11 23:28:37.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [93] = 
    {
        [1] = 1691785717446,
        [2] = "2023-08-11 23:28:37.446 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [94] = 
    {
        [1] = 1691785717448,
        [2] = "2023-08-11 23:28:37.448 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [95] = 
    {
        [1] = 1691785717454,
        [2] = "2023-08-11 23:28:37.454 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [96] = 
    {
        [1] = 1691785717456,
        [2] = "2023-08-11 23:28:37.456 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [97] = 
    {
        [1] = 1691785717458,
        [2] = "2023-08-11 23:28:37.458 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [98] = 
    {
        [1] = 1691785717458,
        [2] = "2023-08-11 23:28:37.458 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [99] = 
    {
        [1] = 1691785717458,
        [2] = "2023-08-11 23:28:37.458 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [100] = 
    {
        [1] = 1691785717464,
        [2] = "2023-08-11 23:28:37.464 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [101] = 
    {
        [1] = 1691785717471,
        [2] = "2023-08-11 23:28:37.471 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [102] = 
    {
        [1] = 1691785717487,
        [2] = "2023-08-11 23:28:37.487 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [103] = 
    {
        [1] = 1691785717493,
        [2] = "2023-08-11 23:28:37.493 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [104] = 
    {
        [1] = 1691785717525,
        [2] = "2023-08-11 23:28:37.525 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [105] = 
    {
        [1] = 1691785717531,
        [2] = "2023-08-11 23:28:37.531 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [106] = 
    {
        [1] = 1691785717537,
        [2] = "2023-08-11 23:28:37.537 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [107] = 
    {
        [1] = 1691785717543,
        [2] = "2023-08-11 23:28:37.543 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [108] = 
    {
        [1] = 1691785717550,
        [2] = "2023-08-11 23:28:37.550 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [109] = 
    {
        [1] = 1691785717956,
        [2] = "2023-08-11 23:28:37.956 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: HarvestPins, AddOnVersion: 1, directory: 'user:/AddOns/HarvestPins/', state: missing dependency (missing: HarvestMap)",
        [7] = "",
    },
    [110] = 
    {
        [1] = 1691785717956,
        [2] = "2023-08-11 23:28:37.956 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 3.956s)",
        [7] = "",
    },
    [111] = 
    {
        [1] = 1691786061308,
        [2] = "2023-08-11 23:34:21.308 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500Delaying the Daggers:|r I should head to the west gate of Davon's Watch and speak with Holgunn.",
        [7] = "",
    },
    [112] = 
    {
        [1] = 1691786358574,
        [2] = "2023-08-11 23:39:18.574 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500City Under Siege:|r I should fight my way through Covenant forces to the tombs north of Davon's Watch and save Tanval Indoril.",
        [7] = "",
    },
    [113] = 
    {
        [1] = 1691786769810,
        [2] = "2023-08-11 23:46:09.810 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in combat.",
        [7] = "",
    },
    [114] = 
    {
        [1] = 1691786776939,
        [2] = "2023-08-11 23:46:16.939 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in combat.",
        [7] = "",
    },
    [115] = 
    {
        [1] = 1691786809303,
        [2] = "2023-08-11 23:46:49.303 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in this location.",
        [7] = "",
    },
    [116] = 
    {
        [1] = 1691786871716,
        [2] = "2023-08-11 23:47:51.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500Quiet the Ringing Bell:|r I should head west of Davon's Watch to Ash Mountain. There I should be able to find Tanval's son Garyn, who is already working to return the creature to the depths of the volcano.",
        [7] = "",
    },
    [117] = 
    {
        [1] = 1691787233522,
        [2] = "2023-08-11 23:53:53.522 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Your bank is full.",
        [7] = "",
    },
    [118] = 
    {
        [1] = 1691787243627,
        [2] = "2023-08-11 23:54:03.627 +0300",
        [3] = 3,
        [4] = "W",
        [5] = "UI",
        [6] = "Your bank is full.",
        [7] = "",
    },
    [119] = 
    {
        [1] = 1691787293599,
        [2] = "2023-08-11 23:54:53.599 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:54381:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 9|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [120] = 
    {
        [1] = 1691787293599,
        [2] = "2023-08-11 23:54:53.599 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 18x |H0:item:54384:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 162|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [121] = 
    {
        [1] = 1691787293599,
        [2] = "2023-08-11 23:54:53.599 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [122] = 
    {
        [1] = 1691787293600,
        [2] = "2023-08-11 23:54:53.600 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 4x |H0:item:54382:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 36|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [123] = 
    {
        [1] = 1691787293600,
        [2] = "2023-08-11 23:54:53.600 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 24 items (4 stacks) for 207|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [124] = 
    {
        [1] = 1691787293798,
        [2] = "2023-08-11 23:54:53.798 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [125] = 
    {
        [1] = 1691787297953,
        [2] = "2023-08-11 23:54:57.953 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [126] = 
    {
        [1] = 1691787298029,
        [2] = "2023-08-11 23:54:58.029 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [127] = 
    {
        [1] = 1691787406018,
        [2] = "2023-08-11 23:56:46.018 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Your bank is full.",
        [7] = "",
    },
    [128] = 
    {
        [1] = 1691787415688,
        [2] = "2023-08-11 23:56:55.688 +0300",
        [3] = 3,
        [4] = "W",
        [5] = "UI",
        [6] = "Your bank is full.",
        [7] = "",
    },
    [129] = 
    {
        [1] = 1691788429389,
        [2] = "2023-08-12 00:13:49.389 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "This quest cannot be shown on a map.",
        [7] = "",
    },
    [130] = 
    {
        [1] = 1691788533504,
        [2] = "2023-08-12 00:15:33.504 +0300",
        [3] = 2,
        [4] = "W",
        [5] = "UI",
        [6] = "This quest cannot be shown on a map.",
        [7] = "",
    },
    [131] = 
    {
        [1] = 1691788611179,
        [2] = "2023-08-12 00:16:51.179 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500The Harborage:|r The Prophet told me to seek him out in a place called the Harborage. I should seek out this place and speak to him.",
        [7] = "",
    },
    [132] = 
    {
        [1] = 1691789188428,
        [2] = "2023-08-12 00:26:28.428 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in this location.",
        [7] = "",
    },
    [133] = 
    {
        [1] = 1691789372432,
        [2] = "2023-08-12 00:29:32.432 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in this location.",
        [7] = "",
    },
    [134] = 
    {
        [1] = 1691790677041,
        [2] = "2023-08-12 00:51:17.041 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500Brothers and Bandits:|r The bandits in the ruins wouldn't let the brothers pass. They agreed to allow Dariel to venture into the ruins with the bandits, but he hasn't returned. I've agreed to search the ruins for him.",
        [7] = "",
    },
    [135] = 
    {
        [1] = 1691790870677,
        [2] = "2023-08-12 00:54:30.677 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You need the Persuasion Perk before you can choose this option",
        [7] = "",
    },
    [136] = 
    {
        [1] = 1691790969444,
        [2] = "2023-08-12 00:56:09.444 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Your inventory is full.",
        [7] = "",
    },
    [137] = 
    {
        [1] = 1691791722855,
        [2] = "2023-08-12 01:08:42.855 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Your inventory is full.",
        [7] = "",
    },
    [138] = 
    {
        [1] = 1691791823279,
        [2] = "2023-08-12 01:10:23.279 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Item not ready yet",
        [7] = "",
    },
    [139] = 
    {
        [1] = 1691791843702,
        [2] = "2023-08-12 01:10:43.702 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Item not ready yet",
        [7] = "",
    },
    [140] = 
    {
        [1] = 1691791921432,
        [2] = "2023-08-12 01:12:01.432 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in this location.",
        [7] = "",
    },
    [141] = 
    {
        [1] = 1691792094200,
        [2] = "2023-08-12 01:14:54.200 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount right now.",
        [7] = "",
    },
    [142] = 
    {
        [1] = 1691792277654,
        [2] = "2023-08-12 01:17:57.654 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Your bank is full.",
        [7] = "",
    },
    [143] = 
    {
        [1] = 1691792287131,
        [2] = "2023-08-12 01:18:07.131 +0300",
        [3] = 3,
        [4] = "W",
        [5] = "UI",
        [6] = "Your bank is full.",
        [7] = "",
    },
    [144] = 
    {
        [1] = 1691792427583,
        [2] = "2023-08-12 01:20:27.583 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You need 1 additional open inventory slot.",
        [7] = "",
    },
    [145] = 
    {
        [1] = 1691792467470,
        [2] = "2023-08-12 01:21:07.470 +0300",
        [3] = 5,
        [4] = "W",
        [5] = "UI",
        [6] = "You need 1 additional open inventory slot.",
        [7] = "",
    },
    [146] = 
    {
        [1] = 1691792486332,
        [2] = "2023-08-12 01:21:26.332 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43537:3:9:26580:3:9:0:0:0:0:0:0:0:0:0:4:0:0:0:9294:0|h|h for 20|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [147] = 
    {
        [1] = 1691792486333,
        [2] = "2023-08-12 01:21:26.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43531:2:17:0:0:0:0:0:0:0:0:0:0:0:0:2:0:0:0:0:0|h|h for 21|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [148] = 
    {
        [1] = 1691792486334,
        [2] = "2023-08-12 01:21:26.334 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:54388:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 9|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [149] = 
    {
        [1] = 1691792486335,
        [2] = "2023-08-12 01:21:26.335 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:76856:319:15:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:10000:0|h|h.",
        [7] = "",
    },
    [150] = 
    {
        [1] = 1691792486336,
        [2] = "2023-08-12 01:21:26.336 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [151] = 
    {
        [1] = 1691792486336,
        [2] = "2023-08-12 01:21:26.336 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43552:3:16:26588:3:16:0:0:0:0:0:0:0:0:0:1:0:0:0:10000:0|h|h for 13|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [152] = 
    {
        [1] = 1691792486338,
        [2] = "2023-08-12 01:21:26.338 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [153] = 
    {
        [1] = 1691792486341,
        [2] = "2023-08-12 01:21:26.341 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 6x |H0:item:54382:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 54|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [154] = 
    {
        [1] = 1691792486341,
        [2] = "2023-08-12 01:21:26.341 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43532:3:16:5365:3:16:0:0:0:0:0:0:0:0:0:4:0:0:0:250:0|h|h for 36|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [155] = 
    {
        [1] = 1691792486342,
        [2] = "2023-08-12 01:21:26.342 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45326:2:16:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:10000:0|h|h for 75|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [156] = 
    {
        [1] = 1691792486342,
        [2] = "2023-08-12 01:21:26.342 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45359:2:17:0:0:0:0:0:0:0:0:0:0:0:0:6:0:0:0:10000:0|h|h for 21|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [157] = 
    {
        [1] = 1691792486343,
        [2] = "2023-08-12 01:21:26.343 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45323:2:16:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:10000:0|h|h for 45|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [158] = 
    {
        [1] = 1691792486343,
        [2] = "2023-08-12 01:21:26.343 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43555:3:14:26582:3:14:0:0:0:0:0:0:0:0:0:9:0:0:0:9750:0|h|h for 11|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [159] = 
    {
        [1] = 1691792486344,
        [2] = "2023-08-12 01:21:26.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:84896:3:16:0:0:0:0:0:0:0:0:0:0:0:1:54:0:1:0:0:0|h|h for 22|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [160] = 
    {
        [1] = 1691792486345,
        [2] = "2023-08-12 01:21:26.345 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 4x |H0:item:54383:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 36|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [161] = 
    {
        [1] = 1691792486345,
        [2] = "2023-08-12 01:21:26.345 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43563:2:17:0:0:0:0:0:0:0:0:0:0:0:0:3:0:0:0:10000:0|h|h for 21|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [162] = 
    {
        [1] = 1691792486346,
        [2] = "2023-08-12 01:21:26.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:44458:9:9:0:0:0:0:0:0:0:0:0:0:0:1:5:0:1:0:70:0|h|h for 18|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [163] = 
    {
        [1] = 1691792486346,
        [2] = "2023-08-12 01:21:26.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45360:2:17:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:10000:0|h|h for 25|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [164] = 
    {
        [1] = 1691792486347,
        [2] = "2023-08-12 01:21:26.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45326:2:17:0:0:0:0:0:0:0:0:0:0:0:0:9:0:0:0:10000:0|h|h for 80|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [165] = 
    {
        [1] = 1691792486347,
        [2] = "2023-08-12 01:21:26.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:85115:3:17:0:0:0:0:0:0:0:0:0:0:0:1:7:0:1:0:10000:0|h|h for 13|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [166] = 
    {
        [1] = 1691792486348,
        [2] = "2023-08-12 01:21:26.348 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45309:2:17:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:10000:0|h|h for 96|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [167] = 
    {
        [1] = 1691792486348,
        [2] = "2023-08-12 01:21:26.348 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:99711:3:17:0:0:0:0:0:0:0:0:0:0:0:0:8:0:0:0:10000:0|h|h for 13|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [168] = 
    {
        [1] = 1691792486349,
        [2] = "2023-08-12 01:21:26.349 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 30 items (22 stacks) for 629|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [169] = 
    {
        [1] = 1691792486449,
        [2] = "2023-08-12 01:21:26.449 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [170] = 
    {
        [1] = 1691792488372,
        [2] = "2023-08-12 01:21:28.372 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [171] = 
    {
        [1] = 1691792488373,
        [2] = "2023-08-12 01:21:28.373 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [172] = 
    {
        [1] = 1691792498769,
        [2] = "2023-08-12 01:21:38.769 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [173] = 
    {
        [1] = 1691792498770,
        [2] = "2023-08-12 01:21:38.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [174] = 
    {
        [1] = 1691792498844,
        [2] = "2023-08-12 01:21:38.844 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [175] = 
    {
        [1] = 1691792499588,
        [2] = "2023-08-12 01:21:39.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [176] = 
    {
        [1] = 1691792499589,
        [2] = "2023-08-12 01:21:39.589 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [177] = 
    {
        [1] = 1691792586730,
        [2] = "2023-08-12 01:23:06.730 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [178] = 
    {
        [1] = 1691792586731,
        [2] = "2023-08-12 01:23:06.731 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [179] = 
    {
        [1] = 1691792586843,
        [2] = "2023-08-12 01:23:06.843 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [180] = 
    {
        [1] = 1691792587961,
        [2] = "2023-08-12 01:23:07.961 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [181] = 
    {
        [1] = 1691792587962,
        [2] = "2023-08-12 01:23:07.962 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [182] = 
    {
        [1] = 1691793027325,
        [2] = "2023-08-12 01:30:27.325 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [183] = 
    {
        [1] = 1691793027326,
        [2] = "2023-08-12 01:30:27.326 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [184] = 
    {
        [1] = 1691793027420,
        [2] = "2023-08-12 01:30:27.420 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [185] = 
    {
        [1] = 1691793029882,
        [2] = "2023-08-12 01:30:29.882 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [186] = 
    {
        [1] = 1691793029883,
        [2] = "2023-08-12 01:30:29.883 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [187] = 
    {
        [1] = 1691793058632,
        [2] = "2023-08-12 01:30:58.632 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [188] = 
    {
        [1] = 1691793058633,
        [2] = "2023-08-12 01:30:58.633 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [189] = 
    {
        [1] = 1691793058726,
        [2] = "2023-08-12 01:30:58.726 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [190] = 
    {
        [1] = 1691793314987,
        [2] = "2023-08-12 01:35:14.987 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [191] = 
    {
        [1] = 1691793314988,
        [2] = "2023-08-12 01:35:14.988 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [192] = 
    {
        [1] = 1691793315080,
        [2] = "2023-08-12 01:35:15.080 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [193] = 
    {
        [1] = 1691793316684,
        [2] = "2023-08-12 01:35:16.684 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [194] = 
    {
        [1] = 1691793316685,
        [2] = "2023-08-12 01:35:16.685 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [195] = 
    {
        [1] = 1691793424444,
        [2] = "2023-08-12 01:37:04.444 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [196] = 
    {
        [1] = 1691793452945,
        [2] = "2023-08-12 01:37:32.945 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [197] = 
    {
        [1] = 1691793452946,
        [2] = "2023-08-12 01:37:32.946 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [198] = 
    {
        [1] = 1691793453016,
        [2] = "2023-08-12 01:37:33.016 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "That item cannot be sold.",
        [7] = "",
    },
    [199] = 
    {
        [1] = 1691793455222,
        [2] = "2023-08-12 01:37:35.222 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:178493:3:3:0:0:0:0:0:0:0:0:0:0:0:1:0:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [200] = 
    {
        [1] = 1691793455223,
        [2] = "2023-08-12 01:37:35.223 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:43056:175:1:0:0:0:0:0:0:0:0:0:0:0:1:36:0:1:0:0:0|h|h.",
        [7] = "",
    },
    [201] = 
    {
        [1] = 1691793623389,
        [2] = "2023-08-12 01:40:23.389 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500Divine Conundrum:|r I should travel to Vvardenfell, in Morrowind, and locate Canon Llevule of the Tribunal outside the town of Seyda Neen.",
        [7] = "",
    },
    [202] = 
    {
        [1] = 1691793853411,
        [2] = "2023-08-12 01:44:13.411 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Not a member of any guild.",
        [7] = "",
    },
    [203] = 
    {
        [1] = 1691793857075,
        [2] = "2023-08-12 01:44:17.075 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Not a member of any guild.",
        [7] = "",
    },
    [204] = 
    {
        [1] = 1691794116399,
        [2] = "2023-08-12 01:48:36.399 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "Item not ready yet",
        [7] = "",
    },
    [205] = 
    {
        [1] = 1691795155694,
        [2] = "2023-08-12 02:05:55.694 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in combat.",
        [7] = "",
    },
    [206] = 
    {
        [1] = 1691795163354,
        [2] = "2023-08-12 02:06:03.354 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in combat.",
        [7] = "",
    },
    [207] = 
    {
        [1] = 1691796541225,
        [2] = "2023-08-12 02:29:01.225 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [208] = 
    {
        [1] = 1691851373002,
        [2] = "2023-08-12 17:42:53.002 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 17:42:13.048 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 111/111\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [209] = 
    {
        [1] = 1691851375470,
        [2] = "2023-08-12 17:42:55.470 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [210] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [211] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [212] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [213] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [214] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [215] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [216] = 
    {
        [1] = 1691851375473,
        [2] = "2023-08-12 17:42:55.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [217] = 
    {
        [1] = 1691851375607,
        [2] = "2023-08-12 17:42:55.607 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [218] = 
    {
        [1] = 1691851375607,
        [2] = "2023-08-12 17:42:55.607 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [219] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [220] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [221] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [222] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [223] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [224] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [225] = 
    {
        [1] = 1691851375628,
        [2] = "2023-08-12 17:42:55.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [226] = 
    {
        [1] = 1691851375634,
        [2] = "2023-08-12 17:42:55.634 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [227] = 
    {
        [1] = 1691851375651,
        [2] = "2023-08-12 17:42:55.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [228] = 
    {
        [1] = 1691851375651,
        [2] = "2023-08-12 17:42:55.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [229] = 
    {
        [1] = 1691851375651,
        [2] = "2023-08-12 17:42:55.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [230] = 
    {
        [1] = 1691851375651,
        [2] = "2023-08-12 17:42:55.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [231] = 
    {
        [1] = 1691851375651,
        [2] = "2023-08-12 17:42:55.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [232] = 
    {
        [1] = 1691851375657,
        [2] = "2023-08-12 17:42:55.657 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [233] = 
    {
        [1] = 1691851375664,
        [2] = "2023-08-12 17:42:55.664 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [234] = 
    {
        [1] = 1691851375664,
        [2] = "2023-08-12 17:42:55.664 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [235] = 
    {
        [1] = 1691851375664,
        [2] = "2023-08-12 17:42:55.664 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [236] = 
    {
        [1] = 1691851375670,
        [2] = "2023-08-12 17:42:55.670 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [237] = 
    {
        [1] = 1691851375670,
        [2] = "2023-08-12 17:42:55.670 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [238] = 
    {
        [1] = 1691851375670,
        [2] = "2023-08-12 17:42:55.670 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [239] = 
    {
        [1] = 1691851375670,
        [2] = "2023-08-12 17:42:55.670 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [240] = 
    {
        [1] = 1691851375676,
        [2] = "2023-08-12 17:42:55.676 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/EventCollectibles/LibExtendedJournal/'",
        [7] = "",
    },
    [241] = 
    {
        [1] = 1691851375677,
        [2] = "2023-08-12 17:42:55.677 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [242] = 
    {
        [1] = 1691851375678,
        [2] = "2023-08-12 17:42:55.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [243] = 
    {
        [1] = 1691851375678,
        [2] = "2023-08-12 17:42:55.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [244] = 
    {
        [1] = 1691851376413,
        [2] = "2023-08-12 17:42:56.413 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [245] = 
    {
        [1] = 1691851376428,
        [2] = "2023-08-12 17:42:56.428 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [246] = 
    {
        [1] = 1691851376441,
        [2] = "2023-08-12 17:42:56.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [247] = 
    {
        [1] = 1691851376446,
        [2] = "2023-08-12 17:42:56.446 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [248] = 
    {
        [1] = 1691851376677,
        [2] = "2023-08-12 17:42:56.677 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [249] = 
    {
        [1] = 1691851376701,
        [2] = "2023-08-12 17:42:56.701 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [250] = 
    {
        [1] = 1691851376701,
        [2] = "2023-08-12 17:42:56.701 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [251] = 
    {
        [1] = 1691851376712,
        [2] = "2023-08-12 17:42:56.712 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [252] = 
    {
        [1] = 1691851376732,
        [2] = "2023-08-12 17:42:56.732 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [253] = 
    {
        [1] = 1691851376747,
        [2] = "2023-08-12 17:42:56.747 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [254] = 
    {
        [1] = 1691851376747,
        [2] = "2023-08-12 17:42:56.747 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [255] = 
    {
        [1] = 1691851376747,
        [2] = "2023-08-12 17:42:56.747 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [256] = 
    {
        [1] = 1691851376754,
        [2] = "2023-08-12 17:42:56.754 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [257] = 
    {
        [1] = 1691851376768,
        [2] = "2023-08-12 17:42:56.768 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [258] = 
    {
        [1] = 1691851376768,
        [2] = "2023-08-12 17:42:56.768 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [259] = 
    {
        [1] = 1691851376768,
        [2] = "2023-08-12 17:42:56.768 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [260] = 
    {
        [1] = 1691851376768,
        [2] = "2023-08-12 17:42:56.768 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [261] = 
    {
        [1] = 1691851376768,
        [2] = "2023-08-12 17:42:56.768 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [262] = 
    {
        [1] = 1691851376773,
        [2] = "2023-08-12 17:42:56.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [263] = 
    {
        [1] = 1691851377339,
        [2] = "2023-08-12 17:42:57.339 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [264] = 
    {
        [1] = 1691851377485,
        [2] = "2023-08-12 17:42:57.485 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [265] = 
    {
        [1] = 1691851377485,
        [2] = "2023-08-12 17:42:57.485 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [266] = 
    {
        [1] = 1691851377485,
        [2] = "2023-08-12 17:42:57.485 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [267] = 
    {
        [1] = 1691851377492,
        [2] = "2023-08-12 17:42:57.492 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [268] = 
    {
        [1] = 1691851377567,
        [2] = "2023-08-12 17:42:57.567 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [269] = 
    {
        [1] = 1691851377577,
        [2] = "2023-08-12 17:42:57.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [270] = 
    {
        [1] = 1691851377583,
        [2] = "2023-08-12 17:42:57.583 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [271] = 
    {
        [1] = 1691851377587,
        [2] = "2023-08-12 17:42:57.587 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [272] = 
    {
        [1] = 1691851377587,
        [2] = "2023-08-12 17:42:57.587 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [273] = 
    {
        [1] = 1691851377598,
        [2] = "2023-08-12 17:42:57.598 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [274] = 
    {
        [1] = 1691851377604,
        [2] = "2023-08-12 17:42:57.604 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [275] = 
    {
        [1] = 1691851377861,
        [2] = "2023-08-12 17:42:57.861 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [276] = 
    {
        [1] = 1691851377862,
        [2] = "2023-08-12 17:42:57.862 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [277] = 
    {
        [1] = 1691851378476,
        [2] = "2023-08-12 17:42:58.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [278] = 
    {
        [1] = 1691851378476,
        [2] = "2023-08-12 17:42:58.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [279] = 
    {
        [1] = 1691851378481,
        [2] = "2023-08-12 17:42:58.481 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [280] = 
    {
        [1] = 1691851378490,
        [2] = "2023-08-12 17:42:58.490 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [281] = 
    {
        [1] = 1691851378501,
        [2] = "2023-08-12 17:42:58.501 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [282] = 
    {
        [1] = 1691851378521,
        [2] = "2023-08-12 17:42:58.521 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [283] = 
    {
        [1] = 1691851378533,
        [2] = "2023-08-12 17:42:58.533 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [284] = 
    {
        [1] = 1691851378548,
        [2] = "2023-08-12 17:42:58.548 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [285] = 
    {
        [1] = 1691851378890,
        [2] = "2023-08-12 17:42:58.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [286] = 
    {
        [1] = 1691851378890,
        [2] = "2023-08-12 17:42:58.890 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [287] = 
    {
        [1] = 1691851378912,
        [2] = "2023-08-12 17:42:58.912 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [288] = 
    {
        [1] = 1691851378912,
        [2] = "2023-08-12 17:42:58.912 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [289] = 
    {
        [1] = 1691851378925,
        [2] = "2023-08-12 17:42:58.925 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [290] = 
    {
        [1] = 1691851378944,
        [2] = "2023-08-12 17:42:58.944 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [291] = 
    {
        [1] = 1691851378944,
        [2] = "2023-08-12 17:42:58.944 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [292] = 
    {
        [1] = 1691851378986,
        [2] = "2023-08-12 17:42:58.986 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [293] = 
    {
        [1] = 1691851379016,
        [2] = "2023-08-12 17:42:59.016 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [294] = 
    {
        [1] = 1691851379016,
        [2] = "2023-08-12 17:42:59.016 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [295] = 
    {
        [1] = 1691851379028,
        [2] = "2023-08-12 17:42:59.028 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [296] = 
    {
        [1] = 1691851379035,
        [2] = "2023-08-12 17:42:59.035 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [297] = 
    {
        [1] = 1691851379103,
        [2] = "2023-08-12 17:42:59.103 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [298] = 
    {
        [1] = 1691851379109,
        [2] = "2023-08-12 17:42:59.109 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [299] = 
    {
        [1] = 1691851379122,
        [2] = "2023-08-12 17:42:59.122 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [300] = 
    {
        [1] = 1691851379130,
        [2] = "2023-08-12 17:42:59.130 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [301] = 
    {
        [1] = 1691851379143,
        [2] = "2023-08-12 17:42:59.143 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [302] = 
    {
        [1] = 1691851379149,
        [2] = "2023-08-12 17:42:59.149 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantJunk, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantJunk/'",
        [7] = "",
    },
    [303] = 
    {
        [1] = 1691851379197,
        [2] = "2023-08-12 17:42:59.197 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [304] = 
    {
        [1] = 1691851379197,
        [2] = "2023-08-12 17:42:59.197 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [305] = 
    {
        [1] = 1691851379197,
        [2] = "2023-08-12 17:42:59.197 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [306] = 
    {
        [1] = 1691851379198,
        [2] = "2023-08-12 17:42:59.198 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [307] = 
    {
        [1] = 1691851379211,
        [2] = "2023-08-12 17:42:59.211 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [308] = 
    {
        [1] = 1691851379218,
        [2] = "2023-08-12 17:42:59.218 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [309] = 
    {
        [1] = 1691851379557,
        [2] = "2023-08-12 17:42:59.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [310] = 
    {
        [1] = 1691851379566,
        [2] = "2023-08-12 17:42:59.566 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [311] = 
    {
        [1] = 1691851384659,
        [2] = "2023-08-12 17:43:04.659 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [312] = 
    {
        [1] = 1691851384672,
        [2] = "2023-08-12 17:43:04.672 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [313] = 
    {
        [1] = 1691851384672,
        [2] = "2023-08-12 17:43:04.672 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [314] = 
    {
        [1] = 1691851384672,
        [2] = "2023-08-12 17:43:04.672 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [315] = 
    {
        [1] = 1691851384678,
        [2] = "2023-08-12 17:43:04.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [316] = 
    {
        [1] = 1691851384688,
        [2] = "2023-08-12 17:43:04.688 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [317] = 
    {
        [1] = 1691851384693,
        [2] = "2023-08-12 17:43:04.693 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [318] = 
    {
        [1] = 1691851384733,
        [2] = "2023-08-12 17:43:04.733 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [319] = 
    {
        [1] = 1691851384758,
        [2] = "2023-08-12 17:43:04.758 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [320] = 
    {
        [1] = 1691851384780,
        [2] = "2023-08-12 17:43:04.780 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [321] = 
    {
        [1] = 1691851384780,
        [2] = "2023-08-12 17:43:04.780 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [322] = 
    {
        [1] = 1691851384797,
        [2] = "2023-08-12 17:43:04.797 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [323] = 
    {
        [1] = 1691851384804,
        [2] = "2023-08-12 17:43:04.804 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [324] = 
    {
        [1] = 1691851384804,
        [2] = "2023-08-12 17:43:04.804 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [325] = 
    {
        [1] = 1691851384924,
        [2] = "2023-08-12 17:43:04.924 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [326] = 
    {
        [1] = 1691851384983,
        [2] = "2023-08-12 17:43:04.983 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [327] = 
    {
        [1] = 1691851385762,
        [2] = "2023-08-12 17:43:05.762 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/', state: missing dependency (missing: LibMarify)",
        [7] = "",
    },
    [328] = 
    {
        [1] = 1691851385762,
        [2] = "2023-08-12 17:43:05.762 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/', state: missing dependency (missing: LibMarify)",
        [7] = "",
    },
    [329] = 
    {
        [1] = 1691851385762,
        [2] = "2023-08-12 17:43:05.762 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: HarvestPins, AddOnVersion: 1, directory: 'user:/AddOns/HarvestPins/', state: missing dependency (missing: HarvestMap)",
        [7] = "",
    },
    [330] = 
    {
        [1] = 1691851385762,
        [2] = "2023-08-12 17:43:05.762 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.762s)",
        [7] = "",
    },
    [331] = 
    {
        [1] = 1691853377354,
        [2] = "2023-08-12 18:16:17.354 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters] ERROR - ApplyFilter: FilterType at inventory '1'  was nil!\nTag 'AF_ButtonFilter', button 'All', filterType: 'nil', groupName: 'All'",
        [7] = "",
    },
    [332] = 
    {
        [1] = 1691853377354,
        [2] = "2023-08-12 18:16:17.354 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [333] = 
    {
        [1] = 1691853377355,
        [2] = "2023-08-12 18:16:17.355 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters]AF_FilterBar:ActivateButton: All",
        [7] = "",
    },
    [334] = 
    {
        [1] = 1691853377355,
        [2] = "2023-08-12 18:16:17.355 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = ">ERROR - filterPanelId is NIL!",
        [7] = "",
    },
    [335] = 
    {
        [1] = 1691853377355,
        [2] = "2023-08-12 18:16:17.355 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [336] = 
    {
        [1] = 1691853380384,
        [2] = "2023-08-12 18:16:20.384 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters] ERROR - ApplyFilter: FilterType at inventory '1'  was nil!\nTag 'AF_ButtonFilter', button 'All', filterType: 'nil', groupName: 'All'",
        [7] = "",
    },
    [337] = 
    {
        [1] = 1691853380385,
        [2] = "2023-08-12 18:16:20.385 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [338] = 
    {
        [1] = 1691853380385,
        [2] = "2023-08-12 18:16:20.385 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters]AF_FilterBar:ActivateButton: All",
        [7] = "",
    },
    [339] = 
    {
        [1] = 1691853380385,
        [2] = "2023-08-12 18:16:20.385 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = ">ERROR - filterPanelId is NIL!",
        [7] = "",
    },
    [340] = 
    {
        [1] = 1691853380385,
        [2] = "2023-08-12 18:16:20.385 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [341] = 
    {
        [1] = 1691854991982,
        [2] = "2023-08-12 18:43:11.982 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your Storage Coffer, Fortified.",
        [7] = "",
    },
    [342] = 
    {
        [1] = 1691855173256,
        [2] = "2023-08-12 18:46:13.256 +0300",
        [3] = 7,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your Storage Coffer, Fortified.",
        [7] = "",
    },
    [343] = 
    {
        [1] = 1691855752774,
        [2] = "2023-08-12 18:55:52.774 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "|cFFA500Tales of Tribute:|r If I want to learn more about the card game, Tales of Tribute, I need to speak to someone named Brahgas in Gonfalon Bay.",
        [7] = "",
    },
    [344] = 
    {
        [1] = 1691856690258,
        [2] = "2023-08-12 19:11:30.258 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't swap these in combat.",
        [7] = "",
    },
    [345] = 
    {
        [1] = 1691857158614,
        [2] = "2023-08-12 19:19:18.614 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You can't mount in combat.",
        [7] = "",
    },
    [346] = 
    {
        [1] = 1691858985714,
        [2] = "2023-08-12 19:49:45.714 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [347] = 
    {
        [1] = 1691858998696,
        [2] = "2023-08-12 19:49:58.696 +0300",
        [3] = 3,
        [4] = "W",
        [5] = "UI",
        [6] = "You may not deposit that item in your bank.",
        [7] = "",
    },
    [348] = 
    {
        [1] = 1691859154304,
        [2] = "2023-08-12 19:52:34.304 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 5x |H0:item:54384:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 45|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [349] = 
    {
        [1] = 1691859154305,
        [2] = "2023-08-12 19:52:34.305 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45305:2:18:0:0:0:0:0:0:0:0:0:0:0:0:7:0:0:0:10000:0|h|h for 96|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [350] = 
    {
        [1] = 1691859154305,
        [2] = "2023-08-12 19:52:34.305 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:54387:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 9|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [351] = 
    {
        [1] = 1691859154306,
        [2] = "2023-08-12 19:52:34.306 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:54385:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 9|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [352] = 
    {
        [1] = 1691859154306,
        [2] = "2023-08-12 19:52:34.306 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 1x |H0:item:45314:2:18:0:0:0:0:0:0:0:0:0:0:0:0:1:0:0:0:10000:0|h|h for 48|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [353] = 
    {
        [1] = 1691859154306,
        [2] = "2023-08-12 19:52:34.306 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 2x |H0:item:54383:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h for 18|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [354] = 
    {
        [1] = 1691859154307,
        [2] = "2023-08-12 19:52:34.307 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "Dustman sold 11 items (6 stacks) for 225|t16:16:EsoUI/Art/currency/currency_gold.dds|t.",
        [7] = "",
    },
    [355] = 
    {
        [1] = 1691862468003,
        [2] = "2023-08-12 20:47:48.003 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 20:47:18.722 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 111/111\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [356] = 
    {
        [1] = 1691862470507,
        [2] = "2023-08-12 20:47:50.507 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [357] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [358] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [359] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [360] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [361] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [362] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [363] = 
    {
        [1] = 1691862470510,
        [2] = "2023-08-12 20:47:50.510 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [364] = 
    {
        [1] = 1691862470569,
        [2] = "2023-08-12 20:47:50.569 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [365] = 
    {
        [1] = 1691862470570,
        [2] = "2023-08-12 20:47:50.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [366] = 
    {
        [1] = 1691862470576,
        [2] = "2023-08-12 20:47:50.576 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [367] = 
    {
        [1] = 1691862470577,
        [2] = "2023-08-12 20:47:50.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [368] = 
    {
        [1] = 1691862470577,
        [2] = "2023-08-12 20:47:50.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [369] = 
    {
        [1] = 1691862470577,
        [2] = "2023-08-12 20:47:50.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [370] = 
    {
        [1] = 1691862470577,
        [2] = "2023-08-12 20:47:50.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [371] = 
    {
        [1] = 1691862470577,
        [2] = "2023-08-12 20:47:50.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [372] = 
    {
        [1] = 1691862470577,
        [2] = "2023-08-12 20:47:50.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [373] = 
    {
        [1] = 1691862470582,
        [2] = "2023-08-12 20:47:50.582 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [374] = 
    {
        [1] = 1691862470588,
        [2] = "2023-08-12 20:47:50.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [375] = 
    {
        [1] = 1691862470588,
        [2] = "2023-08-12 20:47:50.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [376] = 
    {
        [1] = 1691862470588,
        [2] = "2023-08-12 20:47:50.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [377] = 
    {
        [1] = 1691862470588,
        [2] = "2023-08-12 20:47:50.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [378] = 
    {
        [1] = 1691862470588,
        [2] = "2023-08-12 20:47:50.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [379] = 
    {
        [1] = 1691862470594,
        [2] = "2023-08-12 20:47:50.594 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [380] = 
    {
        [1] = 1691862470597,
        [2] = "2023-08-12 20:47:50.597 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [381] = 
    {
        [1] = 1691862470597,
        [2] = "2023-08-12 20:47:50.597 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [382] = 
    {
        [1] = 1691862470597,
        [2] = "2023-08-12 20:47:50.597 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [383] = 
    {
        [1] = 1691862470601,
        [2] = "2023-08-12 20:47:50.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [384] = 
    {
        [1] = 1691862470601,
        [2] = "2023-08-12 20:47:50.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [385] = 
    {
        [1] = 1691862470601,
        [2] = "2023-08-12 20:47:50.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [386] = 
    {
        [1] = 1691862470601,
        [2] = "2023-08-12 20:47:50.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [387] = 
    {
        [1] = 1691862470606,
        [2] = "2023-08-12 20:47:50.606 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/EventCollectibles/LibExtendedJournal/'",
        [7] = "",
    },
    [388] = 
    {
        [1] = 1691862470606,
        [2] = "2023-08-12 20:47:50.606 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [389] = 
    {
        [1] = 1691862470606,
        [2] = "2023-08-12 20:47:50.606 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [390] = 
    {
        [1] = 1691862470606,
        [2] = "2023-08-12 20:47:50.606 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [391] = 
    {
        [1] = 1691862471428,
        [2] = "2023-08-12 20:47:51.428 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [392] = 
    {
        [1] = 1691862471442,
        [2] = "2023-08-12 20:47:51.442 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [393] = 
    {
        [1] = 1691862471454,
        [2] = "2023-08-12 20:47:51.454 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [394] = 
    {
        [1] = 1691862471459,
        [2] = "2023-08-12 20:47:51.459 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [395] = 
    {
        [1] = 1691862471692,
        [2] = "2023-08-12 20:47:51.692 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [396] = 
    {
        [1] = 1691862471718,
        [2] = "2023-08-12 20:47:51.718 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [397] = 
    {
        [1] = 1691862471718,
        [2] = "2023-08-12 20:47:51.718 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [398] = 
    {
        [1] = 1691862471726,
        [2] = "2023-08-12 20:47:51.726 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [399] = 
    {
        [1] = 1691862471748,
        [2] = "2023-08-12 20:47:51.748 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [400] = 
    {
        [1] = 1691862471762,
        [2] = "2023-08-12 20:47:51.762 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [401] = 
    {
        [1] = 1691862471762,
        [2] = "2023-08-12 20:47:51.762 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [402] = 
    {
        [1] = 1691862471762,
        [2] = "2023-08-12 20:47:51.762 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [403] = 
    {
        [1] = 1691862471769,
        [2] = "2023-08-12 20:47:51.769 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [404] = 
    {
        [1] = 1691862471782,
        [2] = "2023-08-12 20:47:51.782 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [405] = 
    {
        [1] = 1691862471782,
        [2] = "2023-08-12 20:47:51.782 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [406] = 
    {
        [1] = 1691862471782,
        [2] = "2023-08-12 20:47:51.782 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [407] = 
    {
        [1] = 1691862471782,
        [2] = "2023-08-12 20:47:51.782 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [408] = 
    {
        [1] = 1691862471782,
        [2] = "2023-08-12 20:47:51.782 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [409] = 
    {
        [1] = 1691862471787,
        [2] = "2023-08-12 20:47:51.787 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [410] = 
    {
        [1] = 1691862472216,
        [2] = "2023-08-12 20:47:52.216 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [411] = 
    {
        [1] = 1691862472320,
        [2] = "2023-08-12 20:47:52.320 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [412] = 
    {
        [1] = 1691862472320,
        [2] = "2023-08-12 20:47:52.320 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [413] = 
    {
        [1] = 1691862472320,
        [2] = "2023-08-12 20:47:52.320 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [414] = 
    {
        [1] = 1691862472329,
        [2] = "2023-08-12 20:47:52.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [415] = 
    {
        [1] = 1691862472410,
        [2] = "2023-08-12 20:47:52.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [416] = 
    {
        [1] = 1691862472425,
        [2] = "2023-08-12 20:47:52.425 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [417] = 
    {
        [1] = 1691862472433,
        [2] = "2023-08-12 20:47:52.433 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [418] = 
    {
        [1] = 1691862472438,
        [2] = "2023-08-12 20:47:52.438 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [419] = 
    {
        [1] = 1691862472438,
        [2] = "2023-08-12 20:47:52.438 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [420] = 
    {
        [1] = 1691862472447,
        [2] = "2023-08-12 20:47:52.447 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [421] = 
    {
        [1] = 1691862472454,
        [2] = "2023-08-12 20:47:52.454 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [422] = 
    {
        [1] = 1691862472703,
        [2] = "2023-08-12 20:47:52.703 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [423] = 
    {
        [1] = 1691862472704,
        [2] = "2023-08-12 20:47:52.704 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [424] = 
    {
        [1] = 1691862473257,
        [2] = "2023-08-12 20:47:53.257 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [425] = 
    {
        [1] = 1691862473257,
        [2] = "2023-08-12 20:47:53.257 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [426] = 
    {
        [1] = 1691862473262,
        [2] = "2023-08-12 20:47:53.262 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [427] = 
    {
        [1] = 1691862473270,
        [2] = "2023-08-12 20:47:53.270 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [428] = 
    {
        [1] = 1691862473281,
        [2] = "2023-08-12 20:47:53.281 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [429] = 
    {
        [1] = 1691862473299,
        [2] = "2023-08-12 20:47:53.299 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [430] = 
    {
        [1] = 1691862473309,
        [2] = "2023-08-12 20:47:53.309 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [431] = 
    {
        [1] = 1691862473322,
        [2] = "2023-08-12 20:47:53.322 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [432] = 
    {
        [1] = 1691862473635,
        [2] = "2023-08-12 20:47:53.635 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [433] = 
    {
        [1] = 1691862473635,
        [2] = "2023-08-12 20:47:53.635 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [434] = 
    {
        [1] = 1691862473648,
        [2] = "2023-08-12 20:47:53.648 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [435] = 
    {
        [1] = 1691862473648,
        [2] = "2023-08-12 20:47:53.648 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [436] = 
    {
        [1] = 1691862473657,
        [2] = "2023-08-12 20:47:53.657 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [437] = 
    {
        [1] = 1691862473673,
        [2] = "2023-08-12 20:47:53.673 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [438] = 
    {
        [1] = 1691862473674,
        [2] = "2023-08-12 20:47:53.674 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [439] = 
    {
        [1] = 1691862473713,
        [2] = "2023-08-12 20:47:53.713 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [440] = 
    {
        [1] = 1691862473739,
        [2] = "2023-08-12 20:47:53.739 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [441] = 
    {
        [1] = 1691862473739,
        [2] = "2023-08-12 20:47:53.739 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [442] = 
    {
        [1] = 1691862473751,
        [2] = "2023-08-12 20:47:53.751 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [443] = 
    {
        [1] = 1691862473758,
        [2] = "2023-08-12 20:47:53.758 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [444] = 
    {
        [1] = 1691862473818,
        [2] = "2023-08-12 20:47:53.818 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [445] = 
    {
        [1] = 1691862473826,
        [2] = "2023-08-12 20:47:53.826 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [446] = 
    {
        [1] = 1691862473839,
        [2] = "2023-08-12 20:47:53.839 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [447] = 
    {
        [1] = 1691862473845,
        [2] = "2023-08-12 20:47:53.845 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [448] = 
    {
        [1] = 1691862473856,
        [2] = "2023-08-12 20:47:53.856 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [449] = 
    {
        [1] = 1691862473864,
        [2] = "2023-08-12 20:47:53.864 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantJunk, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantJunk/'",
        [7] = "",
    },
    [450] = 
    {
        [1] = 1691862473905,
        [2] = "2023-08-12 20:47:53.905 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [451] = 
    {
        [1] = 1691862473906,
        [2] = "2023-08-12 20:47:53.906 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [452] = 
    {
        [1] = 1691862473906,
        [2] = "2023-08-12 20:47:53.906 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [453] = 
    {
        [1] = 1691862473906,
        [2] = "2023-08-12 20:47:53.906 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [454] = 
    {
        [1] = 1691862473917,
        [2] = "2023-08-12 20:47:53.917 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [455] = 
    {
        [1] = 1691862473923,
        [2] = "2023-08-12 20:47:53.923 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [456] = 
    {
        [1] = 1691862474246,
        [2] = "2023-08-12 20:47:54.246 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [457] = 
    {
        [1] = 1691862474253,
        [2] = "2023-08-12 20:47:54.253 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [458] = 
    {
        [1] = 1691862479426,
        [2] = "2023-08-12 20:47:59.426 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [459] = 
    {
        [1] = 1691862479441,
        [2] = "2023-08-12 20:47:59.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [460] = 
    {
        [1] = 1691862479441,
        [2] = "2023-08-12 20:47:59.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [461] = 
    {
        [1] = 1691862479442,
        [2] = "2023-08-12 20:47:59.442 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [462] = 
    {
        [1] = 1691862479447,
        [2] = "2023-08-12 20:47:59.447 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [463] = 
    {
        [1] = 1691862479458,
        [2] = "2023-08-12 20:47:59.458 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [464] = 
    {
        [1] = 1691862479464,
        [2] = "2023-08-12 20:47:59.464 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [465] = 
    {
        [1] = 1691862479511,
        [2] = "2023-08-12 20:47:59.511 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [466] = 
    {
        [1] = 1691862479537,
        [2] = "2023-08-12 20:47:59.537 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [467] = 
    {
        [1] = 1691862479576,
        [2] = "2023-08-12 20:47:59.576 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [468] = 
    {
        [1] = 1691862479577,
        [2] = "2023-08-12 20:47:59.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [469] = 
    {
        [1] = 1691862479593,
        [2] = "2023-08-12 20:47:59.593 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [470] = 
    {
        [1] = 1691862479601,
        [2] = "2023-08-12 20:47:59.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [471] = 
    {
        [1] = 1691862479601,
        [2] = "2023-08-12 20:47:59.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [472] = 
    {
        [1] = 1691862479719,
        [2] = "2023-08-12 20:47:59.719 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [473] = 
    {
        [1] = 1691862479789,
        [2] = "2023-08-12 20:47:59.789 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [474] = 
    {
        [1] = 1691862480792,
        [2] = "2023-08-12 20:48:00.792 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/', state: missing dependency (missing: LibMarify)",
        [7] = "",
    },
    [475] = 
    {
        [1] = 1691862480792,
        [2] = "2023-08-12 20:48:00.792 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/', state: missing dependency (missing: LibMarify)",
        [7] = "",
    },
    [476] = 
    {
        [1] = 1691862480792,
        [2] = "2023-08-12 20:48:00.792 +0300",
        [3] = 1,
        [4] = "W",
        [5] = "LibDebugLogger",
        [6] = "Did not load addon: HarvestPins, AddOnVersion: 1, directory: 'user:/AddOns/HarvestPins/', state: missing dependency (missing: HarvestMap)",
        [7] = "",
    },
    [477] = 
    {
        [1] = 1691862480792,
        [2] = "2023-08-12 20:48:00.792 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.792s)",
        [7] = "",
    },
    [478] = 
    {
        [1] = 1691862612003,
        [2] = "2023-08-12 20:50:12.003 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 20:49:49.291 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 111/111\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [479] = 
    {
        [1] = 1691862614342,
        [2] = "2023-08-12 20:50:14.342 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [480] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [481] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [482] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [483] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [484] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [485] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [486] = 
    {
        [1] = 1691862614344,
        [2] = "2023-08-12 20:50:14.344 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [487] = 
    {
        [1] = 1691862614404,
        [2] = "2023-08-12 20:50:14.404 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [488] = 
    {
        [1] = 1691862614404,
        [2] = "2023-08-12 20:50:14.404 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [489] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [490] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [491] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [492] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [493] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [494] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [495] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [496] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [497] = 
    {
        [1] = 1691862614410,
        [2] = "2023-08-12 20:50:14.410 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/CharacterKnowledge/LibCharacterKnowledge/'",
        [7] = "",
    },
    [498] = 
    {
        [1] = 1691862614415,
        [2] = "2023-08-12 20:50:14.415 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [499] = 
    {
        [1] = 1691862614424,
        [2] = "2023-08-12 20:50:14.424 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [500] = 
    {
        [1] = 1691862614428,
        [2] = "2023-08-12 20:50:14.428 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [501] = 
    {
        [1] = 1691862614460,
        [2] = "2023-08-12 20:50:14.460 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [502] = 
    {
        [1] = 1691862614468,
        [2] = "2023-08-12 20:50:14.468 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantJunk, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantJunk/'",
        [7] = "",
    },
    [503] = 
    {
        [1] = 1691862614477,
        [2] = "2023-08-12 20:50:14.477 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [504] = 
    {
        [1] = 1691862614479,
        [2] = "2023-08-12 20:50:14.479 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [505] = 
    {
        [1] = 1691862614479,
        [2] = "2023-08-12 20:50:14.479 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [506] = 
    {
        [1] = 1691862614480,
        [2] = "2023-08-12 20:50:14.480 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [507] = 
    {
        [1] = 1691862614480,
        [2] = "2023-08-12 20:50:14.480 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [508] = 
    {
        [1] = 1691862614511,
        [2] = "2023-08-12 20:50:14.511 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [509] = 
    {
        [1] = 1691862614511,
        [2] = "2023-08-12 20:50:14.511 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [510] = 
    {
        [1] = 1691862614511,
        [2] = "2023-08-12 20:50:14.511 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [511] = 
    {
        [1] = 1691862614824,
        [2] = "2023-08-12 20:50:14.824 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [512] = 
    {
        [1] = 1691862615178,
        [2] = "2023-08-12 20:50:15.178 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [513] = 
    {
        [1] = 1691862615183,
        [2] = "2023-08-12 20:50:15.183 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [514] = 
    {
        [1] = 1691862615187,
        [2] = "2023-08-12 20:50:15.187 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [515] = 
    {
        [1] = 1691862615187,
        [2] = "2023-08-12 20:50:15.187 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [516] = 
    {
        [1] = 1691862615187,
        [2] = "2023-08-12 20:50:15.187 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [517] = 
    {
        [1] = 1691862615187,
        [2] = "2023-08-12 20:50:15.187 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [518] = 
    {
        [1] = 1691862615187,
        [2] = "2023-08-12 20:50:15.187 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [519] = 
    {
        [1] = 1691862615191,
        [2] = "2023-08-12 20:50:15.191 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [520] = 
    {
        [1] = 1691862618704,
        [2] = "2023-08-12 20:50:18.704 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [521] = 
    {
        [1] = 1691862618704,
        [2] = "2023-08-12 20:50:18.704 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [522] = 
    {
        [1] = 1691862618716,
        [2] = "2023-08-12 20:50:18.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [523] = 
    {
        [1] = 1691862618716,
        [2] = "2023-08-12 20:50:18.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [524] = 
    {
        [1] = 1691862618716,
        [2] = "2023-08-12 20:50:18.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [525] = 
    {
        [1] = 1691862618716,
        [2] = "2023-08-12 20:50:18.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [526] = 
    {
        [1] = 1691862618716,
        [2] = "2023-08-12 20:50:18.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [527] = 
    {
        [1] = 1691862618716,
        [2] = "2023-08-12 20:50:18.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [528] = 
    {
        [1] = 1691862618730,
        [2] = "2023-08-12 20:50:18.730 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [529] = 
    {
        [1] = 1691862618730,
        [2] = "2023-08-12 20:50:18.730 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [530] = 
    {
        [1] = 1691862618735,
        [2] = "2023-08-12 20:50:18.735 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [531] = 
    {
        [1] = 1691862618743,
        [2] = "2023-08-12 20:50:18.743 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [532] = 
    {
        [1] = 1691862618748,
        [2] = "2023-08-12 20:50:18.748 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [533] = 
    {
        [1] = 1691862618780,
        [2] = "2023-08-12 20:50:18.780 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [534] = 
    {
        [1] = 1691862618795,
        [2] = "2023-08-12 20:50:18.795 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [535] = 
    {
        [1] = 1691862618801,
        [2] = "2023-08-12 20:50:18.801 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [536] = 
    {
        [1] = 1691862618831,
        [2] = "2023-08-12 20:50:18.831 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [537] = 
    {
        [1] = 1691862618831,
        [2] = "2023-08-12 20:50:18.831 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [538] = 
    {
        [1] = 1691862618831,
        [2] = "2023-08-12 20:50:18.831 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [539] = 
    {
        [1] = 1691862618846,
        [2] = "2023-08-12 20:50:18.846 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [540] = 
    {
        [1] = 1691862618846,
        [2] = "2023-08-12 20:50:18.846 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [541] = 
    {
        [1] = 1691862618852,
        [2] = "2023-08-12 20:50:18.852 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/EventCollectibles/LibExtendedJournal/'",
        [7] = "",
    },
    [542] = 
    {
        [1] = 1691862618855,
        [2] = "2023-08-12 20:50:18.855 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [543] = 
    {
        [1] = 1691862618856,
        [2] = "2023-08-12 20:50:18.856 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [544] = 
    {
        [1] = 1691862620777,
        [2] = "2023-08-12 20:50:20.777 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [545] = 
    {
        [1] = 1691862620792,
        [2] = "2023-08-12 20:50:20.792 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [546] = 
    {
        [1] = 1691862620812,
        [2] = "2023-08-12 20:50:20.812 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [547] = 
    {
        [1] = 1691862621116,
        [2] = "2023-08-12 20:50:21.116 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [548] = 
    {
        [1] = 1691862621149,
        [2] = "2023-08-12 20:50:21.149 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [549] = 
    {
        [1] = 1691862621156,
        [2] = "2023-08-12 20:50:21.156 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [550] = 
    {
        [1] = 1691862621156,
        [2] = "2023-08-12 20:50:21.156 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [551] = 
    {
        [1] = 1691862621164,
        [2] = "2023-08-12 20:50:21.164 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [552] = 
    {
        [1] = 1691862621164,
        [2] = "2023-08-12 20:50:21.164 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [553] = 
    {
        [1] = 1691862621215,
        [2] = "2023-08-12 20:50:21.215 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [554] = 
    {
        [1] = 1691862621228,
        [2] = "2023-08-12 20:50:21.228 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [555] = 
    {
        [1] = 1691862621320,
        [2] = "2023-08-12 20:50:21.320 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [556] = 
    {
        [1] = 1691862621326,
        [2] = "2023-08-12 20:50:21.326 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [557] = 
    {
        [1] = 1691862621339,
        [2] = "2023-08-12 20:50:21.339 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [558] = 
    {
        [1] = 1691862621346,
        [2] = "2023-08-12 20:50:21.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [559] = 
    {
        [1] = 1691862621346,
        [2] = "2023-08-12 20:50:21.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMarify, AddOnVersion: 1217, directory: 'user:/AddOns/LibMarify/'",
        [7] = "",
    },
    [560] = 
    {
        [1] = 1691862621346,
        [2] = "2023-08-12 20:50:21.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/'",
        [7] = "",
    },
    [561] = 
    {
        [1] = 1691862621360,
        [2] = "2023-08-12 20:50:21.360 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [562] = 
    {
        [1] = 1691862621365,
        [2] = "2023-08-12 20:50:21.365 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [563] = 
    {
        [1] = 1691862621377,
        [2] = "2023-08-12 20:50:21.377 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [564] = 
    {
        [1] = 1691862621377,
        [2] = "2023-08-12 20:50:21.377 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [565] = 
    {
        [1] = 1691862621389,
        [2] = "2023-08-12 20:50:21.389 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [566] = 
    {
        [1] = 1691862621389,
        [2] = "2023-08-12 20:50:21.389 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [567] = 
    {
        [1] = 1691862621389,
        [2] = "2023-08-12 20:50:21.389 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [568] = 
    {
        [1] = 1691862621408,
        [2] = "2023-08-12 20:50:21.408 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [569] = 
    {
        [1] = 1691862621413,
        [2] = "2023-08-12 20:50:21.413 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [570] = 
    {
        [1] = 1691862621437,
        [2] = "2023-08-12 20:50:21.437 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [571] = 
    {
        [1] = 1691862621437,
        [2] = "2023-08-12 20:50:21.437 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [572] = 
    {
        [1] = 1691862621446,
        [2] = "2023-08-12 20:50:21.446 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [573] = 
    {
        [1] = 1691862622205,
        [2] = "2023-08-12 20:50:22.205 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [574] = 
    {
        [1] = 1691862622424,
        [2] = "2023-08-12 20:50:22.424 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [575] = 
    {
        [1] = 1691862622444,
        [2] = "2023-08-12 20:50:22.444 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [576] = 
    {
        [1] = 1691862622444,
        [2] = "2023-08-12 20:50:22.444 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [577] = 
    {
        [1] = 1691862622463,
        [2] = "2023-08-12 20:50:22.463 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [578] = 
    {
        [1] = 1691862622469,
        [2] = "2023-08-12 20:50:22.469 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [579] = 
    {
        [1] = 1691862622905,
        [2] = "2023-08-12 20:50:22.905 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [580] = 
    {
        [1] = 1691862622906,
        [2] = "2023-08-12 20:50:22.906 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [581] = 
    {
        [1] = 1691862623493,
        [2] = "2023-08-12 20:50:23.493 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/'",
        [7] = "",
    },
    [582] = 
    {
        [1] = 1691862623508,
        [2] = "2023-08-12 20:50:23.508 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [583] = 
    {
        [1] = 1691862623508,
        [2] = "2023-08-12 20:50:23.508 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [584] = 
    {
        [1] = 1691862623517,
        [2] = "2023-08-12 20:50:23.517 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [585] = 
    {
        [1] = 1691862623526,
        [2] = "2023-08-12 20:50:23.526 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [586] = 
    {
        [1] = 1691862623537,
        [2] = "2023-08-12 20:50:23.537 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [587] = 
    {
        [1] = 1691862623557,
        [2] = "2023-08-12 20:50:23.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [588] = 
    {
        [1] = 1691862623569,
        [2] = "2023-08-12 20:50:23.569 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [589] = 
    {
        [1] = 1691862623584,
        [2] = "2023-08-12 20:50:23.584 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [590] = 
    {
        [1] = 1691862623584,
        [2] = "2023-08-12 20:50:23.584 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [591] = 
    {
        [1] = 1691862623592,
        [2] = "2023-08-12 20:50:23.592 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [592] = 
    {
        [1] = 1691862623611,
        [2] = "2023-08-12 20:50:23.611 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [593] = 
    {
        [1] = 1691862623640,
        [2] = "2023-08-12 20:50:23.640 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [594] = 
    {
        [1] = 1691862623647,
        [2] = "2023-08-12 20:50:23.647 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [595] = 
    {
        [1] = 1691862623716,
        [2] = "2023-08-12 20:50:23.716 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [596] = 
    {
        [1] = 1691862623723,
        [2] = "2023-08-12 20:50:23.723 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [597] = 
    {
        [1] = 1691862623737,
        [2] = "2023-08-12 20:50:23.737 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [598] = 
    {
        [1] = 1691862623743,
        [2] = "2023-08-12 20:50:23.743 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [599] = 
    {
        [1] = 1691862623759,
        [2] = "2023-08-12 20:50:23.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [600] = 
    {
        [1] = 1691862624460,
        [2] = "2023-08-12 20:50:24.460 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 12.460s)",
        [7] = "",
    },
    [601] = 
    {
        [1] = 1691862850693,
        [2] = "2023-08-12 20:54:10.693 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters] ERROR - ApplyFilter: FilterType at inventory '1'  was nil!\nTag 'AF_ButtonFilter', button 'All', filterType: 'nil', groupName: 'All'",
        [7] = "",
    },
    [602] = 
    {
        [1] = 1691862850696,
        [2] = "2023-08-12 20:54:10.696 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [603] = 
    {
        [1] = 1691862850698,
        [2] = "2023-08-12 20:54:10.698 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters]AF_FilterBar:ActivateButton: All",
        [7] = "",
    },
    [604] = 
    {
        [1] = 1691862850701,
        [2] = "2023-08-12 20:54:10.701 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = ">ERROR - filterPanelId is NIL!",
        [7] = "",
    },
    [605] = 
    {
        [1] = 1691862850703,
        [2] = "2023-08-12 20:54:10.703 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [606] = 
    {
        [1] = 1691862871003,
        [2] = "2023-08-12 20:54:31.003 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 20:49:49.412 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 110/111\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [607] = 
    {
        [1] = 1691862873252,
        [2] = "2023-08-12 20:54:33.252 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [608] = 
    {
        [1] = 1691862873255,
        [2] = "2023-08-12 20:54:33.255 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [609] = 
    {
        [1] = 1691862873255,
        [2] = "2023-08-12 20:54:33.255 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [610] = 
    {
        [1] = 1691862873255,
        [2] = "2023-08-12 20:54:33.255 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [611] = 
    {
        [1] = 1691862873255,
        [2] = "2023-08-12 20:54:33.255 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [612] = 
    {
        [1] = 1691862873255,
        [2] = "2023-08-12 20:54:33.255 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [613] = 
    {
        [1] = 1691862873255,
        [2] = "2023-08-12 20:54:33.255 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [614] = 
    {
        [1] = 1691862873256,
        [2] = "2023-08-12 20:54:33.256 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [615] = 
    {
        [1] = 1691862873327,
        [2] = "2023-08-12 20:54:33.327 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [616] = 
    {
        [1] = 1691862873327,
        [2] = "2023-08-12 20:54:33.327 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [617] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [618] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [619] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [620] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [621] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [622] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [623] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [624] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [625] = 
    {
        [1] = 1691862873333,
        [2] = "2023-08-12 20:54:33.333 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/CharacterKnowledge/LibCharacterKnowledge/'",
        [7] = "",
    },
    [626] = 
    {
        [1] = 1691862873338,
        [2] = "2023-08-12 20:54:33.338 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [627] = 
    {
        [1] = 1691862873347,
        [2] = "2023-08-12 20:54:33.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [628] = 
    {
        [1] = 1691862873349,
        [2] = "2023-08-12 20:54:33.349 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [629] = 
    {
        [1] = 1691862873349,
        [2] = "2023-08-12 20:54:33.349 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [630] = 
    {
        [1] = 1691862873351,
        [2] = "2023-08-12 20:54:33.351 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [631] = 
    {
        [1] = 1691862873351,
        [2] = "2023-08-12 20:54:33.351 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [632] = 
    {
        [1] = 1691862873373,
        [2] = "2023-08-12 20:54:33.373 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [633] = 
    {
        [1] = 1691862873373,
        [2] = "2023-08-12 20:54:33.373 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [634] = 
    {
        [1] = 1691862873373,
        [2] = "2023-08-12 20:54:33.373 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [635] = 
    {
        [1] = 1691862873678,
        [2] = "2023-08-12 20:54:33.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [636] = 
    {
        [1] = 1691862874026,
        [2] = "2023-08-12 20:54:34.026 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [637] = 
    {
        [1] = 1691862874032,
        [2] = "2023-08-12 20:54:34.032 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [638] = 
    {
        [1] = 1691862874034,
        [2] = "2023-08-12 20:54:34.034 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [639] = 
    {
        [1] = 1691862874034,
        [2] = "2023-08-12 20:54:34.034 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [640] = 
    {
        [1] = 1691862874034,
        [2] = "2023-08-12 20:54:34.034 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [641] = 
    {
        [1] = 1691862874035,
        [2] = "2023-08-12 20:54:34.035 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [642] = 
    {
        [1] = 1691862874035,
        [2] = "2023-08-12 20:54:34.035 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [643] = 
    {
        [1] = 1691862874038,
        [2] = "2023-08-12 20:54:34.038 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [644] = 
    {
        [1] = 1691862876593,
        [2] = "2023-08-12 20:54:36.593 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [645] = 
    {
        [1] = 1691862876593,
        [2] = "2023-08-12 20:54:36.593 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [646] = 
    {
        [1] = 1691862876602,
        [2] = "2023-08-12 20:54:36.602 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [647] = 
    {
        [1] = 1691862876602,
        [2] = "2023-08-12 20:54:36.602 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [648] = 
    {
        [1] = 1691862876602,
        [2] = "2023-08-12 20:54:36.602 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [649] = 
    {
        [1] = 1691862876603,
        [2] = "2023-08-12 20:54:36.603 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [650] = 
    {
        [1] = 1691862876603,
        [2] = "2023-08-12 20:54:36.603 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [651] = 
    {
        [1] = 1691862876603,
        [2] = "2023-08-12 20:54:36.603 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [652] = 
    {
        [1] = 1691862876603,
        [2] = "2023-08-12 20:54:36.603 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [653] = 
    {
        [1] = 1691862876614,
        [2] = "2023-08-12 20:54:36.614 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [654] = 
    {
        [1] = 1691862876615,
        [2] = "2023-08-12 20:54:36.615 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [655] = 
    {
        [1] = 1691862876620,
        [2] = "2023-08-12 20:54:36.620 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [656] = 
    {
        [1] = 1691862876627,
        [2] = "2023-08-12 20:54:36.627 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [657] = 
    {
        [1] = 1691862876631,
        [2] = "2023-08-12 20:54:36.631 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [658] = 
    {
        [1] = 1691862876658,
        [2] = "2023-08-12 20:54:36.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [659] = 
    {
        [1] = 1691862876670,
        [2] = "2023-08-12 20:54:36.670 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [660] = 
    {
        [1] = 1691862876676,
        [2] = "2023-08-12 20:54:36.676 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [661] = 
    {
        [1] = 1691862876780,
        [2] = "2023-08-12 20:54:36.780 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [662] = 
    {
        [1] = 1691862876796,
        [2] = "2023-08-12 20:54:36.796 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [663] = 
    {
        [1] = 1691862876823,
        [2] = "2023-08-12 20:54:36.823 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [664] = 
    {
        [1] = 1691862876823,
        [2] = "2023-08-12 20:54:36.823 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [665] = 
    {
        [1] = 1691862876823,
        [2] = "2023-08-12 20:54:36.823 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [666] = 
    {
        [1] = 1691862876835,
        [2] = "2023-08-12 20:54:36.835 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [667] = 
    {
        [1] = 1691862876835,
        [2] = "2023-08-12 20:54:36.835 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [668] = 
    {
        [1] = 1691862876840,
        [2] = "2023-08-12 20:54:36.840 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/EventCollectibles/LibExtendedJournal/'",
        [7] = "",
    },
    [669] = 
    {
        [1] = 1691862876843,
        [2] = "2023-08-12 20:54:36.843 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [670] = 
    {
        [1] = 1691862876844,
        [2] = "2023-08-12 20:54:36.844 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [671] = 
    {
        [1] = 1691862878992,
        [2] = "2023-08-12 20:54:38.992 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [672] = 
    {
        [1] = 1691862879010,
        [2] = "2023-08-12 20:54:39.010 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [673] = 
    {
        [1] = 1691862879031,
        [2] = "2023-08-12 20:54:39.031 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [674] = 
    {
        [1] = 1691862879350,
        [2] = "2023-08-12 20:54:39.350 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [675] = 
    {
        [1] = 1691862879381,
        [2] = "2023-08-12 20:54:39.381 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [676] = 
    {
        [1] = 1691862879387,
        [2] = "2023-08-12 20:54:39.387 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [677] = 
    {
        [1] = 1691862879387,
        [2] = "2023-08-12 20:54:39.387 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [678] = 
    {
        [1] = 1691862879395,
        [2] = "2023-08-12 20:54:39.395 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [679] = 
    {
        [1] = 1691862879395,
        [2] = "2023-08-12 20:54:39.395 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [680] = 
    {
        [1] = 1691862879448,
        [2] = "2023-08-12 20:54:39.448 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [681] = 
    {
        [1] = 1691862879462,
        [2] = "2023-08-12 20:54:39.462 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [682] = 
    {
        [1] = 1691862879563,
        [2] = "2023-08-12 20:54:39.563 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [683] = 
    {
        [1] = 1691862879568,
        [2] = "2023-08-12 20:54:39.568 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [684] = 
    {
        [1] = 1691862879583,
        [2] = "2023-08-12 20:54:39.583 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [685] = 
    {
        [1] = 1691862879591,
        [2] = "2023-08-12 20:54:39.591 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [686] = 
    {
        [1] = 1691862879591,
        [2] = "2023-08-12 20:54:39.591 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMarify, AddOnVersion: 1217, directory: 'user:/AddOns/LibMarify/'",
        [7] = "",
    },
    [687] = 
    {
        [1] = 1691862879591,
        [2] = "2023-08-12 20:54:39.591 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/'",
        [7] = "",
    },
    [688] = 
    {
        [1] = 1691862879606,
        [2] = "2023-08-12 20:54:39.606 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [689] = 
    {
        [1] = 1691862879611,
        [2] = "2023-08-12 20:54:39.611 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [690] = 
    {
        [1] = 1691862879625,
        [2] = "2023-08-12 20:54:39.625 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [691] = 
    {
        [1] = 1691862879625,
        [2] = "2023-08-12 20:54:39.625 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [692] = 
    {
        [1] = 1691862879638,
        [2] = "2023-08-12 20:54:39.638 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [693] = 
    {
        [1] = 1691862879638,
        [2] = "2023-08-12 20:54:39.638 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [694] = 
    {
        [1] = 1691862879638,
        [2] = "2023-08-12 20:54:39.638 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [695] = 
    {
        [1] = 1691862879654,
        [2] = "2023-08-12 20:54:39.654 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [696] = 
    {
        [1] = 1691862879661,
        [2] = "2023-08-12 20:54:39.661 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [697] = 
    {
        [1] = 1691862879678,
        [2] = "2023-08-12 20:54:39.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [698] = 
    {
        [1] = 1691862879678,
        [2] = "2023-08-12 20:54:39.678 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [699] = 
    {
        [1] = 1691862879684,
        [2] = "2023-08-12 20:54:39.684 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [700] = 
    {
        [1] = 1691862880444,
        [2] = "2023-08-12 20:54:40.444 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [701] = 
    {
        [1] = 1691862880669,
        [2] = "2023-08-12 20:54:40.669 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [702] = 
    {
        [1] = 1691862880694,
        [2] = "2023-08-12 20:54:40.694 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [703] = 
    {
        [1] = 1691862880694,
        [2] = "2023-08-12 20:54:40.694 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [704] = 
    {
        [1] = 1691862880715,
        [2] = "2023-08-12 20:54:40.715 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [705] = 
    {
        [1] = 1691862880723,
        [2] = "2023-08-12 20:54:40.723 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [706] = 
    {
        [1] = 1691862881193,
        [2] = "2023-08-12 20:54:41.193 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [707] = 
    {
        [1] = 1691862881194,
        [2] = "2023-08-12 20:54:41.194 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [708] = 
    {
        [1] = 1691862881759,
        [2] = "2023-08-12 20:54:41.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/'",
        [7] = "",
    },
    [709] = 
    {
        [1] = 1691862881772,
        [2] = "2023-08-12 20:54:41.772 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [710] = 
    {
        [1] = 1691862881772,
        [2] = "2023-08-12 20:54:41.772 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [711] = 
    {
        [1] = 1691862881777,
        [2] = "2023-08-12 20:54:41.777 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [712] = 
    {
        [1] = 1691862881786,
        [2] = "2023-08-12 20:54:41.786 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [713] = 
    {
        [1] = 1691862881797,
        [2] = "2023-08-12 20:54:41.797 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [714] = 
    {
        [1] = 1691862881819,
        [2] = "2023-08-12 20:54:41.819 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [715] = 
    {
        [1] = 1691862881831,
        [2] = "2023-08-12 20:54:41.831 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [716] = 
    {
        [1] = 1691862881844,
        [2] = "2023-08-12 20:54:41.844 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [717] = 
    {
        [1] = 1691862881844,
        [2] = "2023-08-12 20:54:41.844 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [718] = 
    {
        [1] = 1691862881852,
        [2] = "2023-08-12 20:54:41.852 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [719] = 
    {
        [1] = 1691862881871,
        [2] = "2023-08-12 20:54:41.871 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [720] = 
    {
        [1] = 1691862881899,
        [2] = "2023-08-12 20:54:41.899 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [721] = 
    {
        [1] = 1691862881906,
        [2] = "2023-08-12 20:54:41.906 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [722] = 
    {
        [1] = 1691862881975,
        [2] = "2023-08-12 20:54:41.975 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [723] = 
    {
        [1] = 1691862881982,
        [2] = "2023-08-12 20:54:41.982 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [724] = 
    {
        [1] = 1691862881995,
        [2] = "2023-08-12 20:54:41.995 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [725] = 
    {
        [1] = 1691862882002,
        [2] = "2023-08-12 20:54:42.002 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [726] = 
    {
        [1] = 1691862882103,
        [2] = "2023-08-12 20:54:42.103 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [727] = 
    {
        [1] = 1691862882285,
        [2] = "2023-08-12 20:54:42.285 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Loading screen ended (duration: 18.454s)",
        [7] = "",
    },
    [728] = 
    {
        [1] = 1691862931471,
        [2] = "2023-08-12 20:55:31.471 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters] ERROR - ApplyFilter: FilterType at inventory '1'  was nil!\nTag 'AF_ButtonFilter', button 'All', filterType: 'nil', groupName: 'All'",
        [7] = "",
    },
    [729] = 
    {
        [1] = 1691862931473,
        [2] = "2023-08-12 20:55:31.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [730] = 
    {
        [1] = 1691862931474,
        [2] = "2023-08-12 20:55:31.474 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters]AF_FilterBar:ActivateButton: All",
        [7] = "",
    },
    [731] = 
    {
        [1] = 1691862931476,
        [2] = "2023-08-12 20:55:31.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = ">ERROR - filterPanelId is NIL!",
        [7] = "",
    },
    [732] = 
    {
        [1] = 1691862931478,
        [2] = "2023-08-12 20:55:31.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [733] = 
    {
        [1] = 1691863183656,
        [2] = "2023-08-12 20:59:43.656 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters] ERROR - ApplyFilter: FilterType at inventory '1'  was nil!\nTag 'AF_ButtonFilter', button 'All', filterType: 'nil', groupName: 'All'",
        [7] = "",
    },
    [734] = 
    {
        [1] = 1691863183658,
        [2] = "2023-08-12 20:59:43.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [735] = 
    {
        [1] = 1691863183658,
        [2] = "2023-08-12 20:59:43.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "[AdvancedFilters]AF_FilterBar:ActivateButton: All",
        [7] = "",
    },
    [736] = 
    {
        [1] = 1691863183658,
        [2] = "2023-08-12 20:59:43.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = ">ERROR - filterPanelId is NIL!",
        [7] = "",
    },
    [737] = 
    {
        [1] = 1691863183658,
        [2] = "2023-08-12 20:59:43.658 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "UI",
        [6] = "===============================================",
        [7] = "",
    },
    [738] = 
    {
        [1] = 1691863224003,
        [2] = "2023-08-12 21:00:24.003 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 20:49:49.634 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 110/111\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [739] = 
    {
        [1] = 1691863226242,
        [2] = "2023-08-12 21:00:26.242 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [740] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [741] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [742] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [743] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [744] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [745] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [746] = 
    {
        [1] = 1691863226245,
        [2] = "2023-08-12 21:00:26.245 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [747] = 
    {
        [1] = 1691863226322,
        [2] = "2023-08-12 21:00:26.322 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [748] = 
    {
        [1] = 1691863226322,
        [2] = "2023-08-12 21:00:26.322 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [749] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [750] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [751] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [752] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [753] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [754] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [755] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [756] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [757] = 
    {
        [1] = 1691863226329,
        [2] = "2023-08-12 21:00:26.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/CharacterKnowledge/LibCharacterKnowledge/'",
        [7] = "",
    },
    [758] = 
    {
        [1] = 1691863226334,
        [2] = "2023-08-12 21:00:26.334 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [759] = 
    {
        [1] = 1691863226343,
        [2] = "2023-08-12 21:00:26.343 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [760] = 
    {
        [1] = 1691863226346,
        [2] = "2023-08-12 21:00:26.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [761] = 
    {
        [1] = 1691863226346,
        [2] = "2023-08-12 21:00:26.346 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [762] = 
    {
        [1] = 1691863226347,
        [2] = "2023-08-12 21:00:26.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [763] = 
    {
        [1] = 1691863226347,
        [2] = "2023-08-12 21:00:26.347 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [764] = 
    {
        [1] = 1691863226370,
        [2] = "2023-08-12 21:00:26.370 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [765] = 
    {
        [1] = 1691863226370,
        [2] = "2023-08-12 21:00:26.370 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [766] = 
    {
        [1] = 1691863226370,
        [2] = "2023-08-12 21:00:26.370 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [767] = 
    {
        [1] = 1691863226680,
        [2] = "2023-08-12 21:00:26.680 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [768] = 
    {
        [1] = 1691863227027,
        [2] = "2023-08-12 21:00:27.027 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [769] = 
    {
        [1] = 1691863227034,
        [2] = "2023-08-12 21:00:27.034 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [770] = 
    {
        [1] = 1691863227037,
        [2] = "2023-08-12 21:00:27.037 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [771] = 
    {
        [1] = 1691863227037,
        [2] = "2023-08-12 21:00:27.037 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [772] = 
    {
        [1] = 1691863227037,
        [2] = "2023-08-12 21:00:27.037 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [773] = 
    {
        [1] = 1691863227037,
        [2] = "2023-08-12 21:00:27.037 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [774] = 
    {
        [1] = 1691863227037,
        [2] = "2023-08-12 21:00:27.037 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [775] = 
    {
        [1] = 1691863227046,
        [2] = "2023-08-12 21:00:27.046 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [776] = 
    {
        [1] = 1691863229513,
        [2] = "2023-08-12 21:00:29.513 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [777] = 
    {
        [1] = 1691863229513,
        [2] = "2023-08-12 21:00:29.513 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [778] = 
    {
        [1] = 1691863229521,
        [2] = "2023-08-12 21:00:29.521 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [779] = 
    {
        [1] = 1691863229522,
        [2] = "2023-08-12 21:00:29.522 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [780] = 
    {
        [1] = 1691863229522,
        [2] = "2023-08-12 21:00:29.522 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [781] = 
    {
        [1] = 1691863229522,
        [2] = "2023-08-12 21:00:29.522 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [782] = 
    {
        [1] = 1691863229522,
        [2] = "2023-08-12 21:00:29.522 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [783] = 
    {
        [1] = 1691863229522,
        [2] = "2023-08-12 21:00:29.522 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [784] = 
    {
        [1] = 1691863229522,
        [2] = "2023-08-12 21:00:29.522 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [785] = 
    {
        [1] = 1691863229532,
        [2] = "2023-08-12 21:00:29.532 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [786] = 
    {
        [1] = 1691863229532,
        [2] = "2023-08-12 21:00:29.532 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [787] = 
    {
        [1] = 1691863229537,
        [2] = "2023-08-12 21:00:29.537 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [788] = 
    {
        [1] = 1691863229543,
        [2] = "2023-08-12 21:00:29.543 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [789] = 
    {
        [1] = 1691863229548,
        [2] = "2023-08-12 21:00:29.548 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [790] = 
    {
        [1] = 1691863229572,
        [2] = "2023-08-12 21:00:29.572 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [791] = 
    {
        [1] = 1691863229584,
        [2] = "2023-08-12 21:00:29.584 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [792] = 
    {
        [1] = 1691863229590,
        [2] = "2023-08-12 21:00:29.590 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [793] = 
    {
        [1] = 1691863229683,
        [2] = "2023-08-12 21:00:29.683 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [794] = 
    {
        [1] = 1691863229697,
        [2] = "2023-08-12 21:00:29.697 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [795] = 
    {
        [1] = 1691863229722,
        [2] = "2023-08-12 21:00:29.722 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [796] = 
    {
        [1] = 1691863229722,
        [2] = "2023-08-12 21:00:29.722 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [797] = 
    {
        [1] = 1691863229722,
        [2] = "2023-08-12 21:00:29.722 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [798] = 
    {
        [1] = 1691863229733,
        [2] = "2023-08-12 21:00:29.733 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [799] = 
    {
        [1] = 1691863229733,
        [2] = "2023-08-12 21:00:29.733 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [800] = 
    {
        [1] = 1691863229739,
        [2] = "2023-08-12 21:00:29.739 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/EventCollectibles/LibExtendedJournal/'",
        [7] = "",
    },
    [801] = 
    {
        [1] = 1691863229741,
        [2] = "2023-08-12 21:00:29.741 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [802] = 
    {
        [1] = 1691863229742,
        [2] = "2023-08-12 21:00:29.742 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [803] = 
    {
        [1] = 1691863231258,
        [2] = "2023-08-12 21:00:31.258 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [804] = 
    {
        [1] = 1691863231271,
        [2] = "2023-08-12 21:00:31.271 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [805] = 
    {
        [1] = 1691863231288,
        [2] = "2023-08-12 21:00:31.288 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [806] = 
    {
        [1] = 1691863231540,
        [2] = "2023-08-12 21:00:31.540 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [807] = 
    {
        [1] = 1691863231566,
        [2] = "2023-08-12 21:00:31.566 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [808] = 
    {
        [1] = 1691863231572,
        [2] = "2023-08-12 21:00:31.572 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [809] = 
    {
        [1] = 1691863231573,
        [2] = "2023-08-12 21:00:31.573 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [810] = 
    {
        [1] = 1691863231578,
        [2] = "2023-08-12 21:00:31.578 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [811] = 
    {
        [1] = 1691863231579,
        [2] = "2023-08-12 21:00:31.579 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [812] = 
    {
        [1] = 1691863231620,
        [2] = "2023-08-12 21:00:31.620 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [813] = 
    {
        [1] = 1691863231631,
        [2] = "2023-08-12 21:00:31.631 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [814] = 
    {
        [1] = 1691863231708,
        [2] = "2023-08-12 21:00:31.708 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [815] = 
    {
        [1] = 1691863231714,
        [2] = "2023-08-12 21:00:31.714 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [816] = 
    {
        [1] = 1691863231725,
        [2] = "2023-08-12 21:00:31.725 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [817] = 
    {
        [1] = 1691863231732,
        [2] = "2023-08-12 21:00:31.732 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [818] = 
    {
        [1] = 1691863231732,
        [2] = "2023-08-12 21:00:31.732 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMarify, AddOnVersion: 1217, directory: 'user:/AddOns/LibMarify/'",
        [7] = "",
    },
    [819] = 
    {
        [1] = 1691863231732,
        [2] = "2023-08-12 21:00:31.732 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/'",
        [7] = "",
    },
    [820] = 
    {
        [1] = 1691863231744,
        [2] = "2023-08-12 21:00:31.744 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [821] = 
    {
        [1] = 1691863231750,
        [2] = "2023-08-12 21:00:31.750 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [822] = 
    {
        [1] = 1691863231759,
        [2] = "2023-08-12 21:00:31.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [823] = 
    {
        [1] = 1691863231759,
        [2] = "2023-08-12 21:00:31.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [824] = 
    {
        [1] = 1691863231770,
        [2] = "2023-08-12 21:00:31.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [825] = 
    {
        [1] = 1691863231770,
        [2] = "2023-08-12 21:00:31.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [826] = 
    {
        [1] = 1691863231770,
        [2] = "2023-08-12 21:00:31.770 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [827] = 
    {
        [1] = 1691863231783,
        [2] = "2023-08-12 21:00:31.783 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [828] = 
    {
        [1] = 1691863231788,
        [2] = "2023-08-12 21:00:31.788 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [829] = 
    {
        [1] = 1691863231802,
        [2] = "2023-08-12 21:00:31.802 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [830] = 
    {
        [1] = 1691863231802,
        [2] = "2023-08-12 21:00:31.802 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [831] = 
    {
        [1] = 1691863231808,
        [2] = "2023-08-12 21:00:31.808 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [832] = 
    {
        [1] = 1691863232448,
        [2] = "2023-08-12 21:00:32.448 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [833] = 
    {
        [1] = 1691863232614,
        [2] = "2023-08-12 21:00:32.614 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [834] = 
    {
        [1] = 1691863232628,
        [2] = "2023-08-12 21:00:32.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [835] = 
    {
        [1] = 1691863232628,
        [2] = "2023-08-12 21:00:32.628 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [836] = 
    {
        [1] = 1691863232644,
        [2] = "2023-08-12 21:00:32.644 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [837] = 
    {
        [1] = 1691863232651,
        [2] = "2023-08-12 21:00:32.651 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [838] = 
    {
        [1] = 1691863232989,
        [2] = "2023-08-12 21:00:32.989 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [839] = 
    {
        [1] = 1691863232991,
        [2] = "2023-08-12 21:00:32.991 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [840] = 
    {
        [1] = 1691863233516,
        [2] = "2023-08-12 21:00:33.516 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/'",
        [7] = "",
    },
    [841] = 
    {
        [1] = 1691863233526,
        [2] = "2023-08-12 21:00:33.526 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [842] = 
    {
        [1] = 1691863233527,
        [2] = "2023-08-12 21:00:33.527 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [843] = 
    {
        [1] = 1691863233531,
        [2] = "2023-08-12 21:00:33.531 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [844] = 
    {
        [1] = 1691863233539,
        [2] = "2023-08-12 21:00:33.539 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [845] = 
    {
        [1] = 1691863233547,
        [2] = "2023-08-12 21:00:33.547 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [846] = 
    {
        [1] = 1691863233565,
        [2] = "2023-08-12 21:00:33.565 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [847] = 
    {
        [1] = 1691863233575,
        [2] = "2023-08-12 21:00:33.575 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [848] = 
    {
        [1] = 1691863233585,
        [2] = "2023-08-12 21:00:33.585 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [849] = 
    {
        [1] = 1691863233585,
        [2] = "2023-08-12 21:00:33.585 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [850] = 
    {
        [1] = 1691863233594,
        [2] = "2023-08-12 21:00:33.594 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [851] = 
    {
        [1] = 1691863233610,
        [2] = "2023-08-12 21:00:33.610 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [852] = 
    {
        [1] = 1691863233633,
        [2] = "2023-08-12 21:00:33.633 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [853] = 
    {
        [1] = 1691863233640,
        [2] = "2023-08-12 21:00:33.640 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [854] = 
    {
        [1] = 1691863233693,
        [2] = "2023-08-12 21:00:33.693 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [855] = 
    {
        [1] = 1691863233700,
        [2] = "2023-08-12 21:00:33.700 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [856] = 
    {
        [1] = 1691863233711,
        [2] = "2023-08-12 21:00:33.711 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [857] = 
    {
        [1] = 1691863233717,
        [2] = "2023-08-12 21:00:33.717 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [858] = 
    {
        [1] = 1691863233797,
        [2] = "2023-08-12 21:00:33.797 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [859] = 
    {
        [1] = 1691863233934,
        [2] = "2023-08-12 21:00:33.934 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Loading screen ended (duration: 17.156s)",
        [7] = "",
    },
    [860] = 
    {
        [1] = 1691865899003,
        [2] = "2023-08-12 21:44:59.003 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 21:44:33.560 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 115/116\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [861] = 
    {
        [1] = 1691865901503,
        [2] = "2023-08-12 21:45:01.503 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [862] = 
    {
        [1] = 1691865901505,
        [2] = "2023-08-12 21:45:01.505 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [863] = 
    {
        [1] = 1691865901505,
        [2] = "2023-08-12 21:45:01.505 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [864] = 
    {
        [1] = 1691865901506,
        [2] = "2023-08-12 21:45:01.506 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [865] = 
    {
        [1] = 1691865901507,
        [2] = "2023-08-12 21:45:01.507 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [866] = 
    {
        [1] = 1691865901507,
        [2] = "2023-08-12 21:45:01.507 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [867] = 
    {
        [1] = 1691865901507,
        [2] = "2023-08-12 21:45:01.507 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [868] = 
    {
        [1] = 1691865901507,
        [2] = "2023-08-12 21:45:01.507 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [869] = 
    {
        [1] = 1691865901564,
        [2] = "2023-08-12 21:45:01.564 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [870] = 
    {
        [1] = 1691865901564,
        [2] = "2023-08-12 21:45:01.564 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [871] = 
    {
        [1] = 1691865901564,
        [2] = "2023-08-12 21:45:01.564 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [872] = 
    {
        [1] = 1691865901569,
        [2] = "2023-08-12 21:45:01.569 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [873] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [874] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [875] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [876] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenuOrderListBox, AddOnVersion: 8, directory: 'user:/AddOns/LibAddonMenuOrderListBox/'",
        [7] = "",
    },
    [877] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [878] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [879] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFeedback, AddOnVersion: 0, directory: 'user:/AddOns/LibFeedback/'",
        [7] = "",
    },
    [880] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [881] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [882] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [883] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [884] = 
    {
        [1] = 1691865901570,
        [2] = "2023-08-12 21:45:01.570 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [885] = 
    {
        [1] = 1691865901601,
        [2] = "2023-08-12 21:45:01.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibShifterBox, AddOnVersion: 500, directory: 'user:/AddOns/LibShifterBox/'",
        [7] = "",
    },
    [886] = 
    {
        [1] = 1691865901601,
        [2] = "2023-08-12 21:45:01.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [887] = 
    {
        [1] = 1691865901601,
        [2] = "2023-08-12 21:45:01.601 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [888] = 
    {
        [1] = 1691865901607,
        [2] = "2023-08-12 21:45:01.607 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [889] = 
    {
        [1] = 1691865901607,
        [2] = "2023-08-12 21:45:01.607 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [890] = 
    {
        [1] = 1691865902000,
        [2] = "2023-08-12 21:45:02.000 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [891] = 
    {
        [1] = 1691865902105,
        [2] = "2023-08-12 21:45:02.105 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: FCOItemSaver, AddOnVersion: 249, directory: 'user:/AddOns/FCOItemSaver/'",
        [7] = "",
    },
    [892] = 
    {
        [1] = 1691865902205,
        [2] = "2023-08-12 21:45:02.205 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [893] = 
    {
        [1] = 1691865902211,
        [2] = "2023-08-12 21:45:02.211 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/CharacterKnowledge/LibExtendedJournal/'",
        [7] = "",
    },
    [894] = 
    {
        [1] = 1691865902218,
        [2] = "2023-08-12 21:45:02.218 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [895] = 
    {
        [1] = 1691865902231,
        [2] = "2023-08-12 21:45:02.231 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AutoCategory, AddOnVersion: 91, directory: 'user:/AddOns/AutoCategory/'",
        [7] = "",
    },
    [896] = 
    {
        [1] = 1691865902244,
        [2] = "2023-08-12 21:45:02.244 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [897] = 
    {
        [1] = 1691865902250,
        [2] = "2023-08-12 21:45:02.250 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [898] = 
    {
        [1] = 1691865902473,
        [2] = "2023-08-12 21:45:02.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [899] = 
    {
        [1] = 1691865902497,
        [2] = "2023-08-12 21:45:02.497 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [900] = 
    {
        [1] = 1691865902503,
        [2] = "2023-08-12 21:45:02.503 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [901] = 
    {
        [1] = 1691865902504,
        [2] = "2023-08-12 21:45:02.504 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [902] = 
    {
        [1] = 1691865902504,
        [2] = "2023-08-12 21:45:02.504 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [903] = 
    {
        [1] = 1691865902515,
        [2] = "2023-08-12 21:45:02.515 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [904] = 
    {
        [1] = 1691865902515,
        [2] = "2023-08-12 21:45:02.515 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [905] = 
    {
        [1] = 1691865902557,
        [2] = "2023-08-12 21:45:02.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [906] = 
    {
        [1] = 1691865902563,
        [2] = "2023-08-12 21:45:02.563 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [907] = 
    {
        [1] = 1691865902577,
        [2] = "2023-08-12 21:45:02.577 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [908] = 
    {
        [1] = 1691865902588,
        [2] = "2023-08-12 21:45:02.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [909] = 
    {
        [1] = 1691865902655,
        [2] = "2023-08-12 21:45:02.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [910] = 
    {
        [1] = 1691865902655,
        [2] = "2023-08-12 21:45:02.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [911] = 
    {
        [1] = 1691865902660,
        [2] = "2023-08-12 21:45:02.660 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [912] = 
    {
        [1] = 1691865902672,
        [2] = "2023-08-12 21:45:02.672 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [913] = 
    {
        [1] = 1691865902677,
        [2] = "2023-08-12 21:45:02.677 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [914] = 
    {
        [1] = 1691865902677,
        [2] = "2023-08-12 21:45:02.677 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMarify, AddOnVersion: 1217, directory: 'user:/AddOns/LibMarify/'",
        [7] = "",
    },
    [915] = 
    {
        [1] = 1691865902677,
        [2] = "2023-08-12 21:45:02.677 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/'",
        [7] = "",
    },
    [916] = 
    {
        [1] = 1691865902689,
        [2] = "2023-08-12 21:45:02.689 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [917] = 
    {
        [1] = 1691865902695,
        [2] = "2023-08-12 21:45:02.695 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [918] = 
    {
        [1] = 1691865902703,
        [2] = "2023-08-12 21:45:02.703 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [919] = 
    {
        [1] = 1691865902703,
        [2] = "2023-08-12 21:45:02.703 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [920] = 
    {
        [1] = 1691865902703,
        [2] = "2023-08-12 21:45:02.703 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [921] = 
    {
        [1] = 1691865902704,
        [2] = "2023-08-12 21:45:02.704 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [922] = 
    {
        [1] = 1691865902713,
        [2] = "2023-08-12 21:45:02.713 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [923] = 
    {
        [1] = 1691865902713,
        [2] = "2023-08-12 21:45:02.713 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [924] = 
    {
        [1] = 1691865902713,
        [2] = "2023-08-12 21:45:02.713 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [925] = 
    {
        [1] = 1691865902727,
        [2] = "2023-08-12 21:45:02.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [926] = 
    {
        [1] = 1691865902727,
        [2] = "2023-08-12 21:45:02.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [927] = 
    {
        [1] = 1691865902727,
        [2] = "2023-08-12 21:45:02.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [928] = 
    {
        [1] = 1691865902733,
        [2] = "2023-08-12 21:45:02.733 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [929] = 
    {
        [1] = 1691865902745,
        [2] = "2023-08-12 21:45:02.745 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [930] = 
    {
        [1] = 1691865902745,
        [2] = "2023-08-12 21:45:02.745 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [931] = 
    {
        [1] = 1691865902745,
        [2] = "2023-08-12 21:45:02.745 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [932] = 
    {
        [1] = 1691865902745,
        [2] = "2023-08-12 21:45:02.745 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [933] = 
    {
        [1] = 1691865902745,
        [2] = "2023-08-12 21:45:02.745 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [934] = 
    {
        [1] = 1691865902750,
        [2] = "2023-08-12 21:45:02.750 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [935] = 
    {
        [1] = 1691865903402,
        [2] = "2023-08-12 21:45:03.402 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [936] = 
    {
        [1] = 1691865903590,
        [2] = "2023-08-12 21:45:03.590 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [937] = 
    {
        [1] = 1691865903590,
        [2] = "2023-08-12 21:45:03.590 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [938] = 
    {
        [1] = 1691865903590,
        [2] = "2023-08-12 21:45:03.590 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [939] = 
    {
        [1] = 1691865903606,
        [2] = "2023-08-12 21:45:03.606 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [940] = 
    {
        [1] = 1691865903613,
        [2] = "2023-08-12 21:45:03.613 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [941] = 
    {
        [1] = 1691865903619,
        [2] = "2023-08-12 21:45:03.619 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [942] = 
    {
        [1] = 1691865903619,
        [2] = "2023-08-12 21:45:03.619 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [943] = 
    {
        [1] = 1691865903636,
        [2] = "2023-08-12 21:45:03.636 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [944] = 
    {
        [1] = 1691865903643,
        [2] = "2023-08-12 21:45:03.643 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [945] = 
    {
        [1] = 1691865903973,
        [2] = "2023-08-12 21:45:03.973 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [946] = 
    {
        [1] = 1691865903975,
        [2] = "2023-08-12 21:45:03.975 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [947] = 
    {
        [1] = 1691865904474,
        [2] = "2023-08-12 21:45:04.474 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/'",
        [7] = "",
    },
    [948] = 
    {
        [1] = 1691865904483,
        [2] = "2023-08-12 21:45:04.483 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [949] = 
    {
        [1] = 1691865904483,
        [2] = "2023-08-12 21:45:04.483 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [950] = 
    {
        [1] = 1691865904487,
        [2] = "2023-08-12 21:45:04.487 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AF_FCOItemSaverFilters, AddOnVersion: 193, directory: 'user:/AddOns/AF_FCOItemSaverFilters/'",
        [7] = "",
    },
    [951] = 
    {
        [1] = 1691865904487,
        [2] = "2023-08-12 21:45:04.487 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [952] = 
    {
        [1] = 1691865904495,
        [2] = "2023-08-12 21:45:04.495 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [953] = 
    {
        [1] = 1691865904509,
        [2] = "2023-08-12 21:45:04.509 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [954] = 
    {
        [1] = 1691865904517,
        [2] = "2023-08-12 21:45:04.517 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [955] = 
    {
        [1] = 1691865904528,
        [2] = "2023-08-12 21:45:04.528 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [956] = 
    {
        [1] = 1691865904837,
        [2] = "2023-08-12 21:45:04.837 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [957] = 
    {
        [1] = 1691865904837,
        [2] = "2023-08-12 21:45:04.837 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [958] = 
    {
        [1] = 1691865904846,
        [2] = "2023-08-12 21:45:04.846 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [959] = 
    {
        [1] = 1691865904846,
        [2] = "2023-08-12 21:45:04.846 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [960] = 
    {
        [1] = 1691865904855,
        [2] = "2023-08-12 21:45:04.855 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [961] = 
    {
        [1] = 1691865904874,
        [2] = "2023-08-12 21:45:04.874 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [962] = 
    {
        [1] = 1691865904899,
        [2] = "2023-08-12 21:45:04.899 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [963] = 
    {
        [1] = 1691865904908,
        [2] = "2023-08-12 21:45:04.908 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [964] = 
    {
        [1] = 1691865904915,
        [2] = "2023-08-12 21:45:04.915 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [965] = 
    {
        [1] = 1691865904965,
        [2] = "2023-08-12 21:45:04.965 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [966] = 
    {
        [1] = 1691865904973,
        [2] = "2023-08-12 21:45:04.973 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [967] = 
    {
        [1] = 1691865904981,
        [2] = "2023-08-12 21:45:04.981 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [968] = 
    {
        [1] = 1691865904988,
        [2] = "2023-08-12 21:45:04.988 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [969] = 
    {
        [1] = 1691865904998,
        [2] = "2023-08-12 21:45:04.998 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [970] = 
    {
        [1] = 1691865904998,
        [2] = "2023-08-12 21:45:04.998 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [971] = 
    {
        [1] = 1691865904998,
        [2] = "2023-08-12 21:45:04.998 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [972] = 
    {
        [1] = 1691865904998,
        [2] = "2023-08-12 21:45:04.998 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [973] = 
    {
        [1] = 1691865904999,
        [2] = "2023-08-12 21:45:04.999 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [974] = 
    {
        [1] = 1691865905009,
        [2] = "2023-08-12 21:45:05.009 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [975] = 
    {
        [1] = 1691865905014,
        [2] = "2023-08-12 21:45:05.014 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [976] = 
    {
        [1] = 1691865905331,
        [2] = "2023-08-12 21:45:05.331 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [977] = 
    {
        [1] = 1691865905339,
        [2] = "2023-08-12 21:45:05.339 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [978] = 
    {
        [1] = 1691865910130,
        [2] = "2023-08-12 21:45:10.130 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [979] = 
    {
        [1] = 1691865910142,
        [2] = "2023-08-12 21:45:10.142 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [980] = 
    {
        [1] = 1691865910142,
        [2] = "2023-08-12 21:45:10.142 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [981] = 
    {
        [1] = 1691865910150,
        [2] = "2023-08-12 21:45:10.150 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [982] = 
    {
        [1] = 1691865910165,
        [2] = "2023-08-12 21:45:10.165 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [983] = 
    {
        [1] = 1691865910203,
        [2] = "2023-08-12 21:45:10.203 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [984] = 
    {
        [1] = 1691865910226,
        [2] = "2023-08-12 21:45:10.226 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [985] = 
    {
        [1] = 1691865910260,
        [2] = "2023-08-12 21:45:10.260 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [986] = 
    {
        [1] = 1691865910948,
        [2] = "2023-08-12 21:45:10.948 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initial loading screen ended (approximate duration: 11.948s)",
        [7] = "",
    },
    [987] = 
    {
        [1] = 1691871394009,
        [2] = "2023-08-12 23:16:34.009 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 21:44:33.553 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 115/116\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [988] = 
    {
        [1] = 1691871396473,
        [2] = "2023-08-12 23:16:36.473 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [989] = 
    {
        [1] = 1691871396475,
        [2] = "2023-08-12 23:16:36.475 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [990] = 
    {
        [1] = 1691871396476,
        [2] = "2023-08-12 23:16:36.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [991] = 
    {
        [1] = 1691871396476,
        [2] = "2023-08-12 23:16:36.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [992] = 
    {
        [1] = 1691871396476,
        [2] = "2023-08-12 23:16:36.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [993] = 
    {
        [1] = 1691871396476,
        [2] = "2023-08-12 23:16:36.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [994] = 
    {
        [1] = 1691871396476,
        [2] = "2023-08-12 23:16:36.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [995] = 
    {
        [1] = 1691871396476,
        [2] = "2023-08-12 23:16:36.476 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [996] = 
    {
        [1] = 1691871396548,
        [2] = "2023-08-12 23:16:36.548 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [997] = 
    {
        [1] = 1691871396549,
        [2] = "2023-08-12 23:16:36.549 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [998] = 
    {
        [1] = 1691871396549,
        [2] = "2023-08-12 23:16:36.549 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [999] = 
    {
        [1] = 1691871396555,
        [2] = "2023-08-12 23:16:36.555 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [1000] = 
    {
        [1] = 1691871396555,
        [2] = "2023-08-12 23:16:36.555 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [1001] = 
    {
        [1] = 1691871396555,
        [2] = "2023-08-12 23:16:36.555 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [1002] = 
    {
        [1] = 1691871396555,
        [2] = "2023-08-12 23:16:36.555 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [1003] = 
    {
        [1] = 1691871396555,
        [2] = "2023-08-12 23:16:36.555 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [1004] = 
    {
        [1] = 1691871396555,
        [2] = "2023-08-12 23:16:36.555 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [1005] = 
    {
        [1] = 1691871396968,
        [2] = "2023-08-12 23:16:36.968 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [1006] = 
    {
        [1] = 1691871397205,
        [2] = "2023-08-12 23:16:37.205 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [1007] = 
    {
        [1] = 1691871397231,
        [2] = "2023-08-12 23:16:37.231 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [1008] = 
    {
        [1] = 1691871397237,
        [2] = "2023-08-12 23:16:37.237 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/CharacterKnowledge/LibExtendedJournal/'",
        [7] = "",
    },
    [1009] = 
    {
        [1] = 1691871397240,
        [2] = "2023-08-12 23:16:37.240 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [1010] = 
    {
        [1] = 1691871397246,
        [2] = "2023-08-12 23:16:37.246 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [1011] = 
    {
        [1] = 1691871397246,
        [2] = "2023-08-12 23:16:37.246 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [1012] = 
    {
        [1] = 1691871397246,
        [2] = "2023-08-12 23:16:37.246 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [1013] = 
    {
        [1] = 1691871397260,
        [2] = "2023-08-12 23:16:37.260 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [1014] = 
    {
        [1] = 1691871397260,
        [2] = "2023-08-12 23:16:37.260 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [1015] = 
    {
        [1] = 1691871397260,
        [2] = "2023-08-12 23:16:37.260 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [1016] = 
    {
        [1] = 1691871397260,
        [2] = "2023-08-12 23:16:37.260 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [1017] = 
    {
        [1] = 1691871397307,
        [2] = "2023-08-12 23:16:37.307 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [1018] = 
    {
        [1] = 1691871397307,
        [2] = "2023-08-12 23:16:37.307 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [1019] = 
    {
        [1] = 1691871397314,
        [2] = "2023-08-12 23:16:37.314 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [1020] = 
    {
        [1] = 1691871397332,
        [2] = "2023-08-12 23:16:37.332 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [1021] = 
    {
        [1] = 1691871397343,
        [2] = "2023-08-12 23:16:37.343 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [1022] = 
    {
        [1] = 1691871397416,
        [2] = "2023-08-12 23:16:37.416 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [1023] = 
    {
        [1] = 1691871397416,
        [2] = "2023-08-12 23:16:37.416 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [1024] = 
    {
        [1] = 1691871397422,
        [2] = "2023-08-12 23:16:37.422 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [1025] = 
    {
        [1] = 1691871397434,
        [2] = "2023-08-12 23:16:37.434 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [1026] = 
    {
        [1] = 1691871397440,
        [2] = "2023-08-12 23:16:37.440 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [1027] = 
    {
        [1] = 1691871397441,
        [2] = "2023-08-12 23:16:37.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMarify, AddOnVersion: 1217, directory: 'user:/AddOns/LibMarify/'",
        [7] = "",
    },
    [1028] = 
    {
        [1] = 1691871397441,
        [2] = "2023-08-12 23:16:37.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [1029] = 
    {
        [1] = 1691871397441,
        [2] = "2023-08-12 23:16:37.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFeedback, AddOnVersion: 0, directory: 'user:/AddOns/LibFeedback/'",
        [7] = "",
    },
    [1030] = 
    {
        [1] = 1691871397446,
        [2] = "2023-08-12 23:16:37.446 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [1031] = 
    {
        [1] = 1691871397550,
        [2] = "2023-08-12 23:16:37.550 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenuOrderListBox, AddOnVersion: 8, directory: 'user:/AddOns/LibAddonMenuOrderListBox/'",
        [7] = "",
    },
    [1032] = 
    {
        [1] = 1691871397550,
        [2] = "2023-08-12 23:16:37.550 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [1033] = 
    {
        [1] = 1691871397550,
        [2] = "2023-08-12 23:16:37.550 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [1034] = 
    {
        [1] = 1691871397572,
        [2] = "2023-08-12 23:16:37.572 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibShifterBox, AddOnVersion: 500, directory: 'user:/AddOns/LibShifterBox/'",
        [7] = "",
    },
    [1035] = 
    {
        [1] = 1691871397572,
        [2] = "2023-08-12 23:16:37.572 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [1036] = 
    {
        [1] = 1691871397588,
        [2] = "2023-08-12 23:16:37.588 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: FCOItemSaver, AddOnVersion: 249, directory: 'user:/AddOns/FCOItemSaver/'",
        [7] = "",
    },
    [1037] = 
    {
        [1] = 1691871397687,
        [2] = "2023-08-12 23:16:37.687 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/'",
        [7] = "",
    },
    [1038] = 
    {
        [1] = 1691871397705,
        [2] = "2023-08-12 23:16:37.705 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [1039] = 
    {
        [1] = 1691871397712,
        [2] = "2023-08-12 23:16:37.712 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [1040] = 
    {
        [1] = 1691871397727,
        [2] = "2023-08-12 23:16:37.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [1041] = 
    {
        [1] = 1691871397727,
        [2] = "2023-08-12 23:16:37.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [1042] = 
    {
        [1] = 1691871397727,
        [2] = "2023-08-12 23:16:37.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [1043] = 
    {
        [1] = 1691871397727,
        [2] = "2023-08-12 23:16:37.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [1044] = 
    {
        [1] = 1691871397727,
        [2] = "2023-08-12 23:16:37.727 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [1045] = 
    {
        [1] = 1691871397738,
        [2] = "2023-08-12 23:16:37.738 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [1046] = 
    {
        [1] = 1691871397738,
        [2] = "2023-08-12 23:16:37.738 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [1047] = 
    {
        [1] = 1691871397738,
        [2] = "2023-08-12 23:16:37.738 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [1048] = 
    {
        [1] = 1691871397753,
        [2] = "2023-08-12 23:16:37.753 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [1049] = 
    {
        [1] = 1691871397753,
        [2] = "2023-08-12 23:16:37.753 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [1050] = 
    {
        [1] = 1691871397753,
        [2] = "2023-08-12 23:16:37.753 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [1051] = 
    {
        [1] = 1691871397759,
        [2] = "2023-08-12 23:16:37.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [1052] = 
    {
        [1] = 1691871397773,
        [2] = "2023-08-12 23:16:37.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [1053] = 
    {
        [1] = 1691871397773,
        [2] = "2023-08-12 23:16:37.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [1054] = 
    {
        [1] = 1691871397773,
        [2] = "2023-08-12 23:16:37.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [1055] = 
    {
        [1] = 1691871397773,
        [2] = "2023-08-12 23:16:37.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [1056] = 
    {
        [1] = 1691871397773,
        [2] = "2023-08-12 23:16:37.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [1057] = 
    {
        [1] = 1691871397773,
        [2] = "2023-08-12 23:16:37.773 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [1058] = 
    {
        [1] = 1691871397779,
        [2] = "2023-08-12 23:16:37.779 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [1059] = 
    {
        [1] = 1691871398388,
        [2] = "2023-08-12 23:16:38.388 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [1060] = 
    {
        [1] = 1691871398584,
        [2] = "2023-08-12 23:16:38.584 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [1061] = 
    {
        [1] = 1691871398584,
        [2] = "2023-08-12 23:16:38.584 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [1062] = 
    {
        [1] = 1691871398584,
        [2] = "2023-08-12 23:16:38.584 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [1063] = 
    {
        [1] = 1691871398603,
        [2] = "2023-08-12 23:16:38.603 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [1064] = 
    {
        [1] = 1691871398611,
        [2] = "2023-08-12 23:16:38.611 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [1065] = 
    {
        [1] = 1691871398617,
        [2] = "2023-08-12 23:16:38.617 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [1066] = 
    {
        [1] = 1691871398617,
        [2] = "2023-08-12 23:16:38.617 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [1067] = 
    {
        [1] = 1691871398641,
        [2] = "2023-08-12 23:16:38.641 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [1068] = 
    {
        [1] = 1691871398653,
        [2] = "2023-08-12 23:16:38.653 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [1069] = 
    {
        [1] = 1691871398660,
        [2] = "2023-08-12 23:16:38.660 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [1070] = 
    {
        [1] = 1691871399029,
        [2] = "2023-08-12 23:16:39.029 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [1071] = 
    {
        [1] = 1691871399030,
        [2] = "2023-08-12 23:16:39.030 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [1072] = 
    {
        [1] = 1691871399566,
        [2] = "2023-08-12 23:16:39.566 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/'",
        [7] = "",
    },
    [1073] = 
    {
        [1] = 1691871399580,
        [2] = "2023-08-12 23:16:39.580 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [1074] = 
    {
        [1] = 1691871399580,
        [2] = "2023-08-12 23:16:39.580 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [1075] = 
    {
        [1] = 1691871399585,
        [2] = "2023-08-12 23:16:39.585 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AF_FCOItemSaverFilters, AddOnVersion: 193, directory: 'user:/AddOns/AF_FCOItemSaverFilters/'",
        [7] = "",
    },
    [1076] = 
    {
        [1] = 1691871399585,
        [2] = "2023-08-12 23:16:39.585 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [1077] = 
    {
        [1] = 1691871399595,
        [2] = "2023-08-12 23:16:39.595 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [1078] = 
    {
        [1] = 1691871399621,
        [2] = "2023-08-12 23:16:39.621 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [1079] = 
    {
        [1] = 1691871399635,
        [2] = "2023-08-12 23:16:39.635 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [1080] = 
    {
        [1] = 1691871399650,
        [2] = "2023-08-12 23:16:39.650 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [1081] = 
    {
        [1] = 1691871399969,
        [2] = "2023-08-12 23:16:39.969 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [1082] = 
    {
        [1] = 1691871399969,
        [2] = "2023-08-12 23:16:39.969 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [1083] = 
    {
        [1] = 1691871399981,
        [2] = "2023-08-12 23:16:39.981 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [1084] = 
    {
        [1] = 1691871399981,
        [2] = "2023-08-12 23:16:39.981 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [1085] = 
    {
        [1] = 1691871399990,
        [2] = "2023-08-12 23:16:39.990 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [1086] = 
    {
        [1] = 1691871400014,
        [2] = "2023-08-12 23:16:40.014 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [1087] = 
    {
        [1] = 1691871400039,
        [2] = "2023-08-12 23:16:40.039 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [1088] = 
    {
        [1] = 1691871400052,
        [2] = "2023-08-12 23:16:40.052 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [1089] = 
    {
        [1] = 1691871400059,
        [2] = "2023-08-12 23:16:40.059 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [1090] = 
    {
        [1] = 1691871400117,
        [2] = "2023-08-12 23:16:40.117 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [1091] = 
    {
        [1] = 1691871400125,
        [2] = "2023-08-12 23:16:40.125 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [1092] = 
    {
        [1] = 1691871400138,
        [2] = "2023-08-12 23:16:40.138 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [1093] = 
    {
        [1] = 1691871400145,
        [2] = "2023-08-12 23:16:40.145 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [1094] = 
    {
        [1] = 1691871400233,
        [2] = "2023-08-12 23:16:40.233 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [1095] = 
    {
        [1] = 1691871400240,
        [2] = "2023-08-12 23:16:40.240 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantJunk, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantJunk/'",
        [7] = "",
    },
    [1096] = 
    {
        [1] = 1691871400283,
        [2] = "2023-08-12 23:16:40.283 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [1097] = 
    {
        [1] = 1691871400283,
        [2] = "2023-08-12 23:16:40.283 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [1098] = 
    {
        [1] = 1691871400283,
        [2] = "2023-08-12 23:16:40.283 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [1099] = 
    {
        [1] = 1691871400284,
        [2] = "2023-08-12 23:16:40.284 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [1100] = 
    {
        [1] = 1691871400296,
        [2] = "2023-08-12 23:16:40.296 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [1101] = 
    {
        [1] = 1691871400302,
        [2] = "2023-08-12 23:16:40.302 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [1102] = 
    {
        [1] = 1691871400637,
        [2] = "2023-08-12 23:16:40.637 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [1103] = 
    {
        [1] = 1691871400637,
        [2] = "2023-08-12 23:16:40.637 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [1104] = 
    {
        [1] = 1691871400645,
        [2] = "2023-08-12 23:16:40.645 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [1105] = 
    {
        [1] = 1691871405952,
        [2] = "2023-08-12 23:16:45.952 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [1106] = 
    {
        [1] = 1691871405967,
        [2] = "2023-08-12 23:16:45.967 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [1107] = 
    {
        [1] = 1691871405967,
        [2] = "2023-08-12 23:16:45.967 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [1108] = 
    {
        [1] = 1691871405974,
        [2] = "2023-08-12 23:16:45.974 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [1109] = 
    {
        [1] = 1691871405990,
        [2] = "2023-08-12 23:16:45.990 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [1110] = 
    {
        [1] = 1691871406027,
        [2] = "2023-08-12 23:16:46.027 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [1111] = 
    {
        [1] = 1691871406053,
        [2] = "2023-08-12 23:16:46.053 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [1112] = 
    {
        [1] = 1691871406088,
        [2] = "2023-08-12 23:16:46.088 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [1113] = 
    {
        [1] = 1691871406243,
        [2] = "2023-08-12 23:16:46.243 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Loading screen ended (duration: 5384.586s)",
        [7] = "",
    },
    [1114] = 
    {
        [1] = 1691871456003,
        [2] = "2023-08-12 23:17:36.003 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initializing...\n@Dude_47\nGalrnskar Haraendottir\n2023-08-12 21:44:34.338 +0300\neso.live.9.0.8.2716820 (101038)\nEU Megaserver\nPC - Steam (win32)\nkeyboard\nregular\nen\nEnglish\naddon count: 114/116\nallow outdated\nfullscreen (D3D11)\n2560 x 1440\ndefault scale (1)\nxbox gamepad\nregular account",
        [7] = "",
    },
    [1115] = 
    {
        [1] = 1691871458475,
        [2] = "2023-08-12 23:17:38.475 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontStrings",
        [7] = "",
    },
    [1116] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_FontDefs",
        [7] = "",
    },
    [1117] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_IngameLocalization",
        [7] = "",
    },
    [1118] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Libraries",
        [7] = "",
    },
    [1119] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Common",
        [7] = "",
    },
    [1120] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_AppAndInGame",
        [7] = "",
    },
    [1121] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PregameAndIngame",
        [7] = "",
    },
    [1122] = 
    {
        [1] = 1691871458478,
        [2] = "2023-08-12 23:17:38.478 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_PublicAllIngames",
        [7] = "",
    },
    [1123] = 
    {
        [1] = 1691871458550,
        [2] = "2023-08-12 23:17:38.550 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "UI module loaded: ZO_Ingame",
        [7] = "",
    },
    [1124] = 
    {
        [1] = 1691871458551,
        [2] = "2023-08-12 23:17:38.551 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDebugLogger, AddOnVersion: 263, directory: 'user:/AddOns/LibDebugLogger/'",
        [7] = "",
    },
    [1125] = 
    {
        [1] = 1691871458551,
        [2] = "2023-08-12 23:17:38.551 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Initialization complete",
        [7] = "",
    },
    [1126] = 
    {
        [1] = 1691871458557,
        [2] = "2023-08-12 23:17:38.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenu-2.0, AddOnVersion: 34, directory: 'user:/AddOns/LibAddonMenu-2.0/'",
        [7] = "",
    },
    [1127] = 
    {
        [1] = 1691871458557,
        [2] = "2023-08-12 23:17:38.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibVotansAddonList, AddOnVersion: 10903, directory: 'user:/AddOns/LibVotansAddonList/'",
        [7] = "",
    },
    [1128] = 
    {
        [1] = 1691871458557,
        [2] = "2023-08-12 23:17:38.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCustomMenu, AddOnVersion: 721, directory: 'user:/AddOns/LibCustomMenu/'",
        [7] = "",
    },
    [1129] = 
    {
        [1] = 1691871458557,
        [2] = "2023-08-12 23:17:38.557 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFilters-3.0, AddOnVersion: 340, directory: 'user:/AddOns/LibFilters-3.0/'",
        [7] = "",
    },
    [1130] = 
    {
        [1] = 1691871458558,
        [2] = "2023-08-12 23:17:38.558 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMotifCategories, AddOnVersion: 2, directory: 'user:/AddOns/LibMotifCategories/'",
        [7] = "",
    },
    [1131] = 
    {
        [1] = 1691871458558,
        [2] = "2023-08-12 23:17:38.558 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AdvancedFilters, AddOnVersion: 1633, directory: 'user:/AddOns/AdvancedFilters/'",
        [7] = "",
    },
    [1132] = 
    {
        [1] = 1691871458984,
        [2] = "2023-08-12 23:17:38.984 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PerfectPixel, AddOnVersion: 0, directory: 'user:/AddOns/PerfectPixel/'",
        [7] = "",
    },
    [1133] = 
    {
        [1] = 1691871459191,
        [2] = "2023-08-12 23:17:39.191 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridList, AddOnVersion: 0, directory: 'user:/AddOns/GridList/'",
        [7] = "",
    },
    [1134] = 
    {
        [1] = 1691871459212,
        [2] = "2023-08-12 23:17:39.212 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibZone, AddOnVersion: 86, directory: 'user:/AddOns/LibZone/'",
        [7] = "",
    },
    [1135] = 
    {
        [1] = 1691871459218,
        [2] = "2023-08-12 23:17:39.218 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibExtendedJournal, AddOnVersion: 15, directory: 'user:/AddOns/CharacterKnowledge/LibExtendedJournal/'",
        [7] = "",
    },
    [1136] = 
    {
        [1] = 1691871459220,
        [2] = "2023-08-12 23:17:39.220 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountCollectibles, AddOnVersion: 4, directory: 'user:/AddOns/LibMultiAccountCollectibles/'",
        [7] = "",
    },
    [1137] = 
    {
        [1] = 1691871459226,
        [2] = "2023-08-12 23:17:39.226 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: EventCollectibles, AddOnVersion: 0, directory: 'user:/AddOns/EventCollectibles/'",
        [7] = "",
    },
    [1138] = 
    {
        [1] = 1691871459226,
        [2] = "2023-08-12 23:17:39.226 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CustomCompassPins, AddOnVersion: 32, directory: 'user:/AddOns/CustomCompassPins/'",
        [7] = "",
    },
    [1139] = 
    {
        [1] = 1691871459226,
        [2] = "2023-08-12 23:17:39.226 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ActionDurationReminder, AddOnVersion: 30950, directory: 'user:/AddOns/ActionDurationReminder/'",
        [7] = "",
    },
    [1140] = 
    {
        [1] = 1691871459236,
        [2] = "2023-08-12 23:17:39.236 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCharacterKnowledge, AddOnVersion: 20, directory: 'user:/AddOns/LibCharacterKnowledge/'",
        [7] = "",
    },
    [1141] = 
    {
        [1] = 1691871459236,
        [2] = "2023-08-12 23:17:39.236 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibHarvensAddonSettings, AddOnVersion: 10900, directory: 'user:/AddOns/LibHarvensAddonSettings/'",
        [7] = "",
    },
    [1142] = 
    {
        [1] = 1691871459236,
        [2] = "2023-08-12 23:17:39.236 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTextFilter, AddOnVersion: 10, directory: 'user:/AddOns/LibTextFilter/'",
        [7] = "",
    },
    [1143] = 
    {
        [1] = 1691871459236,
        [2] = "2023-08-12 23:17:39.236 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotanSearchBox, AddOnVersion: 0, directory: 'user:/AddOns/VotanSearchBox/'",
        [7] = "",
    },
    [1144] = 
    {
        [1] = 1691871459269,
        [2] = "2023-08-12 23:17:39.269 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMainMenu-2.0, AddOnVersion: 40400, directory: 'user:/AddOns/LibMainMenu-2.0/'",
        [7] = "",
    },
    [1145] = 
    {
        [1] = 1691871459269,
        [2] = "2023-08-12 23:17:39.269 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibChatMessage, AddOnVersion: 105, directory: 'user:/AddOns/LibChatMessage/'",
        [7] = "",
    },
    [1146] = 
    {
        [1] = 1691871459275,
        [2] = "2023-08-12 23:17:39.275 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistant, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/'",
        [7] = "",
    },
    [1147] = 
    {
        [1] = 1691871459288,
        [2] = "2023-08-12 23:17:39.288 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantLoot, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantLoot/'",
        [7] = "",
    },
    [1148] = 
    {
        [1] = 1691871459297,
        [2] = "2023-08-12 23:17:39.297 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: MapPins, AddOnVersion: 0, directory: 'user:/AddOns/MapPins/'",
        [7] = "",
    },
    [1149] = 
    {
        [1] = 1691871459358,
        [2] = "2023-08-12 23:17:39.358 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibNotification, AddOnVersion: 10, directory: 'user:/AddOns/LibNotification/'",
        [7] = "",
    },
    [1150] = 
    {
        [1] = 1691871459358,
        [2] = "2023-08-12 23:17:39.358 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAnnyoingUpdateNotificationInG, AddOnVersion: 7, directory: 'user:/AddOns/LibAnnyoingUpdateNotificationInGame/'",
        [7] = "",
    },
    [1151] = 
    {
        [1] = 1691871459364,
        [2] = "2023-08-12 23:17:39.364 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: NoThankYou, AddOnVersion: 11, directory: 'user:/AddOns/NoThankYou/'",
        [7] = "",
    },
    [1152] = 
    {
        [1] = 1691871459374,
        [2] = "2023-08-12 23:17:39.374 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensPotionsAlert, AddOnVersion: 0, directory: 'user:/AddOns/HarvensPotionsAlert/'",
        [7] = "",
    },
    [1153] = 
    {
        [1] = 1691871459379,
        [2] = "2023-08-12 23:17:39.379 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAdvancedSettings, AddOnVersion: 0, directory: 'user:/AddOns/VotansAdvancedSettings/'",
        [7] = "",
    },
    [1154] = 
    {
        [1] = 1691871459379,
        [2] = "2023-08-12 23:17:39.379 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMarify, AddOnVersion: 1217, directory: 'user:/AddOns/LibMarify/'",
        [7] = "",
    },
    [1155] = 
    {
        [1] = 1691871459379,
        [2] = "2023-08-12 23:17:39.379 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLazyCrafting, AddOnVersion: 3000, directory: 'user:/AddOns/LibLazyCrafting/'",
        [7] = "",
    },
    [1156] = 
    {
        [1] = 1691871459379,
        [2] = "2023-08-12 23:17:39.379 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFeedback, AddOnVersion: 0, directory: 'user:/AddOns/LibFeedback/'",
        [7] = "",
    },
    [1157] = 
    {
        [1] = 1691871459385,
        [2] = "2023-08-12 23:17:39.385 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DolgubonsLazyWritCreator, AddOnVersion: 0, directory: 'user:/AddOns/DolgubonsLazyWritCreator/'",
        [7] = "",
    },
    [1158] = 
    {
        [1] = 1691871459467,
        [2] = "2023-08-12 23:17:39.467 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAddonMenuOrderListBox, AddOnVersion: 8, directory: 'user:/AddOns/LibAddonMenuOrderListBox/'",
        [7] = "",
    },
    [1159] = 
    {
        [1] = 1691871459467,
        [2] = "2023-08-12 23:17:39.467 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibDialog, AddOnVersion: 126, directory: 'user:/AddOns/LibDialog/'",
        [7] = "",
    },
    [1160] = 
    {
        [1] = 1691871459467,
        [2] = "2023-08-12 23:17:39.467 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSets, AddOnVersion: 509, directory: 'user:/AddOns/LibSets/'",
        [7] = "",
    },
    [1161] = 
    {
        [1] = 1691871459488,
        [2] = "2023-08-12 23:17:39.488 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibShifterBox, AddOnVersion: 500, directory: 'user:/AddOns/LibShifterBox/'",
        [7] = "",
    },
    [1162] = 
    {
        [1] = 1691871459488,
        [2] = "2023-08-12 23:17:39.488 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMultiAccountSets, AddOnVersion: 17, directory: 'user:/AddOns/LibMultiAccountSets/'",
        [7] = "",
    },
    [1163] = 
    {
        [1] = 1691871459502,
        [2] = "2023-08-12 23:17:39.502 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: FCOItemSaver, AddOnVersion: 249, directory: 'user:/AddOns/FCOItemSaver/'",
        [7] = "",
    },
    [1164] = 
    {
        [1] = 1691871459581,
        [2] = "2023-08-12 23:17:39.581 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyAlchemy, AddOnVersion: 0, directory: 'user:/AddOns/DailyAlchemy/'",
        [7] = "",
    },
    [1165] = 
    {
        [1] = 1691871459590,
        [2] = "2023-08-12 23:17:39.590 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibResearch, AddOnVersion: 42, directory: 'user:/AddOns/LibResearch/'",
        [7] = "",
    },
    [1166] = 
    {
        [1] = 1691871459596,
        [2] = "2023-08-12 23:17:39.596 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedLocations, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/'",
        [7] = "",
    },
    [1167] = 
    {
        [1] = 1691871459604,
        [2] = "2023-08-12 23:17:39.604 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPing, AddOnVersion: 1236, directory: 'user:/AddOns/LibMapPing/'",
        [7] = "",
    },
    [1168] = 
    {
        [1] = 1691871459604,
        [2] = "2023-08-12 23:17:39.604 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGPS, AddOnVersion: 69, directory: 'user:/AddOns/LibGPS/'",
        [7] = "",
    },
    [1169] = 
    {
        [1] = 1691871459604,
        [2] = "2023-08-12 23:17:39.604 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansTamrielMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansTamrielMap/'",
        [7] = "",
    },
    [1170] = 
    {
        [1] = 1691871459604,
        [2] = "2023-08-12 23:17:39.604 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMediaProvider-1.0, AddOnVersion: 26, directory: 'user:/AddOns/LibMediaProvider-1.0/'",
        [7] = "",
    },
    [1171] = 
    {
        [1] = 1691871459604,
        [2] = "2023-08-12 23:17:39.604 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementsOvw, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/'",
        [7] = "",
    },
    [1172] = 
    {
        [1] = 1691871459618,
        [2] = "2023-08-12 23:17:39.618 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUnits2, AddOnVersion: 101, directory: 'user:/AddOns/RaidNotifier/libs/LibUnits2/'",
        [7] = "",
    },
    [1173] = 
    {
        [1] = 1691871459618,
        [2] = "2023-08-12 23:17:39.618 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListSkins, AddOnVersion: 0, directory: 'user:/AddOns/GridListSkins/'",
        [7] = "",
    },
    [1174] = 
    {
        [1] = 1691871459618,
        [2] = "2023-08-12 23:17:39.618 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantWorker, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantWorker/'",
        [7] = "",
    },
    [1175] = 
    {
        [1] = 1691871459634,
        [2] = "2023-08-12 23:17:39.634 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensBagSpace, AddOnVersion: 0, directory: 'user:/AddOns/HarvensBagSpace/'",
        [7] = "",
    },
    [1176] = 
    {
        [1] = 1691871459634,
        [2] = "2023-08-12 23:17:39.634 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapPins-1.0, AddOnVersion: 10038, directory: 'user:/AddOns/LibMapPins-1.0/'",
        [7] = "",
    },
    [1177] = 
    {
        [1] = 1691871459634,
        [2] = "2023-08-12 23:17:39.634 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibGroupSocket, AddOnVersion: 13, directory: 'user:/AddOns/LibGroupSocket/'",
        [7] = "",
    },
    [1178] = 
    {
        [1] = 1691871459642,
        [2] = "2023-08-12 23:17:39.642 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: RaidNotifier, AddOnVersion: 0, directory: 'user:/AddOns/RaidNotifier/'",
        [7] = "",
    },
    [1179] = 
    {
        [1] = 1691871459655,
        [2] = "2023-08-12 23:17:39.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ImmersiveHorseRiding, AddOnVersion: 0, directory: 'user:/AddOns/ImmersiveHorseRiding/'",
        [7] = "",
    },
    [1180] = 
    {
        [1] = 1691871459655,
        [2] = "2023-08-12 23:17:39.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMsgWin-1.0, AddOnVersion: 11, directory: 'user:/AddOns/LibMsgWin-1.0/'",
        [7] = "",
    },
    [1181] = 
    {
        [1] = 1691871459655,
        [2] = "2023-08-12 23:17:39.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTreasure, AddOnVersion: 15, directory: 'user:/AddOns/LibTreasure/'",
        [7] = "",
    },
    [1182] = 
    {
        [1] = 1691871459655,
        [2] = "2023-08-12 23:17:39.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: libAddonKeybinds, AddOnVersion: 5, directory: 'user:/AddOns/libAddonKeybinds/'",
        [7] = "",
    },
    [1183] = 
    {
        [1] = 1691871459655,
        [2] = "2023-08-12 23:17:39.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombat, AddOnVersion: 70, directory: 'user:/AddOns/LibCombat/'",
        [7] = "",
    },
    [1184] = 
    {
        [1] = 1691871459655,
        [2] = "2023-08-12 23:17:39.655 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetricsFightData, AddOnVersion: 13, directory: 'user:/AddOns/CombatMetrics/CombatMetricsFightData/'",
        [7] = "",
    },
    [1185] = 
    {
        [1] = 1691871459661,
        [2] = "2023-08-12 23:17:39.661 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatMetrics, AddOnVersion: 10515, directory: 'user:/AddOns/CombatMetrics/'",
        [7] = "",
    },
    [1186] = 
    {
        [1] = 1691871460225,
        [2] = "2023-08-12 23:17:40.225 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Srendarr, AddOnVersion: 0, directory: 'user:/AddOns/Srendarr/'",
        [7] = "",
    },
    [1187] = 
    {
        [1] = 1691871460402,
        [2] = "2023-08-12 23:17:40.402 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSavedVars, AddOnVersion: 60007, directory: 'user:/AddOns/LibSavedVars/'",
        [7] = "",
    },
    [1188] = 
    {
        [1] = 1691871460402,
        [2] = "2023-08-12 23:17:40.402 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibLootSummary, AddOnVersion: 30103, directory: 'user:/AddOns/LibLootSummary/'",
        [7] = "",
    },
    [1189] = 
    {
        [1] = 1691871460402,
        [2] = "2023-08-12 23:17:40.402 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Postmaster, AddOnVersion: 40105, directory: 'user:/AddOns/Postmaster/'",
        [7] = "",
    },
    [1190] = 
    {
        [1] = 1691871460420,
        [2] = "2023-08-12 23:17:40.420 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAsync, AddOnVersion: 20304, directory: 'user:/AddOns/LibAsync/'",
        [7] = "",
    },
    [1191] = 
    {
        [1] = 1691871460427,
        [2] = "2023-08-12 23:17:40.427 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansMiniMap, AddOnVersion: 0, directory: 'user:/AddOns/VotansMiniMap/'",
        [7] = "",
    },
    [1192] = 
    {
        [1] = 1691871460433,
        [2] = "2023-08-12 23:17:40.433 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CircularMinimap, AddOnVersion: 0, directory: 'user:/AddOns/CircularMinimap/'",
        [7] = "",
    },
    [1193] = 
    {
        [1] = 1691871460434,
        [2] = "2023-08-12 23:17:40.434 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedQuests, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedQuests/'",
        [7] = "",
    },
    [1194] = 
    {
        [1] = 1691871460456,
        [2] = "2023-08-12 23:17:40.456 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CharacterKnowledge, AddOnVersion: 0, directory: 'user:/AddOns/CharacterKnowledge/'",
        [7] = "",
    },
    [1195] = 
    {
        [1] = 1691871460468,
        [2] = "2023-08-12 23:17:40.468 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibTableFunctions-1.0, AddOnVersion: 101, directory: 'user:/AddOns/LibTableFunctions-1.0/'",
        [7] = "",
    },
    [1196] = 
    {
        [1] = 1691871460475,
        [2] = "2023-08-12 23:17:40.475 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: USPF, AddOnVersion: 60900, directory: 'user:/AddOns/USPF/'",
        [7] = "",
    },
    [1197] = 
    {
        [1] = 1691871460835,
        [2] = "2023-08-12 23:17:40.835 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibUespQuestData, AddOnVersion: 20230607, directory: 'user:/AddOns/LibUespQuestData/'",
        [7] = "",
    },
    [1198] = 
    {
        [1] = 1691871460837,
        [2] = "2023-08-12 23:17:40.837 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: JournalQuestLog, AddOnVersion: 0, directory: 'user:/AddOns/JournalQuestLog/'",
        [7] = "",
    },
    [1199] = 
    {
        [1] = 1691871461374,
        [2] = "2023-08-12 23:17:41.374 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: DailyProvisioning, AddOnVersion: 0, directory: 'user:/AddOns/DailyProvisioning/'",
        [7] = "",
    },
    [1200] = 
    {
        [1] = 1691871461388,
        [2] = "2023-08-12 23:17:41.388 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansCraftingQuickAccess, AddOnVersion: 0, directory: 'user:/AddOns/VotansCraftingQuickAccess/'",
        [7] = "",
    },
    [1201] = 
    {
        [1] = 1691871461388,
        [2] = "2023-08-12 23:17:41.388 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensStackSplitSlider, AddOnVersion: 0, directory: 'user:/AddOns/HarvensStackSplitSlider/'",
        [7] = "",
    },
    [1202] = 
    {
        [1] = 1691871461392,
        [2] = "2023-08-12 23:17:41.392 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: AF_FCOItemSaverFilters, AddOnVersion: 193, directory: 'user:/AddOns/AF_FCOItemSaverFilters/'",
        [7] = "",
    },
    [1203] = 
    {
        [1] = 1691871461393,
        [2] = "2023-08-12 23:17:41.393 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedMulticraft, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedMulticraft/'",
        [7] = "",
    },
    [1204] = 
    {
        [1] = 1691871461401,
        [2] = "2023-08-12 23:17:41.401 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSettingsMenu, AddOnVersion: 0, directory: 'user:/AddOns/VotansSettingsMenu/'",
        [7] = "",
    },
    [1205] = 
    {
        [1] = 1691871461417,
        [2] = "2023-08-12 23:17:41.417 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: ItemBrowser, AddOnVersion: 0, directory: 'user:/AddOns/ItemBrowser/'",
        [7] = "",
    },
    [1206] = 
    {
        [1] = 1691871461428,
        [2] = "2023-08-12 23:17:41.428 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFisherman, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/'",
        [7] = "",
    },
    [1207] = 
    {
        [1] = 1691871461441,
        [2] = "2023-08-12 23:17:41.441 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibMapData, AddOnVersion: 111, directory: 'user:/AddOns/LibMapData/'",
        [7] = "",
    },
    [1208] = 
    {
        [1] = 1691871461759,
        [2] = "2023-08-12 23:17:41.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibFoodDrinkBuff, AddOnVersion: 18, directory: 'user:/AddOns/LibFoodDrinkBuff/'",
        [7] = "",
    },
    [1209] = 
    {
        [1] = 1691871461759,
        [2] = "2023-08-12 23:17:41.759 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantConsume, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantConsume/'",
        [7] = "",
    },
    [1210] = 
    {
        [1] = 1691871461772,
        [2] = "2023-08-12 23:17:41.772 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansSurveyTheWorld, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedLocations/VotansSurveyTheWorld/'",
        [7] = "",
    },
    [1211] = 
    {
        [1] = 1691871461772,
        [2] = "2023-08-12 23:17:41.772 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansGroupPins, AddOnVersion: 0, directory: 'user:/AddOns/VotansGroupPins/'",
        [7] = "",
    },
    [1212] = 
    {
        [1] = 1691871461780,
        [2] = "2023-08-12 23:17:41.780 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishFillet, AddOnVersion: 0, directory: 'user:/AddOns/VotansFishFillet/'",
        [7] = "",
    },
    [1213] = 
    {
        [1] = 1691871461804,
        [2] = "2023-08-12 23:17:41.804 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Dustman, AddOnVersion: 0, directory: 'user:/AddOns/Dustman/'",
        [7] = "",
    },
    [1214] = 
    {
        [1] = 1691871461828,
        [2] = "2023-08-12 23:17:41.828 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantIntegration, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantIntegration/'",
        [7] = "",
    },
    [1215] = 
    {
        [1] = 1691871461841,
        [2] = "2023-08-12 23:17:41.841 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: GridListCleanSkin, AddOnVersion: 0, directory: 'user:/AddOns/GridListCleanSkin/'",
        [7] = "",
    },
    [1216] = 
    {
        [1] = 1691871461848,
        [2] = "2023-08-12 23:17:41.848 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Untaunted, AddOnVersion: 10104, directory: 'user:/AddOns/Untaunted/'",
        [7] = "",
    },
    [1217] = 
    {
        [1] = 1691871461905,
        [2] = "2023-08-12 23:17:41.905 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansAchievementFavorites, AddOnVersion: 0, directory: 'user:/AddOns/VotansAchievementsOvw/VotansAchievementFavorites/'",
        [7] = "",
    },
    [1218] = 
    {
        [1] = 1691871461914,
        [2] = "2023-08-12 23:17:41.914 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LootLog, AddOnVersion: 0, directory: 'user:/AddOns/LootLog/'",
        [7] = "",
    },
    [1219] = 
    {
        [1] = 1691871461926,
        [2] = "2023-08-12 23:17:41.926 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestInfo, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/libs/LibQuestInfo/'",
        [7] = "",
    },
    [1220] = 
    {
        [1] = 1691871461934,
        [2] = "2023-08-12 23:17:41.934 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: Ravalox'QuestTracker, AddOnVersion: 3080214, directory: 'user:/AddOns/Ravalox'QuestTracker/'",
        [7] = "",
    },
    [1221] = 
    {
        [1] = 1691871462022,
        [2] = "2023-08-12 23:17:42.022 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibPrice, AddOnVersion: 70410, directory: 'user:/AddOns/LibPrice/'",
        [7] = "",
    },
    [1222] = 
    {
        [1] = 1691871462022,
        [2] = "2023-08-12 23:17:42.022 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansRuneTooltips, AddOnVersion: 0, directory: 'user:/AddOns/VotansRuneTooltips/'",
        [7] = "",
    },
    [1223] = 
    {
        [1] = 1691871462022,
        [2] = "2023-08-12 23:17:42.022 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibCombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/LibCombatAlerts/'",
        [7] = "",
    },
    [1224] = 
    {
        [1] = 1691871462022,
        [2] = "2023-08-12 23:17:42.022 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CombatAlerts, AddOnVersion: 0, directory: 'user:/AddOns/CombatAlerts/'",
        [7] = "",
    },
    [1225] = 
    {
        [1] = 1691871462023,
        [2] = "2023-08-12 23:17:42.023 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantRepair, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantRepair/'",
        [7] = "",
    },
    [1226] = 
    {
        [1] = 1691871462035,
        [2] = "2023-08-12 23:17:42.035 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: HarvensImprovedSkillsWindow, AddOnVersion: 0, directory: 'user:/AddOns/HarvensImprovedSkillsWindow/'",
        [7] = "",
    },
    [1227] = 
    {
        [1] = 1691871462041,
        [2] = "2023-08-12 23:17:42.041 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibQuestData, AddOnVersion: 260, directory: 'user:/AddOns/LibQuestData/'",
        [7] = "",
    },
    [1228] = 
    {
        [1] = 1691871462363,
        [2] = "2023-08-12 23:17:42.363 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibSFUtils, AddOnVersion: 45, directory: 'user:/AddOns/LibSFUtils/'",
        [7] = "",
    },
    [1229] = 
    {
        [1] = 1691871462363,
        [2] = "2023-08-12 23:17:42.363 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibBinaryEncode, AddOnVersion: 34, directory: 'user:/AddOns/LibBinaryEncode/'",
        [7] = "",
    },
    [1230] = 
    {
        [1] = 1691871462371,
        [2] = "2023-08-12 23:17:42.371 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: CraftStoreFixedAndImproved, AddOnVersion: 0, directory: 'user:/AddOns/CraftStoreFixedAndImproved/'",
        [7] = "",
    },
    [1231] = 
    {
        [1] = 1691871467316,
        [2] = "2023-08-12 23:17:47.316 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansLoreLibrarySearch, AddOnVersion: 0, directory: 'user:/AddOns/VotansLoreLibrarySearch/'",
        [7] = "",
    },
    [1232] = 
    {
        [1] = 1691871467329,
        [2] = "2023-08-12 23:17:47.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: LibAlchemyStation, AddOnVersion: 345, directory: 'user:/AddOns/LibAlchemyStation/'",
        [7] = "",
    },
    [1233] = 
    {
        [1] = 1691871467329,
        [2] = "2023-08-12 23:17:47.329 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansFishermanExport, AddOnVersion: 0, directory: 'user:/AddOns/VotansFisherman/VotansFishermanExport/'",
        [7] = "",
    },
    [1234] = 
    {
        [1] = 1691871467337,
        [2] = "2023-08-12 23:17:47.337 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansKeybinder, AddOnVersion: 0, directory: 'user:/AddOns/VotansKeybinder/'",
        [7] = "",
    },
    [1235] = 
    {
        [1] = 1691871467351,
        [2] = "2023-08-12 23:17:47.351 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PotionMaker, AddOnVersion: 0, directory: 'user:/AddOns/PotionMaker/'",
        [7] = "",
    },
    [1236] = 
    {
        [1] = 1691871467389,
        [2] = "2023-08-12 23:17:47.389 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: VotansImprovedProvisioner, AddOnVersion: 0, directory: 'user:/AddOns/VotansImprovedProvisioner/'",
        [7] = "",
    },
    [1237] = 
    {
        [1] = 1691871467415,
        [2] = "2023-08-12 23:17:47.415 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: PersonalAssistantBanking, AddOnVersion: 20230728, directory: 'user:/AddOns/PersonalAssistant/PersonalAssistantBanking/'",
        [7] = "",
    },
    [1238] = 
    {
        [1] = 1691871467448,
        [2] = "2023-08-12 23:17:47.448 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Addon loaded: has2lam, AddOnVersion: 0, directory: 'user:/AddOns/has2lam/'",
        [7] = "",
    },
    [1239] = 
    {
        [1] = 1691871467598,
        [2] = "2023-08-12 23:17:47.598 +0300",
        [3] = 1,
        [4] = "I",
        [5] = "LibDebugLogger",
        [6] = "Loading screen ended (duration: 19.336s)",
        [7] = "",
    },
}
