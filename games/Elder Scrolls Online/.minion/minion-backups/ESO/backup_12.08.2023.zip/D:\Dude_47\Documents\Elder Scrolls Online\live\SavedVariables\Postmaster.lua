Postmaster_Account =
{
    ["EU Megaserver"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 7,
                ["chatContentsSummary"] = 
                {
                    ["sorted"] = false,
                },
            },
        },
    },
}
Postmaster_Character =
{
}
