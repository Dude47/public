AdvancedFilters_Settings =
{
    ["EU Megaserver"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["Settings"] = 
                {
                    ["showDropdownSelectedReminderAnimation"] = true,
                    ["showIconsInFilterDropdowns"] = true,
                    ["itemCountLabelColor"] = 
                    {
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                    },
                    ["hideItemCount"] = false,
                    ["subfilterBarDropdownLastSelectedEntries"] = 
                    {
                    },
                    ["doDebugOutput"] = false,
                    ["showDropdownLastSelectedEntries"] = true,
                    ["hideSubFilterLabel"] = false,
                    ["version"] = 1.5110000000,
                    ["showFilterDropdownMenuOnRightMouseAtSubFilterButton"] = false,
                    ["debugSpamExcludeRefreshSubfilterBar"] = true,
                    ["hideCharBoundAtBankDeposit"] = false,
                    ["rememberFilterDropdownsLastSelection"] = true,
                    ["grayOutSubFiltersWithNoItems"] = true,
                    ["debugSpam"] = false,
                    ["debugSpamExcludeDropdownBoxFilters"] = true,
                },
            },
        },
    },
}
