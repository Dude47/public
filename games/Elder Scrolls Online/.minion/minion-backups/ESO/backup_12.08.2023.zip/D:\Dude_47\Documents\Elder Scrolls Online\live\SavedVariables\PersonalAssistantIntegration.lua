PersonalAssistantIntegration_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 1,
                [1] = 
                {
                    ["name"] = "Profile 1",
                    ["FCOItemSaver"] = 
                    {
                        ["Deconstruction"] = 
                        {
                            ["itemMoveMode"] = 0,
                        },
                        ["Research"] = 
                        {
                            ["itemMoveMode"] = 0,
                        },
                        ["GearSets"] = 
                        {
                            ["itemMoveMode"] = 
                            {
                                [1] = 0,
                                [2] = 0,
                                [3] = 0,
                                [4] = 0,
                                [5] = 0,
                            },
                        },
                        ["Locked"] = 
                        {
                            ["preventAutoSell"] = false,
                            ["preventMoving"] = false,
                        },
                        ["SellGuildStore"] = 
                        {
                            ["itemMoveMode"] = 0,
                        },
                        ["Sell"] = 
                        {
                            ["autoSellMarked"] = false,
                        },
                        ["DynamicIcons"] = 
                        {
                        },
                        ["Improvement"] = 
                        {
                            ["itemMoveMode"] = 0,
                        },
                        ["Intricate"] = 
                        {
                            ["itemMoveMode"] = 0,
                        },
                    },
                    ["CharacterKnowledge"] = 
                    {
                        ["enabled"] = true,
                        ["characterName"] = "Galrnskar Haraendottir",
                    },
                    ["LazyWritCrafter"] = 
                    {
                        ["compatibility"] = true,
                    },
                },
                ["savedVarsVersion"] = 20230728,
                ["profileCounter"] = 1,
            },
        },
    },
}
