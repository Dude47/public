PotionMaker_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["fakeThirdSlot"] = false,
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["version"] = 1,
                ["lastUsedTab"] = "PotionMaker",
                ["training"] = false,
                ["useUnknown"] = true,
                ["useMissing"] = false,
            },
            ["$AccountWide"] = 
            {
                ["favorites"] = 
                {
                },
                ["filterFavoriteByTraits"] = true,
                ["reagentStackOrder"] = false,
                ["XPMode"] = true,
                ["autoSwitchTab"] = true,
                ["showMainMenuItem"] = true,
                ["useItemSaver"] = true,
                ["showAsDefault"] = true,
                ["version"] = 1,
                ["filterFavoriteByReagents"] = false,
                ["suppressNewTraitDialog"] = false,
                ["filterFavoriteBySolvents"] = true,
                ["showInFavorites"] = "REAGENTS",
            },
        },
    },
}
