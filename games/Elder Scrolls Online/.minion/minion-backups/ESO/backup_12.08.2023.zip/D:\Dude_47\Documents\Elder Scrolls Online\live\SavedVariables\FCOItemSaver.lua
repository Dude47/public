FCOItemSaver_Settings =
{
    ["EU Megaserver"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["SettingsForAll"] = 
                {
                    ["filterButtonsSaveForCharacter"] = false,
                    ["language"] = 1,
                    ["saveMode"] = 2,
                    ["version"] = 999,
                },
                ["Settings"] = 
                {
                    ["autoMarkSetTrackerSetsRescan"] = false,
                    ["allowVendorFilter"] = true,
                    ["showBoundItemMarker"] = false,
                    ["autoMarkSetsNonWishedQuality"] = 1,
                    ["dontUnJunkItemsMarkedToBeSold"] = false,
                    ["showFilterStatusInChat"] = false,
                    ["blockMarkedMotifs"] = true,
                    ["autoMarkNewIconNr"] = 1,
                    ["autoMarkRecipes"] = false,
                    ["autoMarkSetsCheckArmorTraitIcon"] = 
                    {
                        [16] = 2,
                        [17] = 2,
                        [18] = 2,
                        [19] = 2,
                        [20] = 2,
                        [25] = 2,
                        [11] = 2,
                        [12] = 2,
                        [13] = 2,
                        [14] = 2,
                        [15] = 2,
                    },
                    ["iconPositionCrafting"] = 
                    {
                        ["y"] = 0,
                        ["x"] = -5,
                    },
                    ["splitResearchDeconstructionImprovementFilter"] = true,
                    ["autoReenable_blockImprovement"] = true,
                    ["allowJewelryImprovementFilter"] = true,
                    ["allowImproveImprovement"] = true,
                    ["blockGuildBankWithoutWithdrawDisableWithFlag"] = false,
                    ["autoMarkSetsWithTraitCheckAllGearIcons"] = false,
                    ["iconPositionCharacter"] = 
                    {
                        ["y"] = 0,
                        ["x"] = 0,
                    },
                    ["allowBankFilter"] = true,
                    ["atPanelEnabled"] = 
                    {
                        [1] = 
                        {
                            ["filters"] = true,
                        },
                        [2] = 
                        {
                            ["filters"] = true,
                        },
                        [3] = 
                        {
                            ["filters"] = false,
                        },
                        [4] = 
                        {
                            ["filters"] = false,
                        },
                        [5] = 
                        {
                            ["filters"] = false,
                        },
                        [7] = 
                        {
                            ["filters"] = false,
                        },
                        [39] = 
                        {
                            ["filters"] = false,
                        },
                        [37] = 
                        {
                            ["filters"] = false,
                        },
                        [11] = 
                        {
                            ["filters"] = false,
                        },
                        [12] = 
                        {
                            ["filters"] = false,
                        },
                        [13] = 
                        {
                            ["filters"] = false,
                        },
                        [14] = 
                        {
                            ["filters"] = false,
                        },
                        [36] = 
                        {
                            ["filters"] = false,
                        },
                        [16] = 
                        {
                            ["filters"] = false,
                        },
                        [17] = 
                        {
                            ["filters"] = false,
                        },
                        [18] = 
                        {
                            ["filters"] = false,
                        },
                        [19] = 
                        {
                            ["filters"] = false,
                        },
                        [20] = 
                        {
                            ["filters"] = false,
                        },
                        [21] = 
                        {
                            ["filters"] = false,
                        },
                        [35] = 
                        {
                            ["filters"] = false,
                        },
                        [34] = 
                        {
                            ["filters"] = false,
                        },
                        [24] = 
                        {
                            ["filters"] = false,
                        },
                        [25] = 
                        {
                            ["filters"] = false,
                        },
                        [26] = 
                        {
                            ["filters"] = false,
                        },
                        [33] = 
                        {
                            ["filters"] = false,
                        },
                        [28] = 
                        {
                            ["filters"] = false,
                        },
                        [29] = 
                        {
                            ["filters"] = false,
                        },
                        [30] = 
                        {
                            ["filters"] = false,
                        },
                        [31] = 
                        {
                            ["filters"] = false,
                        },
                    },
                    ["autoReenable_blockVendorBuy"] = true,
                    ["markedItemsFCOISUnique"] = 
                    {
                        [1] = 
                        {
                        },
                        [2] = 
                        {
                        },
                        [3] = 
                        {
                        },
                        [4] = 
                        {
                        },
                        [5] = 
                        {
                        },
                        [6] = 
                        {
                        },
                        [7] = 
                        {
                        },
                        [8] = 
                        {
                        },
                        [9] = 
                        {
                        },
                        [10] = 
                        {
                        },
                        [11] = 
                        {
                        },
                        [12] = 
                        {
                        },
                        [13] = 
                        {
                        },
                        [14] = 
                        {
                        },
                        [15] = 
                        {
                        },
                        [16] = 
                        {
                        },
                        [17] = 
                        {
                        },
                        [18] = 
                        {
                        },
                        [19] = 
                        {
                        },
                        [20] = 
                        {
                        },
                        [21] = 
                        {
                        },
                        [22] = 
                        {
                        },
                        [23] = 
                        {
                        },
                        [24] = 
                        {
                        },
                        [25] = 
                        {
                        },
                        [26] = 
                        {
                        },
                        [27] = 
                        {
                        },
                        [28] = 
                        {
                        },
                        [29] = 
                        {
                        },
                        [30] = 
                        {
                        },
                        [31] = 
                        {
                        },
                        [32] = 
                        {
                        },
                        [33] = 
                        {
                        },
                        [34] = 
                        {
                        },
                        [35] = 
                        {
                        },
                        [36] = 
                        {
                        },
                        [37] = 
                        {
                        },
                        [38] = 
                        {
                        },
                        [39] = 
                        {
                        },
                        [40] = 
                        {
                        },
                        [41] = 
                        {
                        },
                        [42] = 
                        {
                        },
                    },
                    ["backupParams"] = 
                    {
                    },
                    ["sortIconsInAdditionalInvFlagContextMenu"] = false,
                    ["autoMarkHigherQuality"] = false,
                    ["contextMenuClearMarkesByShiftKey"] = false,
                    ["autoMarkSetTrackerSets"] = false,
                    ["allowVendorBuybackFilter"] = false,
                    ["autoMarkSetsCheckAllSetTrackerIcons"] = false,
                    ["showFilteredItemCount"] = false,
                    ["iconIsGear"] = 
                    {
                        [1] = false,
                        [2] = true,
                        [3] = false,
                        [4] = true,
                        [5] = false,
                        [6] = true,
                        [7] = true,
                        [8] = true,
                        [9] = false,
                        [10] = false,
                        [11] = false,
                        [12] = false,
                        [13] = true,
                        [14] = true,
                        [15] = true,
                        [16] = false,
                        [17] = false,
                        [18] = false,
                        [19] = false,
                        [20] = false,
                        [21] = false,
                        [22] = false,
                        [23] = false,
                        [24] = false,
                        [25] = false,
                        [26] = false,
                        [27] = false,
                        [28] = false,
                        [29] = false,
                        [30] = false,
                        [31] = false,
                        [32] = false,
                        [33] = false,
                        [34] = false,
                        [35] = false,
                        [36] = false,
                        [37] = false,
                        [38] = false,
                        [39] = false,
                        [40] = false,
                        [41] = false,
                        [42] = false,
                    },
                    ["blockMarkedRecipes"] = true,
                    ["showTooltipAtRestoreLastMarked"] = false,
                    ["autoMarkArmorWeaponJewelry"] = false,
                    ["junkItemsMarkedToBeSold"] = false,
                    ["contextMenuClearMarkesModifierKey"] = 7,
                    ["useZOsLockFunctions"] = true,
                    ["autoMarkSetsCheckWeaponTrait"] = 
                    {
                        [1] = true,
                        [2] = true,
                        [3] = true,
                        [4] = true,
                        [5] = true,
                        [6] = true,
                        [7] = true,
                        [8] = true,
                        [9] = true,
                        [10] = true,
                        [11] = true,
                        [12] = true,
                        [13] = true,
                        [14] = true,
                        [15] = true,
                        [16] = true,
                        [17] = true,
                        [18] = true,
                        [19] = true,
                        [20] = true,
                        [25] = true,
                        [26] = true,
                    },
                    ["isIconEnabled"] = 
                    {
                        [1] = false,
                        [2] = false,
                        [3] = false,
                        [4] = false,
                        [5] = false,
                        [6] = false,
                        [7] = false,
                        [8] = false,
                        [9] = false,
                        [10] = false,
                        [11] = false,
                        [12] = false,
                        [13] = true,
                        [14] = true,
                        [15] = true,
                        [16] = false,
                        [17] = false,
                        [18] = false,
                        [19] = false,
                        [20] = false,
                        [21] = false,
                        [22] = false,
                        [23] = false,
                        [24] = false,
                        [25] = false,
                        [26] = false,
                        [27] = false,
                        [28] = false,
                        [29] = false,
                        [30] = false,
                        [31] = false,
                        [32] = false,
                        [33] = false,
                        [34] = false,
                        [35] = false,
                        [36] = false,
                        [37] = false,
                        [38] = false,
                        [39] = false,
                        [40] = false,
                        [41] = false,
                        [42] = false,
                    },
                    ["blockGuildBankWithoutWithdraw"] = true,
                    ["autoMarkSetsWithTraitCheckAllSetTrackerIcons"] = false,
                    ["splitSellGuildSellIntricateFilter"] = true,
                    ["autoMarkCraftedItemsIconNr"] = 1,
                    ["blockMarkedAutoLootContainerDisableWithFlag"] = false,
                    ["blockRefinement"] = true,
                    ["blockSpecialItemsEnchantment"] = true,
                    ["showFilterButtonContextTooltip"] = true,
                    ["iconSortOrder"] = 
                    {
                        [1] = 1,
                        [2] = 3,
                        [3] = 5,
                        [4] = 9,
                        [5] = 10,
                        [6] = 11,
                        [7] = 12,
                        [8] = 2,
                        [9] = 4,
                        [10] = 6,
                        [11] = 7,
                        [12] = 8,
                        [13] = 13,
                        [14] = 14,
                        [15] = 15,
                        [16] = 16,
                        [17] = 17,
                        [18] = 18,
                        [19] = 19,
                        [20] = 20,
                        [21] = 21,
                        [22] = 22,
                        [23] = 23,
                        [24] = 24,
                        [25] = 25,
                        [26] = 26,
                        [27] = 27,
                        [28] = 28,
                        [29] = 29,
                        [30] = 30,
                        [31] = 31,
                        [32] = 32,
                        [33] = 33,
                        [34] = 34,
                        [35] = 35,
                        [36] = 36,
                        [37] = 37,
                        [38] = 38,
                        [39] = 39,
                        [40] = 40,
                        [41] = 41,
                        [42] = 42,
                    },
                    ["blockJewelryResearch"] = true,
                    ["autoReenable_blockTrading"] = true,
                    ["autoReenable_blockGuildBankWithoutWithdraw"] = true,
                    ["allowVendorRepairFilter"] = false,
                    ["armorTypeIconAtCharacterLightColor"] = 
                    {
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                    },
                    ["autoMarkSetTrackerSetsCheckAllIcons"] = false,
                    ["autoMarkSetsNonWishedSellOthers"] = true,
                    ["recipeAddonUsed"] = 1,
                    ["autoDeMarkSellOnOthersExclusionDynamic"] = false,
                    ["addContextMenuLeadingSpaces"] = 0,
                    ["autoMarkKnownRecipesIconNr"] = 11,
                    ["autoMarkSetsCheckWeaponTraitIcon"] = 
                    {
                        [1] = 2,
                        [2] = 2,
                        [3] = 2,
                        [4] = 2,
                        [5] = 2,
                        [6] = 2,
                        [7] = 2,
                        [8] = 2,
                        [9] = 2,
                        [10] = 2,
                        [11] = 2,
                        [12] = 2,
                        [13] = 2,
                        [14] = 2,
                        [15] = 2,
                        [16] = 2,
                        [17] = 2,
                        [18] = 2,
                        [19] = 2,
                        [20] = 2,
                        [25] = 2,
                        [26] = 2,
                    },
                    ["cleanedFCOISUniqueNILEntries"] = true,
                    ["autoMarkBagsToScanOrder"] = 
                    {
                        [4] = 
                        {
                            ["uniqueKey"] = 29,
                            ["tooltip"] = "Home Storage Withdraw",
                            ["value"] = 7,
                            ["text"] = "Home Storage Withdraw",
                        },
                        [1] = 
                        {
                            ["uniqueKey"] = 1,
                            ["tooltip"] = "Inventory",
                            ["value"] = 1,
                            ["text"] = "Inventory",
                        },
                        [2] = 
                        {
                            ["uniqueKey"] = 2,
                            ["tooltip"] = "Bank Withdraw",
                            ["value"] = 2,
                            ["text"] = "Bank Withdraw",
                        },
                        [3] = 
                        {
                            ["uniqueKey"] = 4,
                            ["tooltip"] = "Guild Bank Withdraw",
                            ["value"] = 3,
                            ["text"] = "Guild Bank Withdraw",
                        },
                    },
                    ["allowSellingForBlockedOrnate"] = true,
                    ["armorTypeIconAtCharacterHeavyColor"] = 
                    {
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                    },
                    ["blockMarkedGlyphs"] = true,
                    ["debug"] = false,
                    ["allowCraftBagFilter"] = false,
                    ["blockDeconstruction"] = true,
                    ["autoMarkPreventIfMarkedForDeconstruction"] = false,
                    ["autoMarkRecipesOnlyThisChar"] = false,
                    ["showAntiMessageInChat"] = true,
                    ["blockVendorBuy"] = false,
                    ["backupData"] = 
                    {
                    },
                    ["deepDebug"] = false,
                    ["blockJewelryImprovement"] = true,
                    ["allowJewelryRefinementFilter"] = false,
                    ["autoReenable_blockVendorBuyback"] = true,
                    ["autoMarkNewItems"] = false,
                    ["autoReenable_blockRetrait"] = true,
                    ["autoMarkSetsItemCollectionBookMissingIcon"] = -100,
                    ["blockMarkedRecipesDisableWithFlag"] = false,
                    ["blockMarkedRepairKits"] = false,
                    ["iconSortOrderEntries"] = 
                    {
                        [1] = 
                        {
                            ["uniqueKey"] = 1,
                            ["tooltip"] = "|cff0000|t20:20:/esoui/art/campaign/campaignbrowser_fullpop.dds:inheritcolor|t|r Lock",
                            ["value"] = 1,
                            ["text"] = "|cff0000|t20:20:/esoui/art/campaign/campaignbrowser_fullpop.dds:inheritcolor|t|r Lock",
                        },
                        [2] = 
                        {
                            ["uniqueKey"] = 3,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/crafting/smithing_tabicon_research_disabled.dds:inheritcolor|t|r Research",
                            ["value"] = 3,
                            ["text"] = "|cffffff|t20:20:/esoui/art/crafting/smithing_tabicon_research_disabled.dds:inheritcolor|t|r Research",
                        },
                        [3] = 
                        {
                            ["uniqueKey"] = 5,
                            ["tooltip"] = "|cffff00|t20:20:/esoui/art/tradinghouse/tradinghouse_sell_tabicon_disabled.dds:inheritcolor|t|r Selling",
                            ["value"] = 5,
                            ["text"] = "|cffff00|t20:20:/esoui/art/tradinghouse/tradinghouse_sell_tabicon_disabled.dds:inheritcolor|t|r Selling",
                        },
                        [4] = 
                        {
                            ["uniqueKey"] = 9,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/crafting/enchantment_tabicon_deconstruction_disabled.dds:inheritcolor|t|r Deconstruction",
                            ["value"] = 9,
                            ["text"] = "|cffffff|t20:20:/esoui/art/crafting/enchantment_tabicon_deconstruction_disabled.dds:inheritcolor|t|r Deconstruction",
                        },
                        [5] = 
                        {
                            ["uniqueKey"] = 10,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/crafting/smithing_tabicon_improve_disabled.dds:inheritcolor|t|r Improvement",
                            ["value"] = 10,
                            ["text"] = "|cffffff|t20:20:/esoui/art/crafting/smithing_tabicon_improve_disabled.dds:inheritcolor|t|r Improvement",
                        },
                        [6] = 
                        {
                            ["uniqueKey"] = 11,
                            ["tooltip"] = "|cffff00|t20:20:/esoui/art/currency/currency_gold.dds:inheritcolor|t|r Sell at guild store",
                            ["value"] = 11,
                            ["text"] = "|cffff00|t20:20:/esoui/art/currency/currency_gold.dds:inheritcolor|t|r Sell at guild store",
                        },
                        [7] = 
                        {
                            ["uniqueKey"] = 12,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/progression/progression_indexicon_guilds_up.dds:inheritcolor|t|r Intricate",
                            ["value"] = 12,
                            ["text"] = "|cffffff|t20:20:/esoui/art/progression/progression_indexicon_guilds_up.dds:inheritcolor|t|r Intricate",
                        },
                        [8] = 
                        {
                            ["uniqueKey"] = 2,
                            ["tooltip"] = "|c00ff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 1",
                            ["value"] = 2,
                            ["text"] = "|c00ff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 1",
                        },
                        [9] = 
                        {
                            ["uniqueKey"] = 4,
                            ["tooltip"] = "|cff00ff|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 2",
                            ["value"] = 4,
                            ["text"] = "|cff00ff|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 2",
                        },
                        [10] = 
                        {
                            ["uniqueKey"] = 6,
                            ["tooltip"] = "|cffff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 3",
                            ["value"] = 6,
                            ["text"] = "|cffff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 3",
                        },
                        [11] = 
                        {
                            ["uniqueKey"] = 7,
                            ["tooltip"] = "|cffff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 4",
                            ["value"] = 7,
                            ["text"] = "|cffff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 4",
                        },
                        [12] = 
                        {
                            ["uniqueKey"] = 8,
                            ["tooltip"] = "|cffff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 5",
                            ["value"] = 8,
                            ["text"] = "|cffff00|t20:20:/esoui/art/inventory/inventory_tabicon_armor_disabled.dds:inheritcolor|t|r Gear 5",
                        },
                        [13] = 
                        {
                            ["uniqueKey"] = 13,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/progression/icon_dualwield.dds:inheritcolor|t|r 1st dynamic",
                            ["value"] = 13,
                            ["text"] = "|cffffff|t20:20:/esoui/art/progression/icon_dualwield.dds:inheritcolor|t|r 1st dynamic",
                        },
                        [14] = 
                        {
                            ["uniqueKey"] = 14,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/progression/icon_firestaff.dds:inheritcolor|t|r 2nd dynamic",
                            ["value"] = 14,
                            ["text"] = "|cffffff|t20:20:/esoui/art/progression/icon_firestaff.dds:inheritcolor|t|r 2nd dynamic",
                        },
                        [15] = 
                        {
                            ["uniqueKey"] = 15,
                            ["tooltip"] = "|cffffff|t20:20:/esoui/art/progression/icon_bows.dds:inheritcolor|t|r 3rd dynamic",
                            ["value"] = 15,
                            ["text"] = "|cffffff|t20:20:/esoui/art/progression/icon_bows.dds:inheritcolor|t|r 3rd dynamic",
                        },
                    },
                    ["allowFenceFilter"] = false,
                    ["autoMarkSetTrackerSetsShowTooltip"] = false,
                    ["useContextMenuCustomMarkedNormalColor"] = true,
                    ["lastGearFilterIconId"] = 
                    {
                        [39] = -1,
                        [1] = -1,
                        [2] = -1,
                        [3] = -1,
                        [4] = -1,
                        [5] = -1,
                        [6] = -1,
                        [7] = -1,
                        [8] = -1,
                        [9] = -1,
                        [37] = -1,
                        [11] = -1,
                        [12] = -1,
                        [13] = -1,
                        [14] = -1,
                        [36] = -1,
                        [16] = -1,
                        [17] = -1,
                        [18] = -1,
                        [19] = -1,
                        [20] = -1,
                        [21] = -1,
                        [35] = -1,
                        [34] = -1,
                        [24] = -1,
                        [25] = -1,
                        [26] = -1,
                        [33] = -1,
                        [28] = -1,
                        [29] = -1,
                        [30] = -1,
                        [31] = -1,
                    },
                    ["iconPosition"] = 
                    {
                        ["y"] = 0,
                        ["x"] = 0,
                    },
                    ["filterButtonLeft"] = 
                    {
                        [4] = 72,
                        [1] = 0,
                        [2] = 24,
                        [3] = 48,
                    },
                    ["armorTypeIconAtCharacterMediumColor"] = 
                    {
                        ["b"] = 1,
                        ["g"] = 1,
                        ["r"] = 1,
                        ["a"] = 1,
                    },
                    ["autoMarkBagsChatOutput"] = false,
                    ["allowVendorBuyFilter"] = false,
                    ["allowSellingForBlocked"] = true,
                    ["blockImprovement"] = true,
                    ["languageChosen"] = false,
                    ["allowSellingForBlockedIntricate"] = false,
                    ["contextMenuItemEntryShowTooltip"] = false,
                    ["autoMarkSetsCheckJewelryTraitIcon"] = 
                    {
                        [32] = 2,
                        [33] = 2,
                        [21] = 2,
                        [22] = 2,
                        [23] = 2,
                        [24] = 2,
                        [27] = 2,
                        [28] = 2,
                        [29] = 2,
                        [30] = 2,
                        [31] = 2,
                    },
                    ["blockEnchantingCreation"] = true,
                    ["autoMarkRecipesIconNr"] = 1,
                    ["autoBindMissingSetCollectionPiecesOnLootMarkKnown"] = false,
                    ["autoReenable_blockAlchemyDestroy"] = true,
                    ["showAntiMessageAsAlert"] = true,
                    ["autoMarkPreventIfMarkedForSellAtGuildStore"] = false,
                    ["allowLaunderFilter"] = false,
                    ["checkDeactivatedIcons"] = false,
                    ["autoReenable_blockSelling"] = true,
                    ["allowedFCOISUniqueIdItemTypes"] = 
                    {
                        [1] = true,
                        [2] = true,
                        [3] = false,
                        [4] = false,
                        [5] = false,
                        [6] = false,
                        [7] = false,
                        [8] = false,
                        [9] = false,
                        [10] = false,
                        [11] = false,
                        [12] = false,
                        [13] = false,
                        [14] = false,
                        [15] = false,
                        [16] = false,
                        [17] = false,
                        [18] = false,
                        [19] = false,
                        [20] = false,
                        [21] = false,
                        [22] = false,
                        [23] = false,
                        [24] = false,
                        [25] = false,
                        [26] = false,
                        [27] = false,
                        [28] = false,
                        [29] = false,
                        [30] = false,
                        [31] = false,
                        [32] = false,
                        [33] = false,
                        [34] = false,
                        [35] = false,
                        [36] = false,
                        [37] = false,
                        [38] = false,
                        [39] = false,
                        [40] = false,
                        [41] = false,
                        [42] = false,
                        [43] = false,
                        [44] = false,
                        [45] = false,
                        [46] = false,
                        [47] = false,
                        [48] = false,
                        [49] = false,
                        [50] = false,
                        [51] = false,
                        [52] = false,
                        [53] = false,
                        [54] = false,
                        [55] = false,
                        [56] = false,
                        [57] = false,
                        [58] = false,
                        [59] = false,
                        [60] = false,
                        [61] = false,
                        [62] = false,
                        [63] = false,
                        [64] = false,
                        [65] = false,
                        [66] = false,
                        [67] = false,
                        [68] = false,
                        [69] = false,
                        [70] = false,
                        [71] = false,
                    },
                    ["autoMarkSetsWithTraitCheckAllIcons"] = false,
                    ["blockAlchemyDestroy"] = true,
                    ["autoMarkCraftedWritCreatorMasterWritItemsIconNr"] = 1,
                    ["showSetCollectionMarkedInChat"] = false,
                    ["allowMarkAsJunkForMarkedToBeSold"] = true,
                    ["autoMarkSetsExcludeSetsList"] = 
                    {
                    },
                    ["allowEnchantingFilter"] = false,
                    ["autoDeMarkSell"] = false,
                    ["autoReenable_blockEnchantingExtraction"] = true,
                    ["allowCompanionInventoryFilter"] = false,
                    ["autoMarkSetsNonWishedIconNr"] = 9,
                    ["autoMarkSetsCheckSellIcons"] = false,
                    ["numMaxDynamicIconsUsable"] = 3,
                    ["blockResearch"] = true,
                    ["allowSellingGuildStoreForBlockedIntricate"] = false,
                    ["autoMarkQualityCheckAllIcons"] = false,
                    ["autoDeMarkDeconstruct"] = false,
                    ["autoMarkResearchOnlyLoggedInChar"] = false,
                    ["autoReenable_blockJewelryRefinement"] = true,
                    ["disableResearchCheck"] = 
                    {
                        [1] = false,
                        [2] = false,
                        [3] = false,
                        [4] = false,
                        [5] = false,
                        [6] = false,
                        [7] = false,
                        [8] = false,
                        [9] = false,
                        [10] = false,
                        [11] = false,
                        [12] = false,
                        [13] = true,
                        [14] = true,
                        [15] = true,
                        [16] = true,
                        [17] = true,
                        [18] = true,
                        [19] = true,
                        [20] = true,
                        [21] = true,
                        [22] = true,
                        [23] = true,
                        [24] = true,
                        [25] = true,
                        [26] = true,
                        [27] = true,
                        [28] = true,
                        [29] = true,
                        [30] = true,
                        [31] = true,
                        [32] = true,
                        [33] = true,
                        [34] = true,
                        [35] = true,
                        [36] = true,
                        [37] = true,
                        [38] = true,
                        [39] = true,
                        [40] = true,
                        [41] = true,
                        [42] = true,
                    },
                    ["autoReenable_blockSellingGuildStore"] = true,
                    ["autoMarkSetTrackerSetsGuildBank"] = false,
                    ["autoBindMissingSetCollectionPiecesOnLoot"] = false,
                    ["allowRetraitFilter"] = true,
                    ["blockVendorBuyback"] = false,
                    ["showMarkerTooltip"] = 
                    {
                        [1] = true,
                        [2] = true,
                        [3] = true,
                        [4] = true,
                        [5] = true,
                        [6] = true,
                        [7] = true,
                        [8] = true,
                        [9] = true,
                        [10] = true,
                        [11] = true,
                        [12] = true,
                        [13] = false,
                        [14] = false,
                        [15] = false,
                        [16] = true,
                        [17] = true,
                        [18] = true,
                        [19] = true,
                        [20] = true,
                        [21] = true,
                        [22] = true,
                        [23] = true,
                        [24] = true,
                        [25] = true,
                        [26] = true,
                        [27] = true,
                        [28] = true,
                        [29] = true,
                        [30] = true,
                        [31] = true,
                        [32] = true,
                        [33] = true,
                        [34] = true,
                        [35] = true,
                        [36] = true,
                        [37] = true,
                        [38] = true,
                        [39] = true,
                        [40] = true,
                        [41] = true,
                        [42] = true,
                    },
                    ["autoMarkSetsOnlyTraits"] = false,
                    ["useSubContextMenu"] = true,
                    ["autoMarkSets"] = false,
                    ["contextMenuEntryColorEqualsIconColor"] = true,
                    ["lastSellGuildIntFilterIconId"] = 
                    {
                        [39] = -1,
                        [1] = -1,
                        [2] = -1,
                        [3] = -1,
                        [4] = -1,
                        [5] = -1,
                        [6] = -1,
                        [7] = -1,
                        [8] = -1,
                        [9] = -1,
                        [37] = -1,
                        [11] = -1,
                        [12] = -1,
                        [13] = -1,
                        [14] = -1,
                        [36] = -1,
                        [16] = -1,
                        [17] = -1,
                        [18] = -1,
                        [19] = -1,
                        [20] = -1,
                        [21] = -1,
                        [35] = -1,
                        [34] = -1,
                        [24] = -1,
                        [25] = -1,
                        [26] = -1,
                        [33] = -1,
                        [28] = -1,
                        [29] = -1,
                        [30] = -1,
                        [31] = -1,
                    },
                    ["autoMarkCraftedItemsSets"] = false,
                    ["autoMarkWastedResearchScrolls"] = true,
                    ["autoMarkSetsNonWished"] = false,
                    ["autoDeMarkDeconstructionOnOthersExclusionDynamic"] = false,
                    ["showFCOISMenuBarButton"] = true,
                    ["filterButtonData"] = 
                    {
                        [4] = 
                        {
                            [1] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [2] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [3] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [4] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [5] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [6] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [7] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [8] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [9] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [10] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [11] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [12] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [13] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [14] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [15] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [16] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [17] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [18] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [19] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [20] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [21] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [22] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [23] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [24] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [25] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [26] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [27] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [28] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [29] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [30] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [31] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [32] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [33] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [34] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [35] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [36] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [37] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [38] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 72,
                            },
                            [39] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                        },
                        [1] = 
                        {
                            [1] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [2] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [3] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [4] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [5] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [6] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [7] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [8] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [9] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [10] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [11] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [12] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [13] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [14] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [15] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [16] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [17] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [18] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [19] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [20] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [21] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [22] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [23] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [24] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [25] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [26] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [27] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [28] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [29] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [30] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [31] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [32] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [33] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [34] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [35] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [36] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [37] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [38] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 0,
                            },
                            [39] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                        },
                        [2] = 
                        {
                            [1] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [2] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [3] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [4] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [5] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [6] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [7] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [8] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [9] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [10] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [11] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [12] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [13] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [14] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [15] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [16] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [17] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [18] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [19] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [20] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [21] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [22] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [23] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [24] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [25] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [26] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [27] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [28] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [29] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [30] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [31] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [32] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [33] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [34] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [35] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [36] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [37] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [38] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                            [39] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 24,
                            },
                        },
                        [3] = 
                        {
                            [1] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [2] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [3] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [4] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [5] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [6] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [7] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [8] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [9] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [10] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [11] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [12] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [13] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [14] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [15] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [16] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [17] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [18] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [19] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [20] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [21] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [22] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [23] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [24] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [25] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [26] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [27] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [28] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [29] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [30] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [31] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [32] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [33] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [34] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [35] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [36] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [37] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                            [38] = 
                            {
                                ["height"] = 24,
                                ["width"] = 24,
                                ["top"] = 6,
                                ["left"] = 48,
                            },
                            [39] = 
                            {
                                ["width"] = 24,
                                ["height"] = 24,
                                ["top"] = 6,
                                ["left"] = 9999,
                            },
                        },
                    },
                    ["autoReenable_blockEnchantingCreation"] = true,
                    ["addonFCOISChangedDynIconMaxUsableSlider"] = false,
                    ["icon"] = 
                    {
                        [1] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 1,
                        },
                        [2] = 
                        {
                            ["name"] = "Gear 1",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 1,
                                ["r"] = 0,
                                ["a"] = 1,
                            },
                            ["texture"] = 2,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 8,
                        },
                        [3] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 3,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 2,
                        },
                        [4] = 
                        {
                            ["name"] = "Gear 2",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 2,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 9,
                        },
                        [5] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 4,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 3,
                        },
                        [6] = 
                        {
                            ["name"] = "Gear 3",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 2,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 10,
                        },
                        [7] = 
                        {
                            ["name"] = "Gear 4",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 2,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 11,
                        },
                        [8] = 
                        {
                            ["name"] = "Gear 5",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 2,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 12,
                        },
                        [9] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 55,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 4,
                        },
                        [10] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 56,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 5,
                        },
                        [11] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 58,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 6,
                        },
                        [12] = 
                        {
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["demarkAllOthers"] = false,
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["texture"] = 60,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = false,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [26] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = false,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = true,
                            },
                            ["sortOrder"] = 7,
                        },
                        [13] = 
                        {
                            ["name"] = "Equipment",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 13,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = false,
                                [37] = false,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [14] = 
                        {
                            ["name"] = "Consumables",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 14,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = true,
                                [2] = true,
                                [3] = true,
                                [5] = true,
                                [6] = false,
                                [7] = true,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = true,
                                [12] = true,
                                [13] = true,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = true,
                                [30] = true,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = false,
                                [37] = false,
                                [38] = false,
                                [39] = true,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [15] = 
                        {
                            ["name"] = "Crafting Writs",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 15,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = true,
                                [2] = true,
                                [3] = true,
                                [5] = true,
                                [6] = false,
                                [7] = true,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = true,
                                [12] = true,
                                [13] = true,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = true,
                                [30] = true,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = false,
                                [37] = false,
                                [38] = false,
                                [39] = true,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [16] = 
                        {
                            ["name"] = "4th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 16,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 49,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [17] = 
                        {
                            ["name"] = "5th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 17,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 50,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [18] = 
                        {
                            ["name"] = "6th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 18,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 51,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [19] = 
                        {
                            ["name"] = "7th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 19,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 52,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [20] = 
                        {
                            ["name"] = "8th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 20,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 53,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [21] = 
                        {
                            ["name"] = "9th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 21,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 54,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [22] = 
                        {
                            ["name"] = "10th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 22,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 1,
                                ["g"] = 1,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 55,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [23] = 
                        {
                            ["name"] = "11th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 23,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [24] = 
                        {
                            ["name"] = "12th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 24,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [25] = 
                        {
                            ["name"] = "13th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 25,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [26] = 
                        {
                            ["name"] = "14th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 26,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [27] = 
                        {
                            ["name"] = "15th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 27,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [28] = 
                        {
                            ["name"] = "16th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 28,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [29] = 
                        {
                            ["name"] = "17th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 29,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [30] = 
                        {
                            ["name"] = "18th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 30,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [31] = 
                        {
                            ["name"] = "19th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 31,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [32] = 
                        {
                            ["name"] = "20th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 32,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [33] = 
                        {
                            ["name"] = "21st dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 33,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [34] = 
                        {
                            ["name"] = "22nd dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 34,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [35] = 
                        {
                            ["name"] = "23rd dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 35,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [36] = 
                        {
                            ["name"] = "24th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 36,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [37] = 
                        {
                            ["name"] = "25th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 37,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [38] = 
                        {
                            ["name"] = "26th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 38,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [39] = 
                        {
                            ["name"] = "27th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 39,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [40] = 
                        {
                            ["name"] = "28th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 40,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [41] = 
                        {
                            ["name"] = "29th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 41,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                        [42] = 
                        {
                            ["name"] = "30th dynamic",
                            ["demarkAllOthersExcludeNormal"] = false,
                            ["size"] = 32,
                            ["offsets"] = 
                            {
                                [1] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [2] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [3] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [4] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [5] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [6] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [7] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [8] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [9] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [10] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [11] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [12] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [13] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [14] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [15] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [16] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [17] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [18] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [19] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [20] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [21] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [22] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [23] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [24] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [25] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [26] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [27] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [28] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [29] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [30] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [31] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [32] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [33] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [34] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [35] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [36] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [37] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [38] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                                [39] = 
                                {
                                    ["top"] = 0,
                                    ["left"] = 0,
                                },
                            },
                            ["demarkAllOthers"] = false,
                            ["sortOrder"] = 42,
                            ["autoRemoveMarkForBag"] = 
                            {
                                [2] = false,
                                [3] = false,
                            },
                            ["color"] = 
                            {
                                ["b"] = 0,
                                ["g"] = 0,
                                ["r"] = 1,
                                ["a"] = 1,
                            },
                            ["autoMarkPreventIfMarkedWithThis"] = false,
                            ["texture"] = 1,
                            ["demarkAllOthersExcludeDynamic"] = false,
                            ["antiCheckAtPanel"] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [5] = false,
                                [6] = false,
                                [7] = false,
                                [8] = false,
                                [9] = false,
                                [10] = false,
                                [11] = false,
                                [12] = false,
                                [13] = false,
                                [14] = false,
                                [15] = false,
                                [16] = false,
                                [17] = false,
                                [18] = true,
                                [19] = false,
                                [20] = false,
                                [21] = false,
                                [22] = false,
                                [23] = false,
                                [24] = false,
                                [25] = false,
                                [27] = false,
                                [28] = false,
                                [29] = false,
                                [30] = false,
                                [31] = false,
                                [32] = false,
                                [33] = false,
                                [34] = false,
                                [35] = true,
                                [36] = true,
                                [37] = true,
                                [38] = false,
                                [39] = false,
                            },
                            ["temporaryDisableByInventoryFlagIcon"] = false,
                        },
                    },
                    ["blockJewelryRefinement"] = true,
                    ["keybindMoveItemToJunkAddSellIcon"] = false,
                    ["showFCOISAdditionalInventoriesButton"] = true,
                    ["allowedCraftSkillsForCraftedMarking"] = 
                    {
                        [0] = false,
                        [1] = true,
                        [2] = true,
                        [3] = true,
                        [4] = false,
                        [5] = false,
                        [6] = true,
                        [7] = true,
                    },
                    ["autoMarkResearchCheckAllIcons"] = false,
                    ["autoMarkSetTrackerSetsWorn"] = false,
                    ["contextMenuItemEntryTooltipProtectedPanels"] = false,
                    ["blockSendingByMail"] = true,
                    ["reApplyIconsAfterImprovement"] = true,
                    ["blockSelling"] = true,
                    ["showContextMenuDivider"] = true,
                    ["autoReenable_blockVendorRepair"] = true,
                    ["researchAddonUsed"] = 3,
                    ["useDynSubMenuMaxCount"] = 3,
                    ["showIconTooltipAtCharacter"] = false,
                    ["useUniqueIds"] = false,
                    ["blockMarkedFood"] = false,
                    ["testHooks"] = false,
                    ["lastResDecImpFilterIconId"] = 
                    {
                        [39] = -1,
                        [1] = -1,
                        [2] = -1,
                        [3] = -1,
                        [4] = -1,
                        [5] = -1,
                        [6] = -1,
                        [7] = -1,
                        [8] = -1,
                        [9] = -1,
                        [37] = -1,
                        [11] = -1,
                        [12] = -1,
                        [13] = -1,
                        [14] = -1,
                        [36] = -1,
                        [16] = -1,
                        [17] = -1,
                        [18] = -1,
                        [19] = -1,
                        [20] = -1,
                        [21] = -1,
                        [35] = -1,
                        [34] = -1,
                        [24] = -1,
                        [25] = -1,
                        [26] = -1,
                        [33] = -1,
                        [28] = -1,
                        [29] = -1,
                        [30] = -1,
                        [31] = -1,
                    },
                    ["allowRefinementFilter"] = false,
                    ["dontUnjunkOnBulkMark"] = false,
                    ["allowAlchemyFilter"] = false,
                    ["contextMenuDividerShowsSettings"] = false,
                    ["blockResearchDialog"] = true,
                    ["autoMarkSetTrackerSetsBank"] = false,
                    ["autoMarkSetsIconNr"] = 2,
                    ["iconSizeCharacter"] = 20,
                    ["autoReenable_blockJewelryImprovement"] = true,
                    ["filterButtonSettings"] = 
                    {
                        [1] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [2] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [3] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [4] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [5] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [7] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [39] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [37] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [11] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [12] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [13] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [14] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [36] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [16] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [17] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [18] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [19] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [20] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [21] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [35] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [34] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [24] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [25] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [26] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [33] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [28] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [29] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [30] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                        [31] = 
                        {
                            [4] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [1] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [2] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                            [3] = 
                            {
                                ["filterWithLogicalAND"] = true,
                            },
                        },
                    },
                    ["blockRetrait"] = true,
                    ["colorizeFCOISAdditionalInventoriesButton"] = true,
                    ["dontUnjunkOnNormalMark"] = false,
                    ["blockSellingGuildStore"] = true,
                    ["setTrackerIndexToFCOISIcon"] = 
                    {
                    },
                    ["autoMarkSetsWithTraitCheckSellIcons"] = false,
                    ["autoMarkSetsExcludeSets"] = false,
                    ["autoMarkSetsItemCollectionBookOnlyCurrentAccount"] = true,
                    ["uniqueIdParts"] = 
                    {
                        ["trait"] = true,
                        ["isCrownItem"] = false,
                        ["enchantment"] = true,
                        ["isCrafted"] = true,
                        ["level"] = true,
                        ["isCraftedBy"] = true,
                        ["quality"] = true,
                        ["isStolen"] = true,
                        ["style"] = true,
                    },
                    ["autoMarkSetsNonWishedChecks"] = -1,
                    ["blockJewelryResearchDialog"] = true,
                    ["autoMarkNewItemsCheckOthers"] = false,
                    ["autoMarkSetsCheckJewelryTrait"] = 
                    {
                        [32] = true,
                        [33] = true,
                        [21] = true,
                        [22] = true,
                        [23] = true,
                        [24] = true,
                        [27] = true,
                        [28] = true,
                        [29] = true,
                        [30] = true,
                        [31] = true,
                    },
                    ["keybindMoveItemToJunkEnabled"] = false,
                    ["remindUserAboutSavedVariablesBackup"] = true,
                    ["autoDeMarkSellOnOthers"] = false,
                    ["autoReenable_blockLaunderSelling"] = true,
                    ["allowOnlyUnbound"] = 
                    {
                        [1] = false,
                        [2] = false,
                        [3] = false,
                        [4] = false,
                        [5] = false,
                        [6] = false,
                        [7] = false,
                        [8] = false,
                        [9] = false,
                        [10] = false,
                        [11] = false,
                        [12] = false,
                        [13] = false,
                        [14] = false,
                        [15] = false,
                        [16] = false,
                        [17] = false,
                        [18] = false,
                        [19] = false,
                        [20] = false,
                        [21] = false,
                        [22] = false,
                        [23] = false,
                        [24] = false,
                        [25] = false,
                        [26] = false,
                        [27] = false,
                        [28] = false,
                        [29] = false,
                        [30] = false,
                        [31] = false,
                        [32] = false,
                        [33] = false,
                        [34] = false,
                        [35] = false,
                        [36] = false,
                        [37] = false,
                        [38] = false,
                        [39] = false,
                        [40] = false,
                        [41] = false,
                        [42] = false,
                    },
                    ["showRecipesInChat"] = false,
                    ["uniqueItemIdType"] = 1,
                    ["blockLaunder"] = true,
                    ["autoMarkQuality"] = 1,
                    ["autoMarkOrnate"] = false,
                    ["blockMarkedCrownStoreItemDisableWithFlag"] = false,
                    ["autoMarkQualityIconNr"] = 1,
                    ["markedItems"] = 
                    {
                        [1] = 
                        {
                        },
                        [2] = 
                        {
                        },
                        [3] = 
                        {
                        },
                        [4] = 
                        {
                        },
                        [5] = 
                        {
                        },
                        [6] = 
                        {
                        },
                        [7] = 
                        {
                        },
                        [8] = 
                        {
                        },
                        [9] = 
                        {
                        },
                        [10] = 
                        {
                        },
                        [11] = 
                        {
                        },
                        [12] = 
                        {
                        },
                        [13] = 
                        {
                        },
                        [14] = 
                        {
                        },
                        [15] = 
                        {
                        },
                        [16] = 
                        {
                        },
                        [17] = 
                        {
                        },
                        [18] = 
                        {
                        },
                        [19] = 
                        {
                        },
                        [20] = 
                        {
                        },
                        [21] = 
                        {
                        },
                        [22] = 
                        {
                        },
                        [23] = 
                        {
                        },
                        [24] = 
                        {
                        },
                        [25] = 
                        {
                        },
                        [26] = 
                        {
                        },
                        [27] = 
                        {
                        },
                        [28] = 
                        {
                        },
                        [29] = 
                        {
                        },
                        [30] = 
                        {
                        },
                        [31] = 
                        {
                        },
                        [32] = 
                        {
                        },
                        [33] = 
                        {
                        },
                        [34] = 
                        {
                        },
                        [35] = 
                        {
                        },
                        [36] = 
                        {
                        },
                        [37] = 
                        {
                        },
                        [38] = 
                        {
                        },
                        [39] = 
                        {
                        },
                        [40] = 
                        {
                        },
                        [41] = 
                        {
                        },
                        [42] = 
                        {
                        },
                    },
                    ["filterButtonContextMenuMaxIcons"] = 6,
                    ["autoMarkSetsItemCollectionBookCheckAllIcons"] = false,
                    ["showIntricateItemsInChat"] = false,
                    ["blockMarkedFoodDisableWithFlag"] = false,
                    ["showArmorTypeIconAtCharacter"] = false,
                    ["cleanedFCOISUniqueInNonUnique"] = true,
                    ["standardIconOnKeybind"] = 1,
                    ["addContextMenuLeadingMarkerIcon"] = true,
                    ["autoReenable_blockSendingByMail"] = true,
                    ["blockFence"] = true,
                    ["blockDestroying"] = true,
                    ["showArmorTypeHeaderTextAtCharacter"] = false,
                    ["allowJewelryResearchFilter"] = false,
                    ["allowResearchFilter"] = false,
                    ["blockTrading"] = true,
                    ["autoMarkSetTrackerSetsInv"] = true,
                    ["filterButtonTop"] = 
                    {
                        [1] = 6,
                        [2] = 6,
                        [3] = 6,
                        [4] = 6,
                        [5] = 6,
                        [6] = 6,
                        [7] = 6,
                        [8] = 6,
                        [9] = 6,
                        [10] = 6,
                        [11] = 6,
                        [12] = 6,
                        [13] = 6,
                        [14] = 6,
                        [15] = 6,
                        [16] = 6,
                        [17] = 6,
                        [18] = 6,
                        [19] = 6,
                        [20] = 6,
                        [21] = 6,
                        [22] = 6,
                        [23] = 6,
                        [24] = 6,
                        [25] = 6,
                        [26] = 6,
                        [27] = 6,
                        [28] = 6,
                        [29] = 6,
                        [30] = 6,
                        [31] = 6,
                        [32] = 6,
                        [33] = 6,
                        [34] = 6,
                        [35] = 6,
                        [36] = 6,
                        [37] = 6,
                        [38] = 6,
                        [39] = 6,
                        [40] = 6,
                        [41] = 6,
                        [42] = 6,
                    },
                    ["autoReenable_blockRefinement"] = true,
                    ["splitLockDynFilter"] = true,
                    ["showResearchItemsInChat"] = false,
                    ["autoMarkSetsCheckAllIcons"] = false,
                    ["allowDeconstructDeconstruction"] = true,
                    ["reApplyIconsAfterEnchanting"] = true,
                    ["showSetsInChat"] = false,
                    ["armorTypeIconAtCharacterY"] = 15,
                    ["allowJewelryDeconstructionFilter"] = false,
                    ["showTransmutationGeodeLootDialog"] = true,
                    ["autoMarkKnownRecipes"] = false,
                    ["autoDeMarkDeconstructionOnOthers"] = false,
                    ["addRemoveAllMarkerIconsToItemContextMenu"] = false,
                    ["isFilterOn"] = 
                    {
                        [4] = false,
                        [1] = false,
                        [2] = false,
                        [3] = false,
                    },
                    ["showFilterButtonTooltip"] = false,
                    ["blockCrownStoreItems"] = false,
                    ["autoReenable_blockDestroying"] = true,
                    ["allowTradinghouseFilter"] = true,
                    ["autoDeMarkSellInGuildStore"] = false,
                    ["blockEnchantingExtraction"] = true,
                    ["autoMarkSetsItemCollectionBook"] = false,
                    ["autoMarkAllWeapon"] = false,
                    ["allowGuildBankFilter"] = true,
                    ["showOrnateItemsInChat"] = false,
                    ["lastLockDynFilterIconId"] = 
                    {
                        [39] = -1,
                        [1] = -1,
                        [2] = -1,
                        [3] = -1,
                        [4] = -1,
                        [5] = -1,
                        [6] = -1,
                        [7] = -1,
                        [8] = -1,
                        [9] = -1,
                        [37] = -1,
                        [11] = -1,
                        [12] = -1,
                        [13] = -1,
                        [14] = -1,
                        [36] = -1,
                        [16] = -1,
                        [17] = -1,
                        [18] = -1,
                        [19] = -1,
                        [20] = -1,
                        [21] = -1,
                        [35] = -1,
                        [34] = -1,
                        [24] = -1,
                        [25] = -1,
                        [26] = -1,
                        [33] = -1,
                        [28] = -1,
                        [29] = -1,
                        [30] = -1,
                        [31] = -1,
                    },
                    ["autoMarkSetsNonWishedLevel"] = 1,
                    ["debugDepth"] = 1,
                    ["autoMarkAllEquipment"] = true,
                    ["autoMarkAllJewelry"] = false,
                    ["armorTypeIconAtCharacterX"] = 15,
                    ["blockMarkedMotifsDisableWithFlag"] = false,
                    ["autoMarkSetsCheckArmorTrait"] = 
                    {
                        [16] = true,
                        [17] = true,
                        [18] = true,
                        [19] = true,
                        [20] = true,
                        [25] = true,
                        [11] = true,
                        [12] = true,
                        [13] = true,
                        [14] = true,
                        [15] = true,
                    },
                    ["blockMarkedPotions"] = false,
                    ["autoMarkSetsNonWishedIfCharBelowLevel"] = false,
                    ["allowDeconstructIntricate"] = true,
                    ["allowTradeFilter"] = true,
                    ["version"] = 0.1000000000,
                    ["autoMarkIntricate"] = false,
                    ["autoMarkCraftedItems"] = false,
                    ["useDifferentUndoFilterPanels"] = true,
                    ["blockJewelryDeconstruction"] = true,
                    ["showQualityItemsInChat"] = false,
                    ["autoMarkSetsItemCollectionBookNonMissingIcon"] = -100,
                    ["autoReenable_blockFenceSelling"] = true,
                    ["autoMarkPreventIfMarkedForSell"] = false,
                    ["autoMarkCraftedWritCreatorItemsIconNr"] = 1,
                    ["autoMarkSetsItemCollectionBookAddonUsed"] = 1,
                    ["autoMarkSetsWithTraitIfAutoSetMarked"] = true,
                    ["allowImprovementFilter"] = true,
                    ["autoMarkCraftedWritItems"] = false,
                    ["autoReenable_blockJewelryDeconstruction"] = true,
                    ["removeMarkAsJunk"] = false,
                    ["markerIconOffset"] = 
                    {
                        ["GridList"] = 
                        {
                            ["y"] = -12,
                            ["scale"] = 90,
                            ["x"] = 12,
                        },
                    },
                    ["autoDeMarkSellGuildStoreOnOthersExclusionDynamic"] = false,
                    ["contextMenuItemEntryShowTooltipWithSHIFTKeyOnly"] = false,
                    ["splitGearSetsFilter"] = true,
                    ["blockVendorRepair"] = false,
                    ["allowDeconstructionFilter"] = false,
                    ["cycleMarkerSymbolOnKeybind"] = false,
                    ["isFilterPanelOn"] = 
                    {
                        [1] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [2] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [3] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [4] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [5] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [7] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [39] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [37] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [11] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [12] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [13] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [14] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [36] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [16] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [17] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [18] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [19] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [20] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [21] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [35] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [34] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [24] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [25] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [26] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [33] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [28] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [29] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [30] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                        [31] = 
                        {
                            [4] = false,
                            [1] = false,
                            [2] = false,
                            [3] = false,
                        },
                    },
                    ["autoMarkResearch"] = false,
                    ["keybindMoveMarkedForSellToJunkEnabled"] = false,
                    ["autoReenable_blockDeconstruction"] = true,
                    ["blockAutoLootContainer"] = true,
                    ["itemCoolDownTrackerTrackedItemsMarkerIcon"] = 1,
                    ["allowMailFilter"] = true,
                    ["contextMenuDividerClearsMarkers"] = true,
                    ["autoMarkItemCoolDownTrackerTrackedItems"] = false,
                    ["allowInventoryFilter"] = true,
                    ["autoMarkSetsCheckAllGearIcons"] = true,
                    ["enableKeybindChording"] = true,
                    ["alwaysUseClientLanguage"] = true,
                    ["autoBindMissingSetCollectionPiecesOnLootToChat"] = false,
                    ["FCOISAdditionalInventoriesButtonOffset"] = 
                    {
                        [1] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [2] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [3] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [4] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [5] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [6] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [7] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [8] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [9] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [10] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [11] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [12] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [13] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [14] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [15] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [16] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [17] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [18] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [19] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [20] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [21] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [22] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [23] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [24] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [25] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [26] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [27] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [28] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [29] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [30] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [31] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [32] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [33] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [34] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        [35] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [36] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [37] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [38] = 
                        {
                            ["top"] = 0,
                            ["left"] = 0,
                        },
                        [39] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        ["companion_character"] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                        ["character"] = 
                        {
                            ["top"] = 0,
                            ["left"] = 9999,
                        },
                    },
                    ["askBeforeEquipBoundItems"] = true,
                    ["autoMarkBagsToScan"] = 
                    {
                        [7] = true,
                        [1] = true,
                        [2] = true,
                        [3] = true,
                    },
                    ["contextMenuCustomMarkedNormalColor"] = 
                    {
                        ["b"] = 0,
                        ["g"] = 0,
                        ["r"] = 1,
                        ["a"] = 1,
                    },
                    ["doBackupAfterJumpToHouse"] = false,
                    ["allowResearch"] = true,
                    ["autoDeMarkSellGuildStoreOnOthers"] = false,
                    ["contextMenuLeadingIconSize"] = 22,
                    ["allowDeconstructDeconstructionWithMarkers"] = false,
                },
            },
        },
    },
}
