VotansImprovedLocations_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["version"] = 1,
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["recent"] = 
                {
                    [1] = 10,
                    [2] = 11,
                    [3] = 17,
                    [4] = 8,
                    [5] = 7,
                },
            },
            ["$AccountWide"] = 
            {
                ["favorites"] = 
                {
                },
                ["showRecentList"] = true,
                ["assignToAlliance"] = false,
                ["showToggleFavorite"] = true,
                ["sortBy"] = "Name",
                ["showLevels"] = false,
                ["allAllianceOnTop"] = false,
                ["version"] = 1,
            },
        },
    },
}
