GridList_SV =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                [1] = 1,
                [2] = 1,
                [3] = 1,
                [4] = 1,
                [5] = 1,
                [6] = 1,
                [7] = 1,
                ["stack_font_style_a"] = 0.5000000000,
                [9] = 1,
                [10] = 1,
                [11] = 1,
                ["skin_edge_file_width"] = 128,
                ["stack_font_y"] = -1,
                ["status_icon_x"] = 1,
                ["slot_size"] = 64,
                ["trait_icon_y"] = 0,
                ["icon_anim"] = true,
                ["stack_font_x"] = -4,
                ["status_icon_y"] = 1,
                ["skin_edge_file_height"] = 16,
                ["stack_font_size"] = 15,
                ["trait_icon_a"] = 0.9000000000,
                ["icon_size"] = 38,
                ["slot_backdrop_col"] = 
                {
                    [4] = 1,
                    [1] = 0.0784313725,
                    [2] = 0.0784313725,
                    [3] = 0.0784313725,
                },
                ["anim_scale"] = 1.4000000000,
                ["status_icon_size"] = 22,
                ["version"] = 3,
                ["stack_font_a"] = 1,
                ["status_icon_a"] = 0.8000000000,
                ["edge_quality_trash_col"] = 
                {
                    [4] = 0.6000000000,
                    [1] = 0.1176470588,
                    [2] = 0.1176470588,
                    [3] = 0.1176470588,
                },
                [8] = 1,
                ["edge_quality_normal_col"] = 
                {
                    [4] = 0.6000000000,
                    [1] = 0.3137254902,
                    [2] = 0.3137254902,
                    [3] = 0.3137254902,
                },
                ["trait_icon_size"] = 24,
                ["skin_edge_thickness"] = 20,
                ["edge_quality_a"] = 0.6000000000,
                ["stack_font"] = "$(BOLD_FONT)",
                ["slot_highlight_col"] = 
                {
                    [4] = 1,
                    [1] = 0.3764705882,
                    [2] = 0.4901960784,
                    [3] = 0.5450980392,
                },
                ["status_icon_tooltip"] = false,
                ["skin_edge"] = "GridList/textures/edge.dds",
                ["trait_icon_x"] = 0,
                ["edge_quality_b"] = 1,
                ["skin_backdrop"] = "GridList/textures/backdrop.dds",
                ["trait_icon_tooltip"] = false,
                ["stack_font_shadow"] = "outline",
                ["skin_backdrop_insets"] = 0,
                ["slot_spacing"] = 5,
                ["anim_duration"] = 125,
                ["tooltip_near_slot"] = false,
            },
        },
    },
}
