CharacterKnowledgeSavedVariables =
{
    ["Default"] = 
    {
        ["$InstallationWide"] = 
        {
            ["$AccountWide"] = 
            {
                ["featureRev"] = 1,
                ["version"] = 1,
                ["filterId"] = 1,
                ["tooltips"] = 
                {
                    ["itemColors"] = 
                    {
                        [2] = 16711680,
                        [1] = 65280,
                    },
                    ["enabled"] = true,
                    ["charColors"] = 
                    {
                        [0] = 3355443,
                        [1] = 3381759,
                        [2] = 7829350,
                    },
                },
            },
        },
        ["EU"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 1,
                ["tooltips"] = 
                {
                    ["pinnedCharsForChapters"] = 1,
                },
            },
        },
    },
}
