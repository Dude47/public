NO_THANK_YOU_VARS =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["ava"] = 1,
                ["motd"] = 0,
                ["guildAlertsGuilds"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                },
                ["chatForTradingHouse"] = false,
                ["friends"] = false,
                ["raidToChat"] = true,
                ["dontShowSkillProgression"] = 0,
                ["guildLeave"] = 
                {
                },
                ["fenceDialog"] = false,
                ["ultimateSound"] = 0,
                ["disableChatAutoComplete"] = false,
                ["hideTamriel"] = false,
                ["dontReadBooks"] = false,
                ["nonstopHarvest"] = false,
                ["version"] = 1,
                ["luaError"] = 1,
                ["motdGuilds"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                },
                ["ownedHouses"] = 0,
                ["raid"] = 0,
                ["craftBag"] = false,
                ["guildAlerts"] = 0,
                ["screenshot"] = false,
                ["boss"] = false,
                ["hideTamrielDungeons"] = 0,
                ["unownedHouses"] = 0,
                ["groupZone"] = 1,
                ["noGuildLeave"] = 0,
                ["noBindAlert"] = false,
                ["guildInvites"] = 0,
                ["autoLootItems"] = false,
                ["enlightened"] = false,
                ["guildApps"] = false,
                ["emptyInteractions"] = false,
                ["raidGuilds"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                },
                ["noCameraSpin"] = false,
                ["dontAcceptWritQuest"] = false,
                ["improveDialog"] = false,
                ["crownCrate"] = false,
                ["disbandDialog"] = false,
                ["emptyMail"] = true,
                ["alertTextExpiryDelay"] = 3,
                ["dontShowLoreDiscoveries"] = 0,
                ["craftingResults"] = false,
                ["noReportOnItems"] = false,
                ["noPortOnLeader"] = 0,
                ["hideTamrielWayhsrines"] = 0,
                ["largeGroupDialog"] = false,
                ["noCameraSpinInv"] = false,
                ["noUniversalStones"] = false,
                ["noCameraSpinStats"] = false,
                ["marketAnnouncement"] = false,
                ["repair"] = false,
            },
        },
    },
}
