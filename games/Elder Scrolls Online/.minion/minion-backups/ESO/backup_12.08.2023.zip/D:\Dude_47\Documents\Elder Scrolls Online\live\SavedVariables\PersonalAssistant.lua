PersonalAssistant_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 1,
                ["Debug"] = 
                {
                },
                ["savedVarsVersion"] = 20501,
            },
            ["Galrnskar Haraendottir"] = 
            {
                ["Repair"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["Junk"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["Loot"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["Integration"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["Consume"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["debug"] = false,
                ["version"] = 1,
                ["Banking"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["Worker"] = 
                {
                    ["activeProfile"] = 1,
                },
                ["General"] = 
                {
                    ["jumpOutside"] = false,
                    ["welcomeMessage"] = false,
                },
            },
        },
    },
}
