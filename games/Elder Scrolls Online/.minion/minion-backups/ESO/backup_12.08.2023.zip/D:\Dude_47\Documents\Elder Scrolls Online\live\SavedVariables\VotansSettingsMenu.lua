VotansSettingsMenu_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["LastAddon"] = "PersonalAssistantJunkAddonOptions",
                ["version"] = 1,
            },
            ["$AccountWide"] = 
            {
                ["ShowButton"] = true,
                ["version"] = 1,
            },
        },
    },
}
