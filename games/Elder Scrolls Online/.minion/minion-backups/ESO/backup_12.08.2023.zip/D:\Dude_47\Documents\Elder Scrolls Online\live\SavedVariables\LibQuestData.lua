LibQuestData_SavedVariables =
{
    ["giver_names"] = 
    {
    },
    ["reward_info"] = 
    {
    },
    ["libVersion"] = 260,
    ["location_info"] = 
    {
        ["main/valleyofblades1_base_0"] = 
        {
            [1] = 
            {
                [1] = 0.5592588782,
                [2] = 0.4436497688,
                [3] = -0.1198427978,
                [4] = 0.1167707989,
                [5] = 6398,
                [6] = 100033,
            },
        },
        ["stonefalls/davonswatch_base_0"] = 
        {
            [1] = 
            {
                [1] = 0.7522382736,
                [2] = 0.7520843744,
                [3] = 0.7905716000,
                [4] = 0.4366612088,
                [5] = 4296,
                [6] = 100161,
            },
        },
        ["cyrodiil/northmorrowgate_base_0"] = 
        {
            [1] = 
            {
                [1] = 0.4841942787,
                [2] = 0.4727851450,
                [3] = 0.6107779951,
                [4] = 0.4197816108,
                [5] = 6130,
                [6] = 100051,
            },
        },
        ["malabaltor/blackvineruins_base_0"] = 
        {
            [1] = 
            {
                [1] = 0.2804757059,
                [2] = 0.0842418224,
                [3] = 0.3997144128,
                [4] = 0.5968576089,
                [5] = 4503,
                [6] = 38057,
            },
        },
    },
    ["quest_names"] = 
    {
    },
    ["client_lang"] = "en",
    ["version"] = 4,
    ["strored_data"] = 
    {
    },
    ["quests"] = 
    {
        ["cyrodiil/ava_whole_0"] = 
        {
        },
        ["malabaltor/blackvineruins_base_0"] = 
        {
        },
        ["cyrodiil/northmorrowgate_base_0"] = 
        {
        },
        ["reapersmarch/rawlkha_base_0"] = 
        {
            [1] = 
            {
                ["gpsy"] = 0.6186491948,
                ["name"] = "Divine Conundrum",
                ["quest_display_type"] = 10,
                ["poi_index"] = 75,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.5960475802,
                ["gpsx"] = 0.4538324064,
                ["giver"] = "Nirai",
                ["zone_name"] = "Vvardenfell",
                ["repeat_type"] = 0,
                ["y"] = 0.6037753820,
                ["zone_index"] = 467,
                ["quest_type"] = 0,
            },
        },
        ["main/valleyofblades1_base_0"] = 
        {
        },
        ["stonefalls/davonswatch_base_0"] = 
        {
            [1] = 
            {
                ["gpsy"] = 0.4372488093,
                ["name"] = "The Demon Weapon",
                ["quest_display_type"] = 0,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.7620027065,
                ["gpsx"] = 0.7908508003,
                ["giver"] = "Anais Davaux",
                ["zone_name"] = "Grahtwood",
                ["repeat_type"] = 0,
                ["y"] = 0.7726344466,
                ["zone_index"] = 180,
                ["quest_type"] = 14,
            },
            [2] = 
            {
                ["gpsy"] = 0.4373820098,
                ["name"] = "The Coven Conspiracy",
                ["quest_display_type"] = 0,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.7077108026,
                ["gpsx"] = 0.7892983993,
                ["giver"] = "Scout Gunthe",
                ["zone_name"] = "Eastmarch",
                ["repeat_type"] = 0,
                ["y"] = 0.7772928476,
                ["zone_index"] = 15,
                ["quest_type"] = 14,
            },
            [3] = 
            {
                ["gpsy"] = 0.4382612094,
                ["name"] = "For Glory",
                ["quest_display_type"] = 0,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.6248531342,
                ["gpsx"] = 0.7869292003,
                ["giver"] = "For Glory!",
                ["zone_name"] = "",
                ["repeat_type"] = 0,
                ["y"] = 0.8080409765,
                ["zone_index"] = 294967291,
                ["quest_type"] = 13,
            },
            [4] = 
            {
                ["gpsy"] = 0.4372424096,
                ["name"] = "Ruthless Competition",
                ["quest_display_type"] = 0,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.6051843762,
                ["gpsx"] = 0.7863667997,
                ["giver"] = "Concordia Mercius",
                ["zone_name"] = "Shadowfen",
                ["repeat_type"] = 0,
                ["y"] = 0.7724106312,
                ["zone_index"] = 19,
                ["quest_type"] = 14,
            },
            [5] = 
            {
                ["gpsy"] = 0.4250156092,
                ["name"] = "Quiet the Ringing Bell",
                ["quest_display_type"] = 0,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.5802837014,
                ["gpsx"] = 0.7856547998,
                ["giver"] = "Tanval Indoril",
                ["zone_name"] = "Stonefalls",
                ["repeat_type"] = 0,
                ["y"] = 0.3448044360,
                ["zone_index"] = 9,
                ["quest_type"] = 0,
            },
            [6] = 
            {
                ["gpsy"] = 0.4372588085,
                ["name"] = "The Harborage",
                ["quest_display_type"] = 1,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["api"] = 101038,
                ["lang"] = "en",
                ["gpsx"] = 0.7862292004,
                ["x"] = 0.6003721356,
                ["quest_type"] = 2,
                ["repeat_type"] = 0,
                ["zone_name"] = "The Harborage",
                ["zone_index"] = 45,
                ["y"] = 0.7729841471,
            },
        },
        ["stonefalls/dhalmora_base_0"] = 
        {
            [1] = 
            {
                ["gpsy"] = 0.4467616087,
                ["name"] = "The Missing Prophecy",
                ["quest_display_type"] = 0,
                ["poi_index"] = 294967291,
                ["questID"] = -1,
                ["lang"] = "en",
                ["api"] = 101038,
                ["x"] = 0.4535165727,
                ["gpsx"] = 0.8119743782,
                ["giver"] = "Alessio Guillon",
                ["zone_name"] = "Stormhaven",
                ["repeat_type"] = 0,
                ["y"] = 0.5184137225,
                ["zone_index"] = 4,
                ["quest_type"] = 14,
            },
        },
        ["stonefalls/balfoyen_base_0"] = 
        {
        },
    },
    ["quest_info"] = 
    {
        [3585] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 14023,
            [5] = 10005,
            [6] = 1,
            [7] = 10,
        },
        [4722] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 14722,
            [5] = 10001,
            [6] = 5,
            [7] = 10,
        },
        [4723] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 14722,
            [5] = 10002,
            [6] = 5,
            [7] = 10,
        },
        [4724] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 10000,
            [5] = 10000,
            [6] = 5,
            [7] = 10,
        },
        [4022] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 10001,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [4503] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 10001,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [4296] = 
        {
            [1] = 2,
            [2] = 0,
            [3] = 101038,
            [4] = 10001,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [4024] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 10001,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [4067] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 10001,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [6395] = 
        {
            [1] = 14,
            [2] = 0,
            [3] = 101038,
            [4] = 10000,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [3587] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 14023,
            [5] = 10006,
            [6] = 1,
            [7] = 10,
        },
        [3588] = 
        {
            [1] = 0,
            [2] = 0,
            [3] = 101038,
            [4] = 14023,
            [5] = 10007,
            [6] = 1,
            [7] = 10,
        },
        [6398] = 
        {
            [1] = 14,
            [2] = 0,
            [3] = 101038,
            [4] = 10000,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
        [6799] = 
        {
            [1] = 17,
            [2] = 0,
            [3] = 101038,
            [4] = 10000,
            [5] = 10000,
            [6] = 0,
            [7] = 0,
        },
    },
    ["effective_lang"] = "en",
}
