Untaunted_Save =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["showmarker"] = false,
                ["trackonlyplayer"] = true,
                ["bardirection"] = false,
                ["maxbars"] = 15,
                ["growthdirection"] = false,
                ["customabilities"] = 
                {
                },
                ["markersize"] = 26,
                ["lastversion"] = "1.1.4",
                ["version"] = 7,
                ["accountwide"] = true,
                ["trackedabilities"] = 
                {
                    [1] = 
                    {
                        [2] = true,
                        [1] = 38541,
                    },
                    [2] = 
                    {
                        [2] = true,
                        [1] = 52788,
                    },
                    [3] = 
                    {
                        [2] = false,
                        [1] = 17906,
                    },
                    [4] = 
                    {
                        [2] = false,
                        [1] = 68588,
                    },
                    [5] = 
                    {
                        [2] = false,
                        [1] = 62787,
                    },
                    [6] = 
                    {
                        [2] = false,
                        [1] = 80020,
                    },
                    [7] = 
                    {
                        [2] = false,
                        [1] = 39100,
                    },
                    [8] = 
                    {
                        [2] = false,
                        [1] = 81519,
                    },
                    [9] = 
                    {
                        [2] = false,
                        [1] = 122389,
                    },
                    [10] = 
                    {
                        [2] = false,
                        [1] = 62988,
                    },
                    [11] = 
                    {
                        [2] = false,
                        [1] = 134599,
                    },
                    [12] = 
                    {
                        [2] = false,
                        [1] = 17945,
                    },
                    [13] = 
                    {
                        [2] = false,
                        [1] = 40224,
                    },
                    [14] = 
                    {
                        [2] = false,
                        [1] = 21763,
                    },
                    [15] = 
                    {
                        [2] = false,
                        [1] = 44373,
                    },
                    [16] = 
                    {
                        [2] = false,
                        [1] = 127070,
                    },
                    [17] = 
                    {
                        [2] = false,
                        [1] = 126597,
                    },
                },
                ["window"] = 
                {
                    ["y"] = 150,
                    ["height"] = 25,
                    ["x"] = 150,
                    ["width"] = 300,
                },
            },
        },
    },
}
