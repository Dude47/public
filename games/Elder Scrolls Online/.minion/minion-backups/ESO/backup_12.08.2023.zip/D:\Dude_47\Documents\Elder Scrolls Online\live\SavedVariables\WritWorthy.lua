WritWorthyVars =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["Galrnskar Haraendottir"] = 
            {
                ["version"] = 1,
                ["lang"] = false,
                ["enable_lib_price"] = true,
                ["enable_mat_price_tooltip"] = true,
                ["enable_banked_vouchers"] = false,
                ["writ_unique_id"] = 
                {
                },
                ["enable_mat_list_tooltip"] = "Off",
                ["enable_mat_list_chat"] = "Off",
                ["enable_mm_fallback"] = false,
                ["enable_station_colors"] = false,
            },
            ["$AccountWide"] = 
            {
                ["version"] = 1,
                ["position"] = 
                {
                    [2] = 50,
                    [1] = 50,
                },
            },
        },
    },
}
