HarvestAD_SavedVars =
{
    ["dataVersion"] = 17,
}
