ZO_Ingame_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["ZO_GuildBrowser_ApplicationMessage"] = 
                {
                    ["applicationText"] = "",
                    ["version"] = 1,
                    ["reportedGuilds"] = 
                    {
                    },
                },
                ["NameChange"] = 
                {
                    ["8798292093726442"] = "Galrnskar Haraendottir",
                    ["version"] = 1,
                },
                ["ZO_GuildRecruitment_ResponseMessage"] = 
                {
                    ["guildResponseTexts"] = 
                    {
                    },
                    ["version"] = 1,
                },
                ["ZO_HousingEditor_Options"] = 
                {
                    ["rotateUnitsRadians"] = 0.0008726646,
                    ["moveUnitsCentimeters"] = 1,
                    ["version"] = 1,
                },
                ["GuildMotD"] = 
                {
                    ["version"] = 1,
                },
                ["RandomRollCommand"] = 
                {
                    ["version"] = 1,
                },
            },
            ["Galrnskar Haraendottir"] = 
            {
                ["PerformanceMeters"] = 
                {
                    ["point"] = 6,
                    ["version"] = 1,
                    ["y"] = 20,
                    ["relPoint"] = 6,
                    ["x"] = -20,
                },
                ["EnchantingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["GamepadProvisioner"] = 
                {
                    ["haveSkillsChecked"] = false,
                    ["questsOnlyChecked"] = false,
                    ["haveIngredientsChecked"] = false,
                    ["version"] = 3,
                },
                ["GamepadSmithingExtraction"] = 
                {
                    ["version"] = 1,
                    ["includeBankedItemsChecked"] = true,
                    ["craftingTypes"] = 
                    {
                    },
                },
                ["TradingHouseSearchHistory"] = 
                {
                    ["nextSearchOrderId"] = 0,
                    ["searchEntries"] = 
                    {
                    },
                    ["version"] = 2,
                },
                ["GamepadAlchemyCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
                ["OutfitSlots"] = 
                {
                    ["showLockedStyles"] = true,
                    ["version"] = 1,
                },
                ["AutoComplete"] = 
                {
                    ["RecentInteractions"] = 
                    {
                        ["Fuhi"] = 1691865913,
                        ["Galrnskar Haraendottir"] = 1691865913,
                    },
                    ["version"] = 3,
                },
                ["DeathRecap"] = 
                {
                    ["version"] = 1,
                    ["recapOn"] = true,
                },
                ["AlchemyCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["version"] = 1,
                },
                ["WorldMap"] = 
                {
                    [1] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["point"] = 128,
                        ["mapSize"] = 2,
                        ["relPoint"] = 128,
                        ["width"] = 488,
                        ["y"] = 0,
                        ["height"] = 550,
                        ["x"] = 0,
                        ["keepSquare"] = true,
                    },
                    [2] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [3] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [15] = false,
                                [11] = 1,
                                [4] = false,
                                [5] = false,
                                [3] = false,
                                [7] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [4] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [11] = 1,
                                [2] = false,
                                [3] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [5] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [3] = false,
                                [5] = false,
                                [11] = 1,
                                [15] = false,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [6] = 
                    {
                        ["filters"] = 
                        {
                            [2] = 
                            {
                                [8] = false,
                                [1] = false,
                                [10] = false,
                                [3] = false,
                                [4] = false,
                                [5] = false,
                                [15] = false,
                                [7] = false,
                            },
                        },
                        ["allowHistory"] = false,
                        ["disabledStickyPins"] = 
                        {
                            [2] = 
                            {
                                [5] = true,
                            },
                        },
                        ["mapSize"] = 1,
                    },
                    [7] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [1] = false,
                                [14] = false,
                                [15] = false,
                            },
                            [2] = 
                            {
                                [1] = false,
                                [2] = false,
                                [3] = false,
                                [11] = 1,
                                [14] = false,
                                [15] = false,
                            },
                            [3] = 
                            {
                            },
                        },
                        ["allowHistory"] = false,
                        ["mapSize"] = 1,
                    },
                    [41] = 
                    {
                        ["filters"] = 
                        {
                            [4] = 
                            {
                            },
                            [1] = 
                            {
                                [15] = false,
                            },
                            [2] = 
                            {
                                [15] = false,
                                [1] = false,
                                [6] = false,
                                [11] = 1,
                            },
                            [3] = 
                            {
                                [15] = false,
                            },
                        },
                        ["point"] = 128,
                        ["mapSize"] = 2,
                        ["relPoint"] = 128,
                        ["width"] = 255,
                        ["mapZoom"] = 5.1400000000,
                        ["y"] = -566,
                        ["keepSquare"] = true,
                        ["x"] = 1156.5000000000,
                        ["height"] = 317,
                    },
                    ["version"] = 4,
                    ["userMode"] = 2,
                },
                ["SmithingResearch"] = 
                {
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["SmithingExtraction"] = 
                {
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 1,
                },
                ["SmithingCreation"] = 
                {
                    ["questsOnlyChecked"] = false,
                    ["useUniversalStyleItemChecked"] = false,
                    ["version"] = 3,
                    ["haveKnowledgeChecked"] = true,
                    ["haveMaterialChecked"] = false,
                },
                ["Chat"] = 
                {
                    ["version"] = 4,
                    ["containers"] = 
                    {
                        [1] = 
                        {
                            ["point"] = 6,
                            ["x"] = 0,
                            ["y"] = -82,
                            ["height"] = 267,
                            ["relPoint"] = 6,
                            ["width"] = 445,
                        },
                    },
                },
                ["Provisioner"] = 
                {
                    ["haveSkillsChecked"] = true,
                    ["questsOnlyChecked"] = false,
                    ["haveIngredientsChecked"] = true,
                    ["version"] = 2,
                },
                ["UniversalDeconstruction"] = 
                {
                    ["craftingTypeFilters"] = 
                    {
                    },
                    ["includeBankedItemsChecked"] = true,
                    ["version"] = 2,
                },
                ["ZO_ItemSetCollectionsDataManager"] = 
                {
                    ["equipmentFiltersTypes"] = 
                    {
                    },
                    ["equipmentFilterTypes"] = 
                    {
                    },
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["Dyeing"] = 
                {
                    ["sortStyle"] = 1,
                    ["showLocked"] = true,
                    ["version"] = 1,
                },
                ["GamepadEnchantingCreation"] = 
                {
                    ["shouldFilterQuests"] = false,
                    ["version"] = 1,
                },
            },
        },
    },
}
