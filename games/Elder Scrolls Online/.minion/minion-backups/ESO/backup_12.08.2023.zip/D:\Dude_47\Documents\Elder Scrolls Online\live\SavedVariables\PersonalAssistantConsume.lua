PersonalAssistantConsume_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["foodBufferSeconds"] = 300,
                ["foodLink"] = "",
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["version"] = 2,
                ["isAutoConsumeEXP"] = false,
                ["isAutoEatFood"] = false,
                ["EXPLink"] = "",
                ["EXPBufferSeconds"] = -1,
            },
            ["$AccountWide"] = 
            {
                ["version"] = 2,
                [1] = 
                {
                    ["name"] = "Profile 1",
                    ["autoConsumePoisonEnabled"] = false,
                    ["silentMode"] = false,
                },
                ["savedVarsVersion"] = 20230728,
                ["profileCounter"] = 1,
            },
        },
    },
}
