VotansImprovedQuests_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["alwaysShowOnMap"] = false,
                ["alwaysShowQuests"] = false,
                ["consolidateOtherZones"] = false,
                ["showLevels"] = false,
                ["version"] = 1,
            },
        },
    },
}
