LibLoreLibrary_Settings =
{
    ["lang"] = "en",
    ["version"] = 1,
}
LibLoreLibrary_Data =
{
    ["locales"] = 
    {
    },
    ["langIdx"] = 0,
    ["data"] = 
    {
    },
    ["isCollecting"] = false,
}
