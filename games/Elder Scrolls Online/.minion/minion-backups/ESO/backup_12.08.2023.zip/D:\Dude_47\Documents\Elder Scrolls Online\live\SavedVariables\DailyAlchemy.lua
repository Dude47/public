DailyAlchemyVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["version"] = 1,
            },
            ["$AccountWide"] = 
            {
                ["showPriceTTC"] = false,
                ["showPriceMM"] = false,
                ["isLog"] = true,
                ["acquireDelay"] = 1,
                ["priorityByManual"] = 
                {
                    [1] = 30148,
                    [2] = 30149,
                    [3] = 30151,
                    [4] = 30152,
                    [5] = 30153,
                    [6] = 30154,
                    [7] = 30155,
                    [8] = 30156,
                    [9] = 30157,
                    [10] = 30158,
                    [11] = 30159,
                    [12] = 30160,
                    [13] = 30161,
                    [14] = 30162,
                    [15] = 30163,
                    [16] = 30164,
                    [17] = 30165,
                    [18] = 30166,
                    [19] = 77581,
                    [20] = 77583,
                    [21] = 77584,
                    [22] = 77585,
                    [23] = 77587,
                    [24] = 77589,
                    [25] = 77590,
                    [26] = 77591,
                    [27] = 139019,
                    [28] = 139020,
                    [29] = 150731,
                    [30] = 150789,
                    [31] = 150671,
                    [32] = 150669,
                    [33] = 150670,
                    [34] = 150672,
                },
                ["debugLog"] = 
                {
                },
                ["version"] = 1,
                ["reservations"] = 
                {
                },
                ["isDebugQuest"] = true,
                ["priorityBy"] = 1,
                ["isAcquireItem"] = true,
            },
        },
    },
}
