VotansKeybinder_Data =
{
    ["Default"] = 
    {
        ["$Machine"] = 
        {
            ["$UserProfileWide"] = 
            {
                ["version"] = 1,
                ["Keybindings"] = 
                {
                    ["MOVE_BACKWARD"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 50,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 113,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 140,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["START_CHAT_SLASH"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 108,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_WEAPON_SWAP"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 109,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 118,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 125,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_WEAPON_SWAP_TO_SET_2"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_INVENTORY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 40,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 33,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_ATTACK"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 114,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 138,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["USE_SYNERGY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 55,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 162,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_MAIL"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 105,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_6"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 26,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_FIRST_PERSON"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 53,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["PA_JUNK_TOGGLE_ITEM"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 19,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_MAP"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 44,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 128,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_TERTIARY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 37,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 136,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_SYSTEM"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 12,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_9"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 48,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 123,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["COMMAND_PET"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 56,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 149,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_SKILLS"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 42,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_HELP"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 75,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["MOVE_JUMPASCEND"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 13,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["PA_JUNK_PERMANENT_TOGGLE_ITEM"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 16,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_CHARACTER"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 34,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_GUILDS"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 38,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_NAMEPLATES"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["CHAT_REPLY_TO_LAST_WHISPER"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["PLAYER_TO_PLAYER_INTERACT_ACCEPT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 37,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 133,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["PLAYER_TO_PLAYER_INTERACT_DECLINE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 55,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 134,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TURN_LEFT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 32,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 110,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 141,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["CAMERA_ZOOM_IN"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 121,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SIEGE_PACK_UP"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 55,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 136,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_5"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 25,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_MOUNT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 39,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 181,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SIEGE_RELEASE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 5,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 134,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["GAME_CAMERA_MOUSE_FREE_LOOK"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 116,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_GROUP"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 47,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SHEATHE_WEAPON_TOGGLE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 57,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 178,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_WEAPON_SWAP_TO_SET_1"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["AUTORUN"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 117,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 68,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_3"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 23,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_CONTACTS"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 46,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TAKE_SCREENSHOT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 20,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_8"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 49,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["START_CHAT_ENTER"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 3,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 165,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_WALK"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_NEGATIVE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 55,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 134,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_BLOCK"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 115,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 137,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_HUD_UI"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 107,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["GAME_CAMERA_INTERACT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 36,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["MOVE_FORWARD"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 54,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 112,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 139,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_4"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 24,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_MARKET"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 106,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_SHOW_INGAME_GUI"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_CROUCH"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 4,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 130,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_ALLIANCE_WAR"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 43,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_REPORT_PLAYER"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 75,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_INTERRUPT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 119,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 148,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TURN_RIGHT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 35,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 111,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 142,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_SHOW_QUEST_ON_MAP"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 44,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["DIALOG_SECONDARY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 49,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 135,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_NOTIFICATIONS"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 45,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SIEGE_FIRE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 114,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 31,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 138,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ROLL_DODGE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 161,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_FULLSCREEN"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 5,
                            ["keyCode"] = 3,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_JOURNAL"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 41,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["CAMERA_ZOOM_OUT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 120,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_ACTIVITY_FINDER"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 73,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["CYCLE_PREFERRED_ENEMY_TARGET"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 2,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_CHAMPION"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 100,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["DIALOG_CLOSE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 12,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 127,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 128,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_QUICK_SLOTS"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 48,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 176,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_GAMEPAD_MODE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_PRIMARY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 36,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 133,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ACTION_BUTTON_7"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 27,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["DIALOG_NEGATIVE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 5,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 134,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["PLAYER_TO_PLAYER_INTERACT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 37,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 180,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_HEALTHBARS"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["ASSIST_NEXT_TRACKED_QUEST"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 51,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 126,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_COLLECTIONS_BOOK"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 52,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["TOGGLE_GAME_CAMERA_UI_MODE"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 5,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 127,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["UI_SHORTCUT_SECONDARY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 49,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 135,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["SPECIAL_MOVE_SPRINT"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 7,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                    ["DIALOG_PRIMARY"] = 
                    {
                        [4] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [1] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 36,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [2] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 133,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                        [3] = 
                        {
                            ["mod2"] = 0,
                            ["keyCode"] = 0,
                            ["mod4"] = 0,
                            ["mod1"] = 0,
                            ["mod3"] = 0,
                        },
                    },
                },
            },
        },
    },
}
