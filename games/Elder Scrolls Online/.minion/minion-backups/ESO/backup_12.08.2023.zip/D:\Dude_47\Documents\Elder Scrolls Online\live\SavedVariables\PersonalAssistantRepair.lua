PersonalAssistantRepair_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 1,
                [1] = 
                {
                    ["name"] = "Profile 1",
                    ["RechargeWeapons"] = 
                    {
                        ["defaultSoulGem"] = 1,
                        ["lowSoulGemWarning"] = true,
                        ["lowSoulGemThreshold"] = 10,
                        ["useSoulGems"] = false,
                    },
                    ["RepairEquipped"] = 
                    {
                        ["repairWithGoldDurabilityThreshold"] = 75,
                        ["defaultRepairKit"] = 0,
                        ["lowRepairKitWarning"] = true,
                        ["repairWithRepairKit"] = false,
                        ["repairWithGold"] = true,
                        ["repairWithRepairKitThreshold"] = 10,
                        ["lowRepairKitThreshold"] = 10,
                    },
                    ["RepairInventory"] = 
                    {
                        ["repairWithGoldDurabilityThreshold"] = 75,
                        ["repairWithGold"] = true,
                    },
                    ["silentMode"] = false,
                    ["autoRepairInventoryEnabled"] = false,
                    ["autoRepairEnabled"] = true,
                },
                ["savedVarsVersion"] = 20230728,
                ["profileCounter"] = 1,
            },
        },
    },
}
