CombatMetrics_Save =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["Settings"] = 
                {
                    ["autoscreenshot"] = false,
                    ["chunksize"] = 1000,
                    ["tremorscaleValue"] = 2640,
                    ["maxSVsize"] = 10,
                    ["NotificationAllowed"] = true,
                    ["alkoshValue"] = 6000,
                    ["offincyrodil"] = false,
                    ["keepbossfights"] = false,
                    ["CombatMetrics_LiveReport"] = 
                    {
                        ["y"] = 1409.1999511719,
                        ["x"] = 117,
                    },
                    ["version"] = 5,
                    ["liveReport"] = 
                    {
                        ["damageOut"] = true,
                        ["alignmentleft"] = true,
                        ["time"] = false,
                        ["bgalpha"] = 60,
                        ["healOutAbsolute"] = false,
                        ["damageIn"] = false,
                        ["enabled"] = true,
                        ["locked"] = false,
                        ["healOut"] = false,
                        ["healIn"] = false,
                        ["scale"] = 1.4000000000,
                        ["layout"] = "Compact",
                        ["damageOutSingle"] = false,
                    },
                    ["accountwide"] = false,
                    ["autoselectchatchannel"] = true,
                    ["crusherValue"] = 2108,
                    ["showstacks"] = true,
                    ["showDebugIds"] = false,
                    ["chatLog"] = 
                    {
                        ["damageOut"] = true,
                        ["name"] = "CMX Combat Log",
                        ["healingOut"] = false,
                        ["damageIn"] = false,
                        ["enabled"] = false,
                        ["healingIn"] = false,
                    },
                    ["lightmodeincyrodil"] = true,
                    ["fighthistory"] = 25,
                    ["unitresistance"] = 18200,
                    ["CombatMetrics_Report"] = 
                    {
                        ["y"] = 645,
                        ["x"] = 1280,
                    },
                    ["recordgrpinlarge"] = true,
                    ["ForceNotification"] = false,
                    ["recordgrp"] = true,
                    ["autoscreenshotmintime"] = 30,
                    ["NotificationRead"] = 0,
                    ["SVsize"] = 0.0000381470,
                    ["currentNotificationVersion"] = 0,
                    ["FightReport"] = 
                    {
                        ["useDisplayNames"] = false,
                        ["fightstatspanel"] = 32,
                        ["CLSelection"] = 
                        {
                            [16] = false,
                            [4] = true,
                            [5] = false,
                            [7] = false,
                            [8] = false,
                            [10] = false,
                            [11] = false,
                            [12] = false,
                            [13] = false,
                            [14] = false,
                            [15] = false,
                        },
                        ["ShowGroupBuffsInPlots"] = true,
                        ["showWereWolf"] = false,
                        ["scale"] = 1,
                        ["averageLayout"] = 
                        {
                            ["damageOut"] = 1,
                            ["damageIn"] = 1,
                            ["healingOut"] = 1,
                            ["healingIn"] = 1,
                        },
                        ["FavouriteBuffs"] = 
                        {
                        },
                        ["rightpanel"] = "buffs",
                        ["showPets"] = true,
                        ["maxValue"] = 
                        {
                            ["damageOut"] = true,
                            ["damageIn"] = true,
                            ["healingOut"] = true,
                            ["healingIn"] = true,
                        },
                        ["PlotColors"] = 
                        {
                            [1] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 1,
                                [3] = 0,
                            },
                            [2] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 0,
                            },
                            [3] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 1,
                                [3] = 0,
                            },
                            [4] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 0,
                                [3] = 1,
                            },
                            [5] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 1,
                            },
                            [6] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 0.4000000000,
                                [2] = 1,
                                [3] = 0.4000000000,
                            },
                            [7] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 1,
                                [2] = 0.4000000000,
                                [3] = 0.9000000000,
                            },
                        },
                        ["category"] = "damageOut",
                        ["SmoothWindow"] = 5,
                        ["mainpanel"] = "FightStats",
                        ["hitCritLayout"] = 
                        {
                            ["damageOut"] = 1,
                            ["damageIn"] = 1,
                            ["healingOut"] = 1,
                            ["healingIn"] = 1,
                        },
                        ["Cursor"] = true,
                    },
                    ["lightmode"] = false,
                },
            },
            ["$AccountWide"] = 
            {
                ["Settings"] = 
                {
                    ["autoscreenshot"] = false,
                    ["chunksize"] = 1000,
                    ["tremorscaleValue"] = 2640,
                    ["maxSVsize"] = 10,
                    ["NotificationAllowed"] = true,
                    ["alkoshValue"] = 6000,
                    ["offincyrodil"] = false,
                    ["keepbossfights"] = false,
                    ["CombatMetrics_LiveReport"] = 
                    {
                        ["y"] = 500,
                        ["x"] = 700,
                    },
                    ["version"] = 5,
                    ["liveReport"] = 
                    {
                        ["damageOut"] = true,
                        ["alignmentleft"] = false,
                        ["time"] = true,
                        ["bgalpha"] = 95,
                        ["healOutAbsolute"] = false,
                        ["damageIn"] = true,
                        ["enabled"] = true,
                        ["locked"] = false,
                        ["healOut"] = true,
                        ["healIn"] = true,
                        ["scale"] = 1,
                        ["layout"] = "Compact",
                        ["damageOutSingle"] = false,
                    },
                    ["accountwide"] = false,
                    ["autoselectchatchannel"] = true,
                    ["crusherValue"] = 2108,
                    ["showstacks"] = true,
                    ["showDebugIds"] = false,
                    ["chatLog"] = 
                    {
                        ["damageOut"] = true,
                        ["name"] = "CMX Combat Log",
                        ["healingOut"] = false,
                        ["damageIn"] = false,
                        ["enabled"] = false,
                        ["healingIn"] = false,
                    },
                    ["lightmodeincyrodil"] = true,
                    ["fighthistory"] = 25,
                    ["unitresistance"] = 18200,
                    ["CombatMetrics_Report"] = 
                    {
                        ["y"] = 645,
                        ["x"] = 1280,
                    },
                    ["recordgrpinlarge"] = true,
                    ["ForceNotification"] = false,
                    ["recordgrp"] = true,
                    ["autoscreenshotmintime"] = 30,
                    ["NotificationRead"] = 0,
                    ["SVsize"] = 0,
                    ["currentNotificationVersion"] = 0,
                    ["FightReport"] = 
                    {
                        ["useDisplayNames"] = false,
                        ["fightstatspanel"] = 32,
                        ["CLSelection"] = 
                        {
                            [16] = false,
                            [4] = true,
                            [5] = false,
                            [7] = false,
                            [8] = false,
                            [10] = false,
                            [11] = false,
                            [12] = false,
                            [13] = false,
                            [14] = false,
                            [15] = false,
                        },
                        ["ShowGroupBuffsInPlots"] = true,
                        ["showWereWolf"] = false,
                        ["scale"] = 1,
                        ["averageLayout"] = 
                        {
                            ["damageOut"] = 1,
                            ["damageIn"] = 1,
                            ["healingOut"] = 1,
                            ["healingIn"] = 1,
                        },
                        ["FavouriteBuffs"] = 
                        {
                        },
                        ["rightpanel"] = "buffs",
                        ["showPets"] = true,
                        ["maxValue"] = 
                        {
                            ["damageOut"] = true,
                            ["damageIn"] = true,
                            ["healingOut"] = true,
                            ["healingIn"] = true,
                        },
                        ["PlotColors"] = 
                        {
                            [1] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 1,
                                [3] = 0,
                            },
                            [2] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 0,
                            },
                            [3] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 1,
                                [3] = 0,
                            },
                            [4] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 0,
                                [2] = 0,
                                [3] = 1,
                            },
                            [5] = 
                            {
                                [4] = 0.6600000000,
                                [1] = 1,
                                [2] = 0,
                                [3] = 1,
                            },
                            [6] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 0.4000000000,
                                [2] = 1,
                                [3] = 0.4000000000,
                            },
                            [7] = 
                            {
                                [4] = 0.4000000000,
                                [1] = 1,
                                [2] = 0.4000000000,
                                [3] = 0.9000000000,
                            },
                        },
                        ["category"] = "damageOut",
                        ["SmoothWindow"] = 5,
                        ["mainpanel"] = "FightStats",
                        ["hitCritLayout"] = 
                        {
                            ["damageOut"] = 1,
                            ["damageIn"] = 1,
                            ["healingOut"] = 1,
                            ["healingIn"] = 1,
                        },
                        ["Cursor"] = true,
                    },
                    ["lightmode"] = false,
                },
            },
        },
    },
}
