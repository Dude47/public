PersonalAssistantBanking_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
                [1] = 
                {
                    ["name"] = "Profile 1",
                    ["Advanced"] = 
                    {
                        ["MasterWritCraftingTypes"] = 
                        {
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [5] = 1,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["LearnableItemTypes"] = 
                        {
                            [8] = 
                            {
                                ["Unknown"] = 0,
                                ["Known"] = 1,
                            },
                            [29] = 
                            {
                                ["Unknown"] = 0,
                                ["Known"] = 1,
                            },
                        },
                        ["ItemTraitTypes"] = 
                        {
                            [24] = 0,
                            [9] = 0,
                            [10] = 0,
                            [27] = 0,
                            [20] = 0,
                            [19] = 0,
                        },
                        ["SpecializedItemTypes"] = 
                        {
                            [104] = 1,
                            [113] = 1,
                            [101] = 
                            {
                                [24] = 1,
                                [17] = 1,
                                [16] = 1,
                                [13] = 1,
                                [14] = 1,
                                [15] = 1,
                            },
                            [110] = 1,
                            [108] = 1,
                            [109] = 1,
                            [102] = 1,
                            [100] = 1,
                        },
                        ["advancedItemsEnabled"] = true,
                        ["HolidayWrits"] = 
                        {
                            [2760] = 1,
                        },
                        ["ItemTypes"] = 
                        {
                            [20] = 0,
                            [21] = 0,
                            [54] = 0,
                            [7] = 0,
                            [26] = 0,
                            [12] = 0,
                            [61] = 1,
                            [30] = 0,
                            [4] = 0,
                        },
                    },
                    ["autoStackBags"] = true,
                    ["excludeJunk"] = true,
                    ["Crafting"] = 
                    {
                        ["craftingItemsEnabled"] = true,
                        ["ItemTypes"] = 
                        {
                            [64] = 1,
                            [65] = 1,
                            [66] = 1,
                            [35] = 1,
                            [36] = 1,
                            [37] = 1,
                            [38] = 1,
                            [39] = 1,
                            [40] = 1,
                            [41] = 1,
                            [42] = 1,
                            [43] = 1,
                            [44] = 1,
                            [45] = 1,
                            [46] = 1,
                            [16] = 1,
                            [17] = 1,
                            [51] = 1,
                            [52] = 1,
                            [53] = 1,
                            [31] = 1,
                            [68] = 1,
                            [58] = 1,
                            [10] = 1,
                            [33] = 1,
                            [67] = 1,
                            [62] = 1,
                            [63] = 1,
                        },
                    },
                    ["autoExecuteItemTransfers"] = true,
                    ["silentMode"] = true,
                    ["AvA"] = 
                    {
                        ["avaItemsEnabled"] = false,
                        ["ItemIds"] = 
                        {
                            [27112] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [27962] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [141731] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [142133] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [27138] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                        },
                        ["CrossAllianceItemIds"] = 
                        {
                            [6000] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [4000] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [1300] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [2100] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [1200] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [3100] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [3000] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [5000] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [3200] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [1000] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [2200] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [1100] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [3400] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [3300] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                            [2000] = 
                            {
                                ["bagAmount"] = 0,
                                ["operator"] = 0,
                            },
                        },
                    },
                    ["transactionDepositStacking"] = 0,
                    ["Currencies"] = 
                    {
                        ["goldTransaction"] = true,
                        ["alliancePointsMaxToKeep"] = 0,
                        ["telVarMaxToKeep"] = 0,
                        ["alliancePointsMinToKeep"] = 0,
                        ["alliancePointsTransaction"] = true,
                        ["writVouchersMaxToKeep"] = 0,
                        ["telVarMinToKeep"] = 0,
                        ["currenciesEnabled"] = true,
                        ["writVouchersMinToKeep"] = 0,
                        ["telVarTransaction"] = true,
                        ["writVouchersTransaction"] = true,
                        ["goldMinToKeep"] = 100000,
                        ["goldMaxToKeep"] = 100000,
                    },
                    ["transactionWithdrawalStacking"] = 0,
                    ["Custom"] = 
                    {
                        ["customItemsEnabled"] = true,
                        ["PAItemIds"] = 
                        {
                            ["30357"] = 
                            {
                                ["itemLink"] = "|H0:item:30357:175:1:0:0:0:0:0:0:0:0:0:0:0:0:36:0:0:0:0:0|h|h",
                                ["bagAmount"] = 50,
                                ["ruleEnabled"] = true,
                                ["operator"] = 1,
                            },
                        },
                    },
                },
                ["savedVarsVersion"] = 20230728,
                ["profileCounter"] = 1,
            },
        },
    },
}
