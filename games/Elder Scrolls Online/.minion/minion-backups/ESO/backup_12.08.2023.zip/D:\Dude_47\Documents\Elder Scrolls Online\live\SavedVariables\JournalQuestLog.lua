JournalQuestLog_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["listGrouped"] = false,
                ["version"] = 1,
                ["showMissed"] = true,
                ["showUnavailable"] = true,
                ["showRepeatable"] = true,
            },
        },
    },
}
