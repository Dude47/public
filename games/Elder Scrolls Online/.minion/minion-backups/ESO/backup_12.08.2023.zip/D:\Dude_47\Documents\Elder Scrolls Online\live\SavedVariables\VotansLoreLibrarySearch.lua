VotansLoreLibrarySearch_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["highlight"] = true,
                ["version"] = 1,
                ["highlightColor"] = "a06018",
            },
        },
    },
}
