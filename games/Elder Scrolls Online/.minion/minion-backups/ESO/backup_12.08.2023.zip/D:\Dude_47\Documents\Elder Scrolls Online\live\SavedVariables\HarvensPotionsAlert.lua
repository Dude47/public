HarvensPotionsAlert_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["Galrnskar Haraendottir"] = 
            {
                ["pos"] = 
                {
                    ["y"] = 0,
                    ["point"] = 128,
                    ["relPoint"] = 128,
                    ["x"] = 0,
                },
                ["cooldownAlert"] = true,
                ["pos2"] = 
                {
                    ["y"] = 0,
                    ["point"] = 128,
                    ["relPoint"] = 128,
                    ["x"] = 0,
                },
                ["slots"] = 
                {
                    [4] = 
                    {
                        ["id"] = 0,
                        ["value"] = 100,
                        ["threshold"] = 0,
                    },
                    [1] = 
                    {
                        ["id"] = 0,
                        ["value"] = 100,
                        ["threshold"] = 0,
                    },
                    [32] = 
                    {
                        ["id"] = 0,
                        ["value"] = 100,
                        ["threshold"] = 0,
                    },
                    [1000] = 
                    {
                        ["id"] = 4,
                        ["value"] = 100,
                        ["threshold"] = 0,
                    },
                },
                ["version"] = 1,
                ["cooldownAlertFont"] = "$(BOLD_FONT)|36|thick-outline",
                ["scale"] = 1,
                ["cooldownAlertIconSize"] = 48,
            },
        },
    },
}
