DolgubonsWritCrafterSavedVars =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = true,
                [5] = true,
                [6] = true,
                [7] = true,
                ["autoCraft"] = false,
                ["OffsetX"] = 1150,
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["statusBarX"] = 1421.5000000000,
                ["updateChoiceCopies"] = 
                {
                },
                ["scanForUnopened"] = false,
                ["keepQuestBuffer"] = false,
                ["EZJewelryDestroy"] = true,
                ["keepNewContainer"] = true,
                ["debug"] = false,
                ["lootContainerOnReceipt"] = true,
                ["stealProtection"] = true,
                ["dailyResetWarnType"] = "announcement",
                ["rewardHandling"] = 
                {
                    ["ornate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["master"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["survey"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["all"] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["recipe"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["intricate"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["soulGem"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["fragment"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["glyph"] = 
                    {
                        [0] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                    ["repair"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        ["sameForAllCrafts"] = true,
                        ["all"] = 1,
                        [6] = 1,
                        [7] = 1,
                    },
                    ["mats"] = 
                    {
                        [0] = 1,
                        [1] = 1,
                        [2] = 1,
                        [3] = 1,
                        [4] = 1,
                        [5] = 1,
                        [6] = 1,
                        [7] = 1,
                        ["sameForAllCrafts"] = true,
                    },
                },
                ["lootOutput"] = false,
                ["jewelryWritDestroy"] = false,
                ["OffsetY"] = 0,
                ["tutorial"] = true,
                ["autoLoot"] = true,
                ["useCharacterSettings"] = false,
                ["reticleAntiSteal"] = true,
                ["statusBarInventory"] = true,
                ["autoCloseBank"] = true,
                ["showWindow"] = true,
                ["showStatusBar"] = true,
                ["version"] = 19,
                ["autoAccept"] = true,
                ["statusBarIcons"] = false,
                ["craftMultiplier"] = 1,
                ["shouldGrab"] = true,
                ["suppressQuestAnnouncements"] = true,
                ["statusBarY"] = 1270,
                ["dailyResetWarnTime"] = 60,
                ["transparentStatusBar"] = false,
                ["transmuteBlock"] = 
                {
                },
                ["delay"] = 100,
                ["ignoreAuto"] = false,
                ["changeReticle"] = true,
                ["exitWhenDone"] = true,
                ["despawnBanker"] = true,
                ["skipItemQuests"] = 
                {
                    ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                },
                ["mail"] = 
                {
                    ["delete"] = false,
                    ["loot"] = false,
                },
                ["lootJubileeBoxes"] = true,
                ["styles"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    [8] = true,
                    [9] = true,
                    [10] = true,
                    [34] = true,
                },
                ["containerDelay"] = 1,
                ["hideWhenDone"] = true,
            },
            ["$AccountWide"] = 
            {
                ["writLocations"] = 
                {
                    [57] = 
                    {
                        [1] = 10,
                        [2] = 231085,
                        [3] = 249391,
                        [4] = 1000000,
                    },
                    [849] = 
                    {
                        [1] = 849,
                        [2] = 215118,
                        [3] = 512682,
                        [4] = 1000000,
                    },
                    [1011] = 
                    {
                        [1] = 1011,
                        [2] = 146161,
                        [3] = 341851,
                        [4] = 1000000,
                    },
                    [20] = 
                    {
                        [1] = 20,
                        [2] = 243273,
                        [3] = 227612,
                        [4] = 1000000,
                    },
                    [347] = 
                    {
                        [1] = 347,
                        [2] = 237668,
                        [3] = 302699,
                        [4] = 1000000,
                    },
                    [382] = 
                    {
                        [1] = 382,
                        [2] = 122717,
                        [3] = 187928,
                        [4] = 1000000,
                    },
                    [103] = 
                    {
                        [1] = 103,
                        [2] = 366252,
                        [3] = 201624,
                        [4] = 2000000,
                    },
                },
                ["total"] = 0,
                ["masterWrits"] = true,
                ["updateNoticesShown"] = 
                {
                },
                ["identifier"] = 354,
                ["rewards"] = 
                {
                    [1] = 
                    {
                        ["ornate"] = 0,
                        ["master"] = 0,
                        ["survey"] = 0,
                        ["material"] = 0,
                        ["intricate"] = 0,
                        ["num"] = 0,
                        ["fragment"] = 0,
                        ["repair"] = 0,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                    },
                    [2] = 
                    {
                        ["ornate"] = 0,
                        ["master"] = 0,
                        ["survey"] = 0,
                        ["material"] = 0,
                        ["intricate"] = 0,
                        ["num"] = 0,
                        ["fragment"] = 0,
                        ["repair"] = 0,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                    },
                    [3] = 
                    {
                        ["soulGem"] = 0,
                        ["master"] = 0,
                        ["survey"] = 0,
                        ["glyph"] = 0,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        ["num"] = 0,
                    },
                    [4] = 
                    {
                        ["master"] = 0,
                        ["survey"] = 0,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        ["num"] = 0,
                    },
                    [5] = 
                    {
                        ["master"] = 0,
                        ["fragment"] = 0,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        ["num"] = 0,
                    },
                    [6] = 
                    {
                        ["ornate"] = 0,
                        ["master"] = 0,
                        ["survey"] = 0,
                        ["material"] = 0,
                        ["intricate"] = 0,
                        ["num"] = 0,
                        ["fragment"] = 0,
                        ["repair"] = 0,
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                    },
                    [7] = 
                    {
                        ["recipe"] = 
                        {
                            ["purple"] = 0,
                            ["white"] = 0,
                            ["blue"] = 0,
                            ["gold"] = 0,
                            ["green"] = 0,
                        },
                        ["num"] = 0,
                    },
                },
                ["skipped"] = 0,
                ["alternateUniverse"] = true,
                ["unlockedCheese"] = false,
                [6697110] = false,
                ["luckyProgress"] = 
                {
                    ["gutDestruction"] = 0,
                    ["luckCompletion"] = 0,
                    ["rngesus"] = 0,
                    ["readInstructions"] = 0,
                    ["lootGut"] = 0,
                    ["cheeseCompletion"] = 0,
                    ["cheeseNerd"] = 0,
                    ["shootingOnLocation"] = 0,
                },
                ["unlockedGoat"] = false,
                ["notifyWiped"] = true,
                ["accountWideProfile"] = 
                {
                    [1] = true,
                    [2] = true,
                    [3] = true,
                    [4] = true,
                    [5] = true,
                    [6] = true,
                    [7] = true,
                    ["autoCraft"] = true,
                    ["OffsetX"] = 1150,
                    ["statusBarX"] = 1421.5000000000,
                    ["updateChoiceCopies"] = 
                    {
                    },
                    ["scanForUnopened"] = false,
                    ["keepQuestBuffer"] = false,
                    ["EZJewelryDestroy"] = true,
                    ["keepNewContainer"] = true,
                    ["debug"] = false,
                    ["lootContainerOnReceipt"] = true,
                    ["stealProtection"] = true,
                    ["dailyResetWarnType"] = "announcement",
                    ["rewardHandling"] = 
                    {
                        ["ornate"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            ["sameForAllCrafts"] = true,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["master"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [5] = 1,
                            [6] = 1,
                            [7] = 1,
                            ["all"] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["survey"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [6] = 1,
                            [7] = 1,
                            ["all"] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["recipe"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["intricate"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            ["sameForAllCrafts"] = true,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["soulGem"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["fragment"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["glyph"] = 
                        {
                            [0] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                        ["repair"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            ["sameForAllCrafts"] = true,
                            ["all"] = 1,
                            [6] = 1,
                            [7] = 1,
                        },
                        ["mats"] = 
                        {
                            [0] = 1,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                            [4] = 1,
                            [5] = 1,
                            [6] = 1,
                            [7] = 1,
                            ["sameForAllCrafts"] = true,
                        },
                    },
                    ["lootOutput"] = false,
                    ["jewelryWritDestroy"] = false,
                    ["tutorial"] = false,
                    ["autoLoot"] = true,
                    ["OffsetY"] = 0,
                    ["statusBarInventory"] = true,
                    ["lootJubileeBoxes"] = true,
                    ["statusBarY"] = 1270,
                    ["showWindow"] = true,
                    ["showStatusBar"] = true,
                    ["autoCloseBank"] = true,
                    ["autoAccept"] = true,
                    ["statusBarIcons"] = false,
                    ["craftMultiplier"] = 1,
                    ["shouldGrab"] = true,
                    ["suppressQuestAnnouncements"] = true,
                    ["despawnBanker"] = true,
                    ["dailyResetWarnTime"] = 60,
                    ["transparentStatusBar"] = false,
                    ["transmuteBlock"] = 
                    {
                    },
                    ["delay"] = 100,
                    ["ignoreAuto"] = false,
                    ["changeReticle"] = true,
                    ["exitWhenDone"] = true,
                    ["useCharacterSettings"] = false,
                    ["skipItemQuests"] = 
                    {
                        ["|H1:item:30165:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:45831:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:30152:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:45850:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                        ["|H1:item:77591:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h"] = true,
                    },
                    ["mail"] = 
                    {
                        ["delete"] = false,
                        ["loot"] = false,
                    },
                    ["styles"] = 
                    {
                        [1] = true,
                        [2] = true,
                        [3] = true,
                        [4] = true,
                        [5] = true,
                        [6] = true,
                        [7] = true,
                        [8] = true,
                        [9] = true,
                        [10] = true,
                        [34] = true,
                    },
                    ["containerDelay"] = 1,
                    ["hideWhenDone"] = true,
                    ["reticleAntiSteal"] = true,
                },
                ["version"] = 20,
                ["timeSinceReset"] = 1691522653,
                ["skin"] = "default",
                ["cheesyProgress"] = 
                {
                    ["cheeseCompletion"] = 0,
                    ["cheeseProfession"] = 0,
                    ["sheoVisit"] = 0,
                    ["music"] = 0,
                    ["cheeseNerd"] = 0,
                    ["cheesyDestruction"] = 0,
                },
                ["updateDefaultCopyValue"] = 
                {
                },
            },
        },
    },
}
