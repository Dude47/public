VotansRuneTooltips_Storage =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["showUnknownPotency"] = true,
                ["showUnknownEssence"] = true,
                ["version"] = 1,
            },
        },
    },
}
