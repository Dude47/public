LootLogSavedVariables =
{
    ["Default"] = 
    {
        ["$InstallationWide"] = 
        {
            ["$AccountWide"] = 
            {
                ["historyHours"] = 2,
                ["chatItemCollector"] = true,
                ["tradeRequestMode"] = 1,
                ["tradeCommandsCount"] = 0,
                ["featureRev"] = 4,
                ["tradeIncludeBoE"] = false,
                ["version"] = 2,
                ["chatCraftCount"] = false,
                ["tradeFlagItemLists"] = true,
                ["chatIcons"] = false,
                ["uncollectedColors"] = 
                {
                    ["itemLists"] = 13369446,
                    ["lootedGroup"] = 16750848,
                    ["lootedPersonal"] = 13369344,
                    ["linkedChat"] = 13421568,
                },
                ["autoBind"] = 
                {
                    ["stopTime"] = 0,
                    ["junk"] = false,
                },
                ["multi"] = 
                {
                    ["colors"] = 
                    {
                        [1] = 13434828,
                        [2] = 52377,
                        [3] = 3394815,
                    },
                },
                ["tradeFlagChat"] = true,
                ["tradeRequestPrefix"] = "Requesting",
                ["historyShowUncollected"] = false,
                ["historyMode"] = 4,
                ["chatStaticRecipientColor"] = 
                {
                    ["enabled"] = false,
                    ["color"] = 3381759,
                },
                ["chatMode"] = 4,
            },
        },
    },
}
LootLogHistory =
{
    ["EU"] = 
    {
    },
}
