QuestTrackerSavedVars =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["fontSettings"] = 
                {
                    ["conditions"] = 
                    {
                        ["size"] = 14,
                        ["font"] = "Bold",
                        ["outline"] = "Soft Thick Shadow",
                        ["color"] = 
                        {
                            [4] = 1,
                            [1] = 0.7725490928,
                            [2] = 0.7607843876,
                            [3] = 0.6196078658,
                        },
                    },
                    ["categories"] = 
                    {
                        ["size"] = 20,
                        ["font"] = "Bold",
                        ["outline"] = "Soft Thick Shadow",
                        ["color"] = 
                        {
                            [4] = 1,
                            [1] = 0.7725490928,
                            [2] = 0.7607843876,
                            [3] = 0.6196078658,
                        },
                    },
                    ["quests"] = 
                    {
                        ["size"] = 16,
                        ["font"] = "Bold",
                        ["outline"] = "Soft Thick Shadow",
                        ["color"] = 
                        {
                            [4] = 1,
                            [1] = 0.7725490928,
                            [2] = 0.7607843876,
                            [3] = 0.6196078658,
                        },
                    },
                },
                ["accountWide"] = true,
                ["nodeExclusitivity"] = 
                {
                    ["questNodes"] = false,
                    ["allNodes"] = true,
                    ["currentSetting"] = "All",
                    ["isTreeExclusive"] = true,
                    ["categoryNodes"] = false,
                },
                ["showQuestLevel"] = true,
                ["hideInCombat"] = true,
                ["chatAlertType"] = "Detailed",
                ["questTrackForceAssist"] = true,
                ["overrideConColors"] = false,
                ["hideFocusedQuestTracker"] = true,
                ["showNumCategoryQuests"] = false,
                ["tooltips"] = 
                {
                    ["anchorPoint"] = 2,
                    ["relativeTo"] = 8,
                    ["autoTooltip"] = false,
                    ["show"] = true,
                    ["fadeTime"] = 5,
                },
                ["autoOpenNodes"] = false,
                ["autoOpenCategoryOnLogin"] = false,
                ["sortByLevel"] = true,
                ["version"] = 3,
                ["hideDefaultQuestTracker"] = true,
                ["mainWindow"] = 
                {
                    ["autoWindowSizeWidth"] = true,
                    ["height"] = 400,
                    ["showInGameScene"] = false,
                    ["autoWindowSizeHeight"] = true,
                    ["offsetX"] = 2307,
                    ["offsetY"] = 308,
                    ["hideLockIcon"] = "Never",
                    ["width"] = 300,
                    ["backdrop"] = 
                    {
                        ["backdropAlpha"] = 0.5000000000,
                        ["backdropColor"] = 
                        {
                            [4] = 0.5019608140,
                            [1] = 0,
                            [2] = 0,
                            [3] = 0,
                        },
                        ["backdropHideOnLock"] = true,
                        ["hideMungeOverlay"] = false,
                        ["dragBarColor"] = 
                        {
                            [4] = 1,
                            [1] = 0,
                            [2] = 0,
                            [3] = 0,
                        },
                        ["backdropName"] = "Colored",
                    },
                    ["isItLocked"] = true,
                    ["hideQuestWindow"] = false,
                    ["locked"] = false,
                },
            },
            ["Galrnskar Haraendottir"] = 
            {
                ["fontSettings"] = 
                {
                    ["conditions"] = 
                    {
                        ["size"] = 14,
                        ["font"] = "Bold",
                        ["outline"] = "Soft Thick Shadow",
                        ["color"] = 
                        {
                            [4] = 1,
                            [1] = 0.7725490928,
                            [2] = 0.7607843876,
                            [3] = 0.6196078658,
                        },
                    },
                    ["categories"] = 
                    {
                        ["size"] = 20,
                        ["font"] = "Bold",
                        ["outline"] = "Soft Thick Shadow",
                        ["color"] = 
                        {
                            [4] = 1,
                            [1] = 0.7725490928,
                            [2] = 0.7607843876,
                            [3] = 0.6196078658,
                        },
                    },
                    ["quests"] = 
                    {
                        ["size"] = 16,
                        ["font"] = "Bold",
                        ["outline"] = "Soft Thick Shadow",
                        ["color"] = 
                        {
                            [4] = 1,
                            [1] = 0.7725490928,
                            [2] = 0.7607843876,
                            [3] = 0.6196078658,
                        },
                    },
                },
                ["accountWide"] = true,
                ["nodeExclusitivity"] = 
                {
                    ["questNodes"] = false,
                    ["allNodes"] = false,
                    ["currentSetting"] = "None",
                    ["isTreeExclusive"] = false,
                    ["categoryNodes"] = false,
                },
                ["showQuestLevel"] = true,
                ["hideInCombat"] = true,
                ["chatAlertType"] = "Detailed",
                ["questTrackForceAssist"] = true,
                ["overrideConColors"] = false,
                ["hideFocusedQuestTracker"] = true,
                ["showNumCategoryQuests"] = true,
                ["tooltips"] = 
                {
                    ["anchorPoint"] = 2,
                    ["relativeTo"] = 8,
                    ["autoTooltip"] = false,
                    ["show"] = true,
                    ["fadeTime"] = 5,
                },
                ["autoOpenNodes"] = false,
                ["autoOpenCategoryOnLogin"] = false,
                ["sortByLevel"] = true,
                ["version"] = 3,
                ["hideDefaultQuestTracker"] = true,
                ["mainWindow"] = 
                {
                    ["autoWindowSizeWidth"] = true,
                    ["height"] = 400,
                    ["showInGameScene"] = false,
                    ["autoWindowSizeHeight"] = true,
                    ["offsetX"] = 100,
                    ["offsetY"] = 100,
                    ["hideLockIcon"] = "Never",
                    ["width"] = 300,
                    ["backdrop"] = 
                    {
                        ["backdropAlpha"] = 0.5000000000,
                        ["backdropColor"] = 
                        {
                            [4] = 0.5000000000,
                            [1] = 0,
                            [2] = 0,
                            [3] = 0,
                        },
                        ["backdropHideOnLock"] = false,
                        ["hideMungeOverlay"] = false,
                        ["dragBarColor"] = 
                        {
                            [4] = 0.5000000000,
                            [1] = 1,
                            [2] = 1,
                            [3] = 1,
                        },
                        ["backdropName"] = "Colored",
                    },
                    ["isItLocked"] = false,
                    ["hideQuestWindow"] = false,
                    ["locked"] = false,
                },
            },
        },
    },
}
