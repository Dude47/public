LibSets_SV_Data =
{
    ["EU Megaserver"] = 
    {
        ["$AllAccounts"] = 
        {
            ["$AccountWide"] = 
            {
                ["modifyTooltips"] = false,
                ["version"] = 0.3800000000,
                ["tooltipModifications"] = 
                {
                    ["tooltipTextures"] = true,
                    ["addDropMechanic"] = true,
                    ["addBossName"] = true,
                    ["addSetType"] = true,
                    ["addDLC"] = true,
                    ["addDropLocation"] = true,
                    ["addReconstructionCost"] = true,
                    ["addNeededTraits"] = true,
                },
                ["useCustomTooltipPattern"] = "",
                ["addSetCollectionsCurrentZoneButton"] = true,
                ["setPreviewTooltips"] = 
                {
                    ["enchantSearchCategoryType"] = 0,
                    ["sendToChatToo"] = true,
                    ["quality"] = 370,
                    ["equipType"] = 3,
                    ["traitType"] = 18,
                },
            },
        },
    },
}
LibSets_SV_DEBUG_Data =
{
    ["Default"] = 
    {
        ["$AllAccounts"] = 
        {
            ["$AccountWide"] = 
            {
                ["collectibleNames"] = 
                {
                },
                ["maps"] = 
                {
                },
                ["setItemIdsNoSetId"] = 
                {
                },
                ["setItemIds"] = 
                {
                },
                ["setItemIds_Compressed"] = 
                {
                },
                ["NewSetIDs"] = 
                {
                },
                ["wayshrineNames"] = 
                {
                },
                ["collectible_DLCNames"] = 
                {
                },
                ["version"] = 1,
                ["setNames"] = 
                {
                },
                ["zoneData"] = 
                {
                },
                ["dungeonFinderData"] = 
                {
                },
            },
        },
    },
}
