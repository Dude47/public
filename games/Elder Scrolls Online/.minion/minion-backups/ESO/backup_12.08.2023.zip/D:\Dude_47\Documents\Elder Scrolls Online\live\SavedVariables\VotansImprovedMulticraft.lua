VotansImprovedMulticraft_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["creationSpinner"] = 
                {
                },
                ["nonCrafterProtect"] = false,
                ["autoMaxRefinement"] = false,
                ["version"] = 1,
            },
        },
    },
}
