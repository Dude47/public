PersonalAssistantJunk_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["profileCounter"] = 1,
                [1] = 
                {
                    ["Jewelry"] = 
                    {
                        ["autoMarkIncludingSets"] = false,
                        ["autoMarkKnownTraits"] = true,
                        ["autoMarkQualityThreshold"] = -1,
                        ["autoMarkOrnate"] = false,
                        ["autoMarkIntricateTrait"] = false,
                        ["autoMarkUnknownTraits"] = false,
                    },
                    ["silentMode"] = false,
                    ["KeyBindings"] = 
                    {
                        ["showMarkUnmarkAsJunkKeybind"] = true,
                        ["destroyItemQualityThreshold"] = 5,
                        ["enableDestroyItemKeybind"] = false,
                        ["showMarkUnmarkAsPermJunkKeybind"] = true,
                        ["showDestroyItemKeybind"] = true,
                        ["destroyExcludeUnknownItems"] = false,
                        ["enableMarkUnmarkAsPermJunkKeybind"] = true,
                        ["enableMarkUnmarkAsJunkKeybind"] = true,
                    },
                    ["Weapons"] = 
                    {
                        ["autoMarkIncludingSets"] = false,
                        ["autoMarkKnownTraits"] = true,
                        ["autoMarkQualityThreshold"] = -1,
                        ["autoMarkOrnate"] = false,
                        ["autoMarkIntricateTrait"] = false,
                        ["autoMarkUnknownTraits"] = false,
                    },
                    ["autoMarkAsJunkEnabled"] = false,
                    ["Collectibles"] = 
                    {
                        ["autoMarkSellToMerchant"] = true,
                    },
                    ["Stolen"] = 
                    {
                        ["solvents"] = false,
                        ["lures"] = false,
                        ["weapons"] = false,
                        ["drinks"] = false,
                        ["traitItems"] = false,
                        ["styleMaterials"] = false,
                        ["trash"] = false,
                        ["jewelries"] = false,
                        ["treasures"] = false,
                        ["ingredients"] = false,
                        ["apparels"] = false,
                        ["food"] = false,
                    },
                    ["name"] = "Profile 1",
                    ["autoSellJunkPirharri"] = false,
                    ["Custom"] = 
                    {
                        ["customItemsEnabled"] = true,
                        ["PAItemIds"] = 
                        {
                            ["54387"] = 
                            {
                                ["itemLink"] = "|H0:item:54387:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["ruleAdded"] = 1691693647,
                                ["junkCount"] = 0,
                            },
                            ["54382"] = 
                            {
                                ["itemLink"] = "|H0:item:54382:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["ruleAdded"] = 1691692991,
                                ["junkCount"] = 0,
                            },
                            ["57659"] = 
                            {
                                ["itemLink"] = "|H0:item:57659:177:50:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0|h|h",
                                ["ruleAdded"] = 1691693639,
                                ["junkCount"] = 0,
                            },
                        },
                    },
                    ["QuestProtection"] = 
                    {
                        ["ThievesGuild"] = 
                        {
                            ["excludeTheCovetousCountess"] = false,
                        },
                        ["NewLifeFestival"] = 
                        {
                            ["excludeRareFish"] = true,
                        },
                        ["ClockworkCity"] = 
                        {
                            ["excludeNibblesAndBits"] = false,
                            ["excludeAMatterOfLeisure"] = false,
                            ["excludeAMatterOfRespect"] = false,
                            ["excludeMorselsAndPecks"] = false,
                            ["excludeAMatterOfTributes"] = false,
                        },
                    },
                    ["Armor"] = 
                    {
                        ["autoMarkIncludingSets"] = false,
                        ["autoMarkKnownTraits"] = true,
                        ["autoMarkQualityThreshold"] = -1,
                        ["autoMarkOrnate"] = false,
                        ["autoMarkIntricateTrait"] = false,
                        ["autoMarkUnknownTraits"] = false,
                    },
                    ["ignoreCraftedItems"] = true,
                    ["Miscellaneous"] = 
                    {
                        ["autoMarkTreasure"] = false,
                        ["autoMarkCompanionItemsQualityThreshold"] = -1,
                        ["autoMarkGlyphQualityThreshold"] = -1,
                    },
                    ["autoSellJunk"] = true,
                    ["AutoDestroy"] = 
                    {
                        ["destroyMaxValueThreshold"] = 0,
                        ["destroyMaxStolenValueThreshold"] = 0,
                        ["destroyStolenJunk"] = false,
                        ["destroyMaxQualityThreshold"] = 0,
                        ["destroyJunk"] = false,
                        ["destroyMaxStolenQualityThreshold"] = 0,
                    },
                    ["Trash"] = 
                    {
                        ["autoMarkTrash"] = true,
                    },
                    ["ignoreMailboxItems"] = true,
                },
                ["savedVarsVersion"] = 20230728,
                ["version"] = 2,
            },
        },
    },
}
