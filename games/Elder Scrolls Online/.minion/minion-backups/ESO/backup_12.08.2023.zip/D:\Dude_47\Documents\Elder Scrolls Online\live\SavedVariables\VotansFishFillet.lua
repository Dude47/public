VotanFishFillet_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["showAllStacks"] = true,
                ["version"] = 1,
                ["stats"] = 
                {
                    ["perfectRoe"] = 0,
                    ["fishes"] = 0,
                },
                ["filletAllStacks"] = false,
            },
        },
    },
}
