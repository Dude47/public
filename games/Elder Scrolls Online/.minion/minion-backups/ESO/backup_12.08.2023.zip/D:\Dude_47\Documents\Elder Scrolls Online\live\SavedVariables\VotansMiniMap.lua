VotansMiniMap_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["version"] = 1,
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["showMap"] = true,
            },
            ["$AccountWide"] = 
            {
                ["showCameraAngle"] = true,
                ["showRealTimeClock"] = true,
                ["titleFontSize"] = 22,
                ["zoomToPlayer"] = false,
                ["enableMap"] = true,
                ["showMounted"] = true,
                ["frameStyle"] = "ESO",
                ["allowFloorNavigation"] = true,
                ["keepSquare"] = true,
                ["zoom"] = 0.7500000000,
                ["subZoneZoom"] = 1,
                ["enableTweaks"] = true,
                ["debug"] = false,
                ["titleColor"] = 
                {
                    [4] = 1,
                    [1] = 0.7725490928,
                    [2] = 0.7607843876,
                    [3] = 0.6196078658,
                },
                ["lockWindow"] = false,
                ["showOnTop"] = false,
                ["height"] = 317,
                ["showClock"] = true,
                ["showLoot"] = true,
                ["cameraAngle"] = 45,
                ["fixedMaps"] = 
                {
                },
                ["mountedZoom"] = 0.6000000000,
                ["titleAtTop"] = true,
                ["showInGameClock"] = true,
                ["zoneAlertMode"] = "MINIMAPHIDDEN",
                ["version"] = 1,
                ["x"] = 1156.5000000000,
                ["zoomOut"] = 0.1500000000,
                ["battlegroundZoom"] = 0,
                ["zoomIn"] = 2,
                ["borderAlpha"] = 100,
                ["unitPinScaleLimit"] = 0.8000000000,
                ["titleFont"] = "BOLD_FONT",
                ["showHUD"] = true,
                ["dungeonZoom"] = 0.7000000000,
                ["enableCompass"] = "UNTOUCHED",
                ["showCombat"] = false,
                ["width"] = 255,
                ["asyncUpdate"] = false,
                ["showFullTitle"] = false,
                ["y"] = -566,
                ["pinSizes"] = 
                {
                },
                ["showSiege"] = false,
                ["timeFormat"] = 4,
            },
        },
    },
}
