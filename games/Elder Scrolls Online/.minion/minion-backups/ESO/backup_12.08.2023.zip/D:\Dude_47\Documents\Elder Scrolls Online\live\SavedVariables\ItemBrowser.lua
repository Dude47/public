ItemBrowserSavedVariables =
{
    ["Default"] = 
    {
        ["$InstallationWide"] = 
        {
            ["$AccountWide"] = 
            {
                ["favorites"] = 
                {
                },
                ["tooltipColors"] = 
                {
                    ["pieces"] = 
                    {
                        ["unlocked"] = 65280,
                        ["locked"] = 16711680,
                    },
                    ["accounts"] = 
                    {
                        ["unlocked"] = 3381759,
                        ["locked"] = 7829350,
                    },
                },
                ["version"] = 1,
                ["externalTooltips"] = 
                {
                    ["showPieces"] = 1,
                    ["showAccounts"] = 1,
                    ["enableExtension"] = true,
                },
                ["filterId"] = 1,
                ["usePercentage"] = false,
            },
        },
    },
}
