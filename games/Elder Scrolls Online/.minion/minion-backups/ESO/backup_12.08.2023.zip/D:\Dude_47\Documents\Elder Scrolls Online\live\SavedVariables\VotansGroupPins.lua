VotansGroupPins_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["showFriendMarker"] = true,
                ["healthBad"] = "CC0000",
                ["simpleMemberColor"] = "FFFFFF",
                ["healthGood"] = "00CC00",
                ["pveColor"] = "Health",
                ["healthDead"] = "CCCCCC",
                ["simpleLeaderColor"] = "FFFFFF",
                ["simplePlayerColor"] = "6BF5F4",
                ["avaColor"] = "Health",
                ["simpleFriendColor"] = "00b400",
                ["version"] = 1,
                ["showLeaderCrown"] = true,
                ["pveIcon"] = "Class",
                ["avaIcon"] = "Class",
                ["healthWarn"] = "C0C000",
            },
        },
    },
}
