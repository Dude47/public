VotansFisherman_Data =
{
    ["zoneToLure5"] = 
    {
        [101] = 
        {
            [1691695856] = 
            {
                ["my"] = 0.2908996104,
                ["py"] = 0.2893339940,
                ["count"] = 0,
                ["mx"] = 0.6351176349,
                ["lureType"] = 
                {
                    [3] = true,
                },
                ["px"] = 0.6365172225,
                ["y"] = 0.2901168022,
                ["caught"] = 
                {
                },
                ["x"] = 0.6358174287,
            },
        },
        [41] = 
        {
            [1691788948] = 
            {
                ["my"] = 0.4634852121,
                ["py"] = 0.4642207966,
                ["count"] = 0,
                ["mx"] = 0.7334902338,
                ["lureType"] = 
                {
                    [2] = true,
                },
                ["px"] = 0.7354571896,
                ["y"] = 0.4638530043,
                ["caught"] = 
                {
                },
                ["x"] = 0.7344737117,
            },
            [1691789798] = 
            {
                ["my"] = 0.4376037755,
                ["py"] = 0.4388680011,
                ["count"] = 0,
                ["mx"] = 0.7460319707,
                ["lureType"] = 
                {
                    [4] = true,
                },
                ["px"] = 0.7477087931,
                ["y"] = 0.4382358883,
                ["caught"] = 
                {
                },
                ["x"] = 0.7468703819,
            },
        },
        [281] = 
        {
            [1691616183] = 
            {
                ["my"] = 0.4367490887,
                ["py"] = 0.4376192068,
                ["count"] = 0,
                ["mx"] = 0.8153771438,
                ["lureType"] = 
                {
                    [4] = true,
                },
                ["px"] = 0.8166899915,
                ["y"] = 0.4371841478,
                ["caught"] = 
                {
                },
                ["x"] = 0.8160335677,
            },
        },
        [57] = 
        {
            [1691856268] = 
            {
                ["my"] = 0.5126807801,
                ["py"] = 0.5133528148,
                ["count"] = 1,
                ["mx"] = 0.7990246754,
                ["lureType"] = 
                {
                    [3] = true,
                },
                ["px"] = 0.7983672062,
                ["y"] = 0.5127592966,
                ["caught"] = 
                {
                },
                ["x"] = 0.7989478606,
            },
        },
    },
    ["Default"] = 
    {
        ["$Machine"] = 
        {
            ["$UserProfileWide"] = 
            {
                ["version"] = 101038,
                ["focusRanges"] = 
                {
                },
            },
        },
        ["@Dude_47"] = 
        {
            ["8798292093726442"] = 
            {
                ["$LastCharacterName"] = "Galrnskar Haraendottir",
                ["showPins"] = 
                {
                    ["pve"] = true,
                    ["pvp"] = true,
                },
                ["version"] = 1,
            },
            ["$AccountWide"] = 
            {
                ["showDebug"] = false,
                ["showTooltip"] = true,
                ["pinLevel"] = 30,
                ["notificationAnim"] = "Pulse1",
                ["lureColors"] = 
                {
                    [4] = "345FE2",
                    [1] = "C2C444",
                    [2] = "7CAECC",
                    [3] = "2ECCBE",
                },
                ["showReelIn"] = true,
                ["version"] = 1,
                ["showContextMenu"] = true,
                ["autoHideRFT"] = false,
                ["reelInSize"] = 1,
                ["pinSize"] = 32,
                ["zoneStats"] = 
                {
                },
                ["showLootOnHUD"] = true,
                ["pinIcon"] = 
                {
                    [4] = "default",
                    [1] = "default",
                    [2] = "default",
                    [3] = "default",
                },
                ["autoReturnInteraction"] = false,
                ["reelInColor"] = "FFFFFF",
                ["showLootOnMap"] = true,
                ["preferBetterBait"] = false,
                ["showDefaultLoot"] = false,
                ["autoSwitchBait"] = false,
            },
        },
    },
}
