VotanSearchBox_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["searchSetName"] = true,
                ["version"] = 1,
                ["keepSticky"] = false,
                ["searchMasterWrit"] = true,
                ["allSameText"] = false,
                ["hideSearchBox"] = false,
            },
        },
    },
}
