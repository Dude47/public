LibChatMessageSettings =
{
    ["EU Megaserver@Dude_47"] = 
    {
        ["timePrefixOnRegularChat"] = true,
        ["historyMaxAge"] = 3600,
        ["historyEnabled"] = false,
        ["version"] = 1,
        ["tagPrefixMode"] = 2,
        ["timePrefixEnabled"] = false,
        ["timePrefixFormat"] = "[%X]",
    },
}
LibChatMessageHistory =
{
    ["EU Megaserver@Dude_47"] = 
    {
    },
}
