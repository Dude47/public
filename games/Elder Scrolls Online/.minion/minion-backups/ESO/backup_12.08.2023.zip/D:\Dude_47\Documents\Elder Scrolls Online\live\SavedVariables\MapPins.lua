MP_SavedVars =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["Galrnskar Haraendottir"] = 
            {
                [1] = true,
                [2] = true,
                [3] = true,
                [4] = false,
                [5] = true,
                [6] = false,
                [7] = false,
                [8] = true,
                [9] = false,
                [10] = false,
                [11] = false,
                [12] = false,
                [13] = false,
                [14] = false,
                [15] = false,
                [16] = false,
                [17] = false,
                [18] = false,
                [19] = false,
                [20] = false,
                [21] = true,
                [22] = false,
                [23] = false,
                [24] = false,
                [26] = false,
                [27] = false,
                [28] = false,
                ["version"] = 2,
                ["TimeBreachClosed"] = 
                {
                },
            },
        },
    },
}
MP_SavedGlobal =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["pinsize"] = 20,
                ["version"] = 1,
            },
        },
    },
}
MP_ChestData =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
            },
        },
    },
}
MP_ThievesTrove =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
            },
        },
    },
}
