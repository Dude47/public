CombatAlertsSavedVariables =
{
    ["Default"] = 
    {
        ["$InstallationWide"] = 
        {
            ["$AccountWide"] = 
            {
                ["castAlertsSound"] = true,
                ["nearbyLeft"] = 1200,
                ["extMA"] = false,
                ["version"] = 1,
                ["panelTop"] = 300,
                ["extTDC"] = false,
                ["castAlertsEnabled"] = true,
                ["lokiStance"] = false,
                ["dsrShowWave"] = false,
                ["crushing"] = false,
                ["panelLeft"] = 400,
                ["maxCastMS"] = 4000,
                ["projectileTimingAdjustment"] = 0.8000000000,
                ["debugLog"] = 
                {
                },
                ["verboseCasts"] = false,
                ["nearbyEnabled"] = false,
                ["crshift"] = true,
                ["nearbyTop"] = 300,
                ["dsrDelugeBlame"] = false,
                ["dsrPortSounds"] = false,
                ["debugEnabled"] = false,
            },
        },
    },
}
