PersonalAssistantLoot_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["version"] = 2,
                [1] = 
                {
                    ["name"] = "Profile 1",
                    ["silentMode"] = false,
                    ["InventorySpace"] = 
                    {
                        ["lowInventorySpaceWarning"] = true,
                        ["lowInventorySpaceThreshold"] = 10,
                    },
                    ["LootEvents"] = 
                    {
                        ["LootRecipes"] = 
                        {
                            ["unknownRecipeMsg"] = true,
                        },
                        ["LootCompanionItems"] = 
                        {
                            ["qualityThreshold"] = 4,
                        },
                        ["lootEventsEnabled"] = true,
                        ["LootApparelWeapons"] = 
                        {
                            ["uncollectedSetMsg"] = true,
                            ["unknownTraitMsg"] = true,
                        },
                        ["LootStyles"] = 
                        {
                            ["autoLearnMotif"] = false,
                            ["autoLearnStylePage"] = false,
                            ["unknownMotifMsg"] = true,
                            ["autoLearnRecipe"] = false,
                            ["unknownStylePageMsg"] = true,
                        },
                        ["Fishing"] = 
                        {
                            ["AutoFillet"] = false,
                        },
                    },
                    ["ItemIcons"] = 
                    {
                        ["CompanionItems"] = 
                        {
                            ["iconXOffsetGrid"] = 2,
                            ["iconYOffsetGrid"] = -2,
                            ["iconXOffsetList"] = 0,
                            ["iconSizeList"] = 16,
                            ["iconYOffsetList"] = 0,
                            ["iconSizeGrid"] = 16,
                            ["showCompanionItemIcon"] = true,
                        },
                        ["iconYOffsetGrid"] = -2,
                        ["Recipes"] = 
                        {
                            ["showKnownIcon"] = false,
                            ["showUnknownIcon"] = true,
                        },
                        ["ApparelWeapons"] = 
                        {
                            ["showKnownIcon"] = false,
                            ["showUnknownIcon"] = true,
                        },
                        ["StylePageContainers"] = 
                        {
                            ["showKnownIcon"] = false,
                            ["showUnknownIcon"] = true,
                        },
                        ["Motifs"] = 
                        {
                            ["showKnownIcon"] = false,
                            ["showUnknownIcon"] = true,
                        },
                        ["iconXOffsetGrid"] = 2,
                        ["itemIconsEnabled"] = true,
                        ["iconSizeList"] = 16,
                        ["iconXOffsetList"] = 0,
                        ["iconYOffsetList"] = 0,
                        ["iconTooltipShown"] = true,
                        ["iconSizeGrid"] = 16,
                        ["SetCollection"] = 
                        {
                            ["iconXOffsetGrid"] = -2,
                            ["iconYOffsetGrid"] = -2,
                            ["iconXOffsetList"] = 20,
                            ["iconSizeList"] = 16,
                            ["showUncollectedIcon"] = true,
                            ["iconYOffsetList"] = 0,
                            ["iconSizeGrid"] = 16,
                        },
                    },
                },
                ["savedVarsVersion"] = 20230728,
                ["profileCounter"] = 1,
            },
        },
    },
}
