ZO_InternalIngame_SavedVariables =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["Tribute"] = 
                {
                    ["version"] = 1,
                    ["autoPlayChecked"] = false,
                },
            },
        },
    },
}
