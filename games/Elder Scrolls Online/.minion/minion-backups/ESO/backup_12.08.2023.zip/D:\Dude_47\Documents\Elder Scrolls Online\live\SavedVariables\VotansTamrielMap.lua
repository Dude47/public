VotansTamrielMap_Data =
{
    ["Default"] = 
    {
        ["@Dude_47"] = 
        {
            ["$AccountWide"] = 
            {
                ["hidePins"] = true,
                ["version"] = 1,
                ["color"] = "Alliance",
                ["titleFont"] = "ANTIQUE_FONT",
                ["opacity"] = 50,
            },
        },
    },
}
